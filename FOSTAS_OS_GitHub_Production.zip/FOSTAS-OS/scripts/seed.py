"""
FOSTAS OS — Knowledge Base & Godot Project Seeder

Generates the full Toybox Terror knowledge base (9 .md files) and
a sample Godot project skeleton. Idempotent — safe to re-run.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Allow running as script
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from backend.knowledge import get_knowledge_manager
from config.settings import get_settings


# ============================================================
# KNOWLEDGE BASE CONTENT
# ============================================================

KNOWLEDGE_DOCS = {
    "GameBible.md": """# FOSTAS: Toybox Terror — Game Bible

## Vision
FOSTAS: Toybox Terror is an online 5v5 multiplayer first-person shooter for PC (Steam) that pairs a brightly-colored stylized toy-world aesthetic with a mid-match psychological-horror event (the FOSTAS Monster). Engine: Godot 4.3. Match length: 8-12 minutes. Best-of-3 rounds in ranked Artifact Mode.

## Factions
Two factions only: **RED TEAM** vs **BLUE TEAM**. No other color is permitted anywhere in the project. This is enforced at the shader level — the PlasticToy material takes a `team_color_override` uniform.

## Match Structure
- 5v5 lobby-based
- 4-minute round timer
- 30-second artifact-spawn delay
- FOSTAS event triggers ONCE per match at random 1:30-6:30
- Reconnect window: 90 seconds

## Classes
1. **Combat Medic** — support/close-range. Body mesh: `low_poly_solider_character`. Carries `medkit`. Heal Pulse (Q), Revive (E).
2. **Tactical Mage** — mid-range caster. Body mesh: `soldat_low_poly`. Carries `old_fantasy_book`. Spell system gated behind per-life quests.

## Performance Targets
- 60 FPS sustained on GTX 1060 @ 1080p medium
- 120-144 FPS on RTX 4070
- Frame-time budget: 16.6 ms

## Damage Model
- Headshot: x4 multiplier
- Torso: x1
- Limb: x0.7
- TTK target: 0.3-0.8 s at optimal range (0.25 floor, 1.2 ceiling)

## Hardcore Injury System
Six limb HP pools per player: head, torso, left arm, right arm, left leg, right leg. Four thresholds trigger escalating debuffs.

## Bots
Fill empty lobby slots to guarantee 5v5 minimum. Reuse Medic/Mage meshes with Toy Reskin Pass. Three skill levels: easy, medium, hard.
""",

    "Weapons.md": """# FOSTAS Weapons System

## Toy Reskin Pipeline (8 steps, applied to all imported weapon GLTFs)
1. Load imported GLTF as-is (no re-modeling)
2. Swap every metallic/dark material for PlasticToy material
3. Apply team_color_override (RED: #E63946, BLUE: #1D6FB8)
4. Replace muzzle flash with toy sparkle particle
5. Replace bullet tracer with candy-colored streak
6. Add subtle cartoon outline shader
7. Normalize scale to 1m bounding-box longest axis
8. Attach Toy Blaster Pistol as universal sidearm

## Damage Model
- Headshot: x4
- Torso: x1
- Limb: x0.7
- TTK target: 0.3-0.8 s at optimal range

## Weapon Manifest (11 imported GLTFs)

| # | Folder | Real Weapon | Toy Name | Slot | DMG | RPM | Mag | Range |
|---|--------|-------------|----------|------|-----|-----|-----|-------|
| 1 | low-poly_aug_a1 | Steyr AUG A1 | BumbleBee AR | Primary | 22 | 700 | 30 | 60m |
| 2 | low-poly_fn_arka | FN ARKA | Plasma Carbine | Primary | 28 | 600 | 30 | 80m |
| 3 | low-poly_hk_mr762 | H&K MR762 | Laser Marksman | Primary | 55 | 300 | 20 | 120m |
| 4 | low-poly_kriss_vector | KRISS Vector | BuzzBee SMG | Primary | 16 | 1100 | 25 | 25m |
| 5 | low-poly_pp-19_vityaz-sn | PP-19 Vityaz | Hornet SMG | Primary | 18 | 800 | 30 | 30m |
| 6 | low-poly_psl_rifle | PSL DMR | Star Sniper | Primary | 110 (HS one-shot) | 60 | 10 | 200m |
| 7 | low-poly_rpk-74n | RPK-74N | Stinger LMG | Primary | 24 | 600 | 75 | 80m, bipod |
| 8 | low-poly_saiga_410 | Saiga-410 | Confetti Cannon | Primary | 12x8 pellets | 200 | 8 | 15m |
| 9 | low-poly_six_12 | Six12 | Bubble Blaster | Primary | 14x6 pellets | 240 | 6 | 18m |
| 10 | low-poly_tactical_shotgun | Tactical Shotgun | Party Popper | Primary | 16x9 pellets | 100 | 5 | 20m |
| 11 | low-poly_gl6 | GL6 grenade launcher | Balloon Bomber | Primary | 80 splash | 60 | 4 | 50m arc |

## Universal Sidearm (NOT from imported GLTF)
**Toy Blaster Pistol**: single low-poly mesh ~3K tris, toy plastic, every class spawns with it. DMG 12, RPM 300, Mag 10, Range 20m. Infinite reserve.

## Critical Gaps
- All 11 weapon GLTFs ship with ZERO animations — must author reload/fire/inspect from scratch.
- Scale normalization required (bounding boxes range from 0.38m to 3.88m longest axis).

## Adding a New Weapon
To add a new weapon via FOSTAS OS:
1. Create `godot/scripts/weapons/<weapon_name>.gd` extending `Weapon` base class.
2. Define `@export` stats matching the table above.
3. Implement `fire()`, `reload()`, `_physics_process()`.
4. Create matching `.tscn` scene with model placeholder.
5. Register in `godot/autoload/weapons_registry.gd`.
""",

    "Magic.md": """# FOSTAS Magic System (Tactical Mage only)

## Spell Gating (per-life randomized quest)
Each life, the Mage is assigned ONE of two quests at random:

### Quest A — "3 Headshots"
Land three headshot kills. On completion, unlocks Tier-2 Weapon Enchantment.

### Quest B — "3 Teammate Heals"
Heal three teammates via Heal Pulse (shared with Medic cooldown). On completion, unlocks Tier-2 Mass Shield.

## Tier-2 Spells (quest reward)

### Weapon Enchantment
- Headshot damage multiplier jumps from x4 to x12
- Mage's weapon glows purple (#9D4EDD)
- Duration: 15 seconds
- Cooldown: 30 seconds
- Pairs with high-fire-rate weapons (BuzzBee SMG, Hornet SMG)

### Mass Shield
- All teammates within 8m gain 50 HP overshield
- Shield glows team-color
- Duration: 10 seconds
- Cooldown: 45 seconds

## Tier-3 Spells (Soul Contract — automatic penalty)

### Mass Teleport
- Teleports entire team to friendly castle
- Penalty: Mage loses 50 HP permanently for rest of round
- Cooldown: 120 seconds

### Soul Harvest
- Instantly kills all Shadow Monsters in 30m radius (only during FOSTAS event)
- Penalty: Mage's next 3 respawns take +50% damage
- Cooldown: 240 seconds

## Bounty → Ultimate Shortcut
Any player on a 3-killstreak gets a glowing red rune above their head (visible through walls to enemies only) AND automatically unlocks their class's Tier-2 ability without completing the quest. This is the parallel path to spell power.

## Spellbook Prop & VFX
- Mage carries `old_fantasy_book` asset floating beside left hand
- Book opens and glows when casting any spell
- Weapon Enchantment VFX: purple particle trail on bullets, weapon barrel aura
- Mass Shield VFX: team-color expanding ring on cast
- Mass Teleport VFX: team-color column of light, players dissolve and reform at castle
""",

    "Potions.md": """# FOSTAS Potions System

## Healing Potion (Toy Green)
- Restores 50 HP instantly
- Carry limit: 2 per life
- Use key: F
- VFX: toy-green sparkle burst, "drink" animation on character
- Models reuse `medkit` asset with green tint shader

## Speed Potion (Toy Yellow)
- +30% movement speed for 8 seconds
- Carry limit: 1 per life
- Use key: G
- VFX: yellow motion trail, cartoon dust clouds at feet
- Cooldown after use: 5 seconds (anti-spam)

## Rage Potion (Toy Red)
- +25% damage for 6 seconds
- Carry limit: 1 per life
- Use key: H
- VFX: red eye glow, weapon barrel flame aura
- Risk: highlights user on enemy minimap (visible during cute phase only)

## Invisibility Potion (Toy Blue)
- 4 seconds of invisibility (90% transparent)
- Carry limit: 1 per life
- Use key: J
- VFX: blue dissolve effect, faint shimmer on movement
- Breaks on damage dealt or taken

## Potion Spawn Rules
- Spawn at fixed map points (potions rack in each castle's courtyard)
- Respawn every 45 seconds after pickup
- Maximum 3 potions per rack at any time
- Both teams have equal access to their own rack

## Adding a New Potion via FOSTAS OS
1. Create `godot/scripts/items/potion.gd` extending `Item` base class.
2. Define `@export` stats: effect_type, magnitude, duration, carry_limit.
3. Implement `use(player)` method that applies the effect.
4. Register in `godot/autoload/items_registry.gd`.
5. Add a spawn point to the map's potions rack.
""",

    "Vehicles.md": """# FOSTAS Vehicles System

## Design Philosophy
FOSTAS: Toybox Terror is primarily a 5v5 infantry FPS, but vehicles appear as map objectives and event rewards. All vehicles use the stylized toy aesthetic — bright plastic colors, oversized wheels, cartoon proportions.

## Toy Kart (Map Objective)
- Spawns once per round at the mid-field playground center
- 2 seats: driver + gunner
- Driver: WASD movement, Boost (Shift, 3-second burst, 10s cooldown)
- Gunner: Toy Blaster turret (infinite ammo, 300 RPM, 15 DMG)
- HP: 200 (destroyed → respawns after 60s)
- Speed: 12 m/s normal, 18 m/s boost
- Model: original Kart GLB (not in 11-weapon manifest — separate asset)

## Toy Tank (FOSTAS Event Reward)
- Spawns for the team that kills the most Shadow Monsters during the Hunt phase
- 1 driver, 1 gunner
- Main cannon: 150 DMG, 4 RPM, 100m range, splash radius 5m
- Coaxial MG: 25 DMG, 600 RPM
- HP: 500
- Speed: 6 m/s
- Limited duration: 60 seconds, then despawns

## Toy Helicopter (Rare Pickup)
- Spawns at a random rooftop every 3 minutes
- 1 pilot, 1 gunner
- Pilot: WASD + Space/Ctrl for altitude
- Gunner: dual Toy Blasters (300 RPM each, 12 DMG)
- HP: 150
- Flight time: unlimited until destroyed
- Fuel: NONE (simplified for arcade feel)

## Adding a New Vehicle via FOSTAS OS
1. Create `godot/scripts/vehicles/<vehicle_name>.gd` extending `VehicleBody3D` or `RigidBody3D`.
2. Define `@export` stats: max_speed, hp, seats, weapons.
3. Implement `_physics_process()` for movement.
4. Add driver/gunner input mapping.
5. Create matching `.tscn` scene.
6. Register in `godot/autoload/vehicles_registry.gd`.
""",

    "Maps.md": """# FOSTAS Maps System

## Primary Map — Castle Wars
Assembled from TWO imported GLTFs:

### Base: `castle_wars_pavlov_vr/scene.gltf`
- 19 meshes, 21 nodes, 19 materials, 5 textures
- Bounding box: 137m x 40m x 18.7m
- Two opposing castles: AlliesC.001 → Red, AxisC → Blue
- Each castle has 3 floors: courtyard gate, ramparts, sniper tower
- ⚠ LICENSE: CC-BY-NC-SA-4.0 — NON-COMMERCIAL. Replace for Steam release.

### Mid-field: `lowpoly__map__asset__by_resoforge`
- Massive 1684-mesh, 2746-node set
- Bounding box: 252m x 112m x 60m
- Materials: PLANE, YELLOW, WHITE, etc.
- Provides containers, ramps, crates for cover
- License: CC-BY-4.0 (commercial OK)

## Map Layout
- Two castles at opposite ends (Red on west, Blue on east)
- Courtyard in the middle (artifact spawn point)
- 3 lanes: north, middle, south
- Vertical play: each castle's sniper tower overlooks courtyard
- Health/ammo racks in each castle's courtyard

## Lighting
- **Cute phase (default)**: baked global illumination, soft pastel GI, warm sun
- **Horror phase (FOSTAS event)**: real-time GI, single cold point-light per shadow monster, rest of map in darkness
- Transition: 0.4-second lerp

## Verticality
- Each castle: gate level, ramparts (mid), sniper tower (top)
- Tower windows overlook courtyard
- Sniper rifle (Star Sniper) optimal from tower

## Future Maps (planned)
1. **Toy Workshop** — assembly line conveyor belts, toy parts as cover
2. **Playground** — swing sets, slides, sandcastle bunkers
3. **Toy Store** — shelving aisles, display cases, checkout counter control point

## Adding a New Map via FOSTAS OS
1. Create `godot/scenes/maps/<map_name>.tscn` extending Node3D.
2. Import the base GLTF as a child scene.
3. Add spawn points (player, weapon, potion, vehicle).
4. Add light probes for baked GI (cute phase).
5. Add real-time light sources for horror phase.
6. Register in `godot/autoload/maps_registry.gd`.
""",

    "Monster.md": """# FOSTAS Monster System

## Shadow Monster (FOSTAS Event creature)
- Asset: `decraniated_low_poly_retro_pixel`
- Re-shaded to pure black (#0A0A0F) with red emissive eyes (#FF0000)
- Five instances spawn during the 20-second Hunt phase
- AI-driven: wanders randomly, chases nearest player on sight
- HP: 100
- Speed: 5 m/s (slightly slower than player sprint of 6 m/s)
- Attack: melee, 25 DMG per hit, 1.0s cooldown
- Detection range: 15m, FOV 180°
- Cannot be permanently killed — respawns after 5s if destroyed

## FOSTAS Event Phases

### Phase 1 — Blackout (0.4s)
- Every player's screen snaps to pure black
- Cute ambient music cuts to dead silence
- All team VOIP mutes
- No fade — sudden and total

### Phase 2 — Warning (1.0s)
- Massive blood-red glowing text: "FOSTAS MONSTER IS COMING! HIDE!"
- Heavy sub-bass rumble
- VOIP remains muted

### Phase 3 — Hunt (20s)
- 5 Shadow Monsters spawn from random courtyard points
- Players debuffed: -15% movement speed (panic slow), screen-shake x3, minimap disabled, VOIP muted
- Monsters hunt players; players can fight back but monster respawns
- Tactical Mage's Soul Harvest Tier-3 can clear monsters in radius

### Phase 4 — Recovery (2s)
- Screen fades back to cute palette
- Sun returns, ambient music resumes
- Match continues from where interrupted (timer, artifact state, bleed-outs preserved)

## Lighting Transition
- 0.4s lerp from baked cute-phase GI to real-time horror-phase GI
- Cold point-light follows each shadow monster
- Rest of map is in darkness during Hunt

## Adaptive Music
- 4 stems: cute base, cute combat, horror base, horror combat
- 0.5s crossfades
- During FOSTAS event: silence at Phase 1, sub-bass rumble at Phase 2, horror combat stem at Phase 3, fade back to cute at Phase 4

## Adding a New Monster via FOSTAS OS
1. Create `godot/scripts/monsters/<monster_name>.gd` extending `CharacterBody3D`.
2. Define `@export` stats: max_health, move_speed, attack_damage, detection_range.
3. Implement simple state machine: IDLE → WANDER → CHASE → ATTACK → DIE.
4. Implement `take_damage(amount)` and `die()`.
5. Create matching `.tscn` scene with model placeholder.
6. Register in `godot/autoload/monsters_registry.gd`.
7. (Optional) Request 3D model generation from Tripo.
""",

    "Networking.md": """# FOSTAS Multiplayer Networking

## Architecture
- Dedicated-server authoritative (standard competitive FPS)
- Server tick rate: 20 Hz (50ms per tick)
- Client input rate: 60 Hz
- Snapshot interpolation: 100ms buffer
- Lag compensation: 200ms rewind window for hit validation
- Reconnect window: 90 seconds

## Server Authority
- Server runs full game simulation at 20 Hz
- Clients send inputs (movement, look, fire) at 60 Hz
- Server validates all actions (no client trust)
- Server broadcasts world snapshots at 20 Hz
- Clients interpolate between snapshots (100ms buffer)

## Hit Validation (Lag Compensation)
- Client fires → predicts hit locally
- Server rewinds world state by up to 200ms
- Server validates shot from client's perspective at fire time
- If hit confirmed server-side, damage applied
- If miss, no rollback needed (client prediction was wrong)

## Client-Side Prediction
- Movement: client predicts own position, server corrects if mismatch
- Reconciliation: client rewinds to server-confirmed state, replays inputs
- Visual smoothing: 0.1s lerp to avoid rubber-banding

## Snapshot Interpolation
- Buffer 3 snapshots (150ms) before rendering
- Linear interpolation between snapshots
- Extrapolation cap: 100ms (then freeze entity)

## FOSTAS Event Networking
- Server rolls trigger time at match start (random 1:30-6:30, once per match)
- Server broadcasts all phase transitions:
  - Phase 1 Blackout (0.4s) — all clients blackout simultaneously
  - Phase 2 Warning (1.0s) — all clients see warning text
  - Phase 3 Hunt (20s) — server spawns 5 monsters, broadcasts positions
  - Phase 4 Recovery (2s) — all clients fade back

## Common Issues & Fixes

### Lag / Rubber-banding
- Symptom: players teleport, hit registration feels off
- Root cause: snapshot interpolation buffer underrun, or client prediction mismatch
- Fix: increase interpolation buffer to 150ms, add input delta compression, validate movement server-side with tolerance window

### Desync
- Symptom: clients see different world states
- Root cause: missed snapshots, deterministic physics divergence
- Fix: server broadcasts full state every 5 seconds (re-sync), client rewinds and replays

### High Ping Player
- Symptom: lag compensation abused (getting shot around corners)
- Root cause: 200ms rewind window too generous for 300ms+ ping players
- Fix: clamp rewind to min(client_ping, 200ms), reject shots from ping > 300ms

## Adding New Network Features via FOSTAS OS
1. Define RPC in `godot/scripts/network/rpc_manager.gd`.
2. Use `@rpc("any_peer", "call_local", "reliable")` for state changes.
3. Use `@rpc("any_peer", "unreliable")` for high-frequency updates.
4. Server validates all peer requests before applying.
""",

    "Optimization.md": """# FOSTAS Performance Optimization

## Targets
- 60 FPS sustained on GTX 1060 @ 1080p medium (during 5v5 + FOSTAS event)
- 120-144 FPS on RTX 4070
- Frame-time budget: 16.6 ms (60 FPS)

## Profiling Tools
- Godot Built-in Profiler (Monitor tab)
- `--rendering-driver opengl3` for compatibility testing
- `--rendering-driver vulkan` for production
- Render debug: `--render-debug overdraw` to find overdraw hotspots

## Rendering Optimizations

### LOD (Level of Detail)
- 3 LOD levels per weapon model: full (0-15m), medium (15-40m), low (40m+)
- 4 LOD levels per environment mesh (castle_wars is 19 meshes)
- Trigger: distance from camera
- Use Godot's `LODManager` or manual `MeshInstance3D.lod_bias`

### Occlusion Culling
- Enable `OcclusionCulling` in project settings
- Bake occlusion meshes for castle_wars and mid-field playground
- Critical for 1684-mesh mid-field scene

### Baked Lighting (Cute Phase)
- Use BakedLightmap + LightmapGI for cute phase
- 4K lightmap resolution for castle interiors
- 2K for outdoor areas
- Static geometry only — dynamic objects use real-time light probes

### Real-time Lighting (Horror Phase)
- Single cold point-light per shadow monster (max 5 active)
- Disable shadow casting on point-lights (perf cost too high)
- Use unlit materials for distant geometry during Hunt phase

### Material Optimizations
- Use `StandardMaterial3D` with `shading_mode = unshaded` where possible
- PlasticToy material: 1 texture, 1 uniform (team_color_override) — very cheap
- Avoid `BaseMaterial3D` features like `subsurface_scattering` for toys

## Networking Optimizations

### Snapshot Compression
- Use delta compression (send only changes from last snapshot)
- Quantize positions to 16-bit per axis (±327m, 1mm precision)
- Quantize rotations to quaternion packed in 32 bits

### Bandwidth Budget
- Target: 64 Kbps per client (server → client)
- Target: 16 Kbps per client (client → server, inputs)
- 5v5 = 10 clients = 640 Kbps server upload, 160 Kbps server download

## Memory Optimizations
- Asset streaming for mid-field playground (load in chunks based on player position)
- Texture streaming: mipmaps streamed from disk
- Audio: stream long stems, preload short SFX

## Frame-Time Budget Breakdown (60 FPS = 16.6ms)
- Rendering: 8ms (48%)
- Physics: 3ms (18%)
- Networking: 1ms (6%)
- Game logic: 3ms (18%)
- Audio: 0.5ms (3%)
- OS/overhead: 1.1ms (7%)

## Common Performance Issues & Fixes

### Frame Drops During FOSTAS Event
- Root cause: 5 real-time point-lights + dynamic GI recalculation
- Fix: disable dynamic GI during Hunt, use baked "horror" lightmap + per-monster point-light

### Stuttering on Asset Load
- Root cause: synchronous texture streaming
- Fix: enable `ResourceLoader.load_async`, preload critical assets at match start

### High Draw Calls (1684 mesh mid-field)
- Root cause: too many small meshes
- Fix: merge static meshes via `MeshInstance3D.merge_meshes`, target <500 draw calls per frame
""",
}


# ============================================================
# GODOT SAMPLE PROJECT FILES
# ============================================================

GODOT_PROJECT_FILE = """; Engine configuration file.
; It's best edited using the editor UI and not directly.

config_version=5

[application]

config/name="FOSTAS: Toybox Terror"
config/description="Online 5v5 multiplayer FPS — stylized toy world × psychological horror"
run/main_scene="res://scenes/main.tscn"
config/features=PackedStringArray("4.3", "GL Compatibility")
config/icon="res://icon.svg"

[autoload]

WeaponsRegistry="*res://scripts/autoload/weapons_registry.gd"
MonstersRegistry="*res://scripts/autoload/monsters_registry.gd"

[display]

window/size/viewport_width=1920
window/size/viewport_height=1080
window/stretch/mode="canvas_items"

[input]

move_forward={
"deadzone": 0.5,
"events": [Object(InputEventKey,"keycode":87)]
}
move_backward={
"deadzone": 0.5,
"events": [Object(InputEventKey,"keycode":83)]
}
move_left={
"deadzone": 0.5,
"events": [Object(InputEventKey,"keycode":65)]
}
move_right={
"deadzone": 0.5,
"events": [Object(InputEventKey,"keycode":68)]
}
fire={
"deadzone": 0.5,
"events": [Object(InputEventMouseButton,"button_index":1)]
}
reload={
"deadzone": 0.5,
"events": [Object(InputEventKey,"keycode":82)]
}

[rendering]

renderer/rendering_method="gl_compatibility"
renderer/rendering_method.mobile="gl_compatibility"
environment/defaults/default_clear_color=Color(0.85, 0.93, 1.0, 1.0)
"""

WEAPON_BASE_SCRIPT = """# File: scripts/weapons/weapon.gd
# FOSTAS: Toybox Terror — Base Weapon Class
# All weapons extend this. Provides fire(), reload(), ammo tracking.
extends Node3D
class_name Weapon

@export var weapon_name: String = "Toy Weapon"
@export var damage: int = 25
@export var fire_rate: float = 600.0  # rounds per minute
@export var magazine_size: int = 30
@export var range_m: float = 60.0
@export var reload_time: float = 2.5
@export var team_color: Color = Color(0.9, 0.22, 0.27)  # RED default

var current_ammo: int = 0
var is_reloading: bool = false
var _last_fire_time: float = 0.0
var _reload_timer: float = 0.0

signal fired(hit_result: Dictionary)
signal reloaded
signal ammo_changed(current: int, max: int)

func _ready() -> void:
    current_ammo = magazine_size
    ammo_changed.emit(current_ammo, magazine_size)

func _process(delta: float) -> void:
    if is_reloading:
        _reload_timer -= delta
        if _reload_timer <= 0.0:
            _finish_reload()

func can_fire() -> bool:
    if is_reloading:
        return false
    if current_ammo <= 0:
        return false
    var now: float = Time.get_ticks_msec() / 1000.0
    var cooldown: float = 60.0 / max(1.0, fire_rate)
    if now - _last_fire_time < cooldown:
        return false
    return true

func fire(from_position: Vector3, direction: Vector3) -> Dictionary:
    if not can_fire():
        return {"hit": false, "reason": "cannot_fire"}
    current_ammo -= 1
    _last_fire_time = Time.get_ticks_msec() / 1000.0
    ammo_changed.emit(current_ammo, magazine_size)
    # Raycast-based hit detection (server-authoritative in real multiplayer)
    var space_state: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
    var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(
        from_position, from_position + direction * range_m
    )
    query.exclude = [self]
    var result: Dictionary = space_state.intersect_ray(query)
    var hit_result: Dictionary = {"hit": false, "damage": 0, "ammo_left": current_ammo}
    if not result.is_empty():
        hit_result.hit = true
        hit_result.collider = result.collider
        hit_result.position = result.position
        hit_result.damage = damage
    fired.emit(hit_result)
    return hit_result

func reload() -> void:
    if is_reloading:
        return
    if current_ammo == magazine_size:
        return
    is_reloading = true
    _reload_timer = reload_time

func _finish_reload() -> void:
    current_ammo = magazine_size
    is_reloading = false
    ammo_changed.emit(current_ammo, magazine_size)
    reloaded.emit()
"""

EXISTING_WEAPON_RIFLE = """# File: scripts/weapons/bumblebee_ar.gd
# FOSTAS: Toybox Terror — BumbleBee AR (Toy reskin of Steyr AUG A1)
extends Weapon
class_name BumbleBeeAR

func _ready() -> void:
    weapon_name = "BumbleBee AR"
    damage = 22
    fire_rate = 700.0
    magazine_size = 30
    range_m = 60.0
    reload_time = 2.2
    super._ready()
"""

MONSTER_BASE_SCRIPT = """# File: scripts/monsters/shadow_monster.gd
# FOSTAS: Toybox Terror — Shadow Monster (FOSTAS Event creature)
# Spawns during the 20-second Hunt phase. AI state machine: IDLE -> WANDER -> CHASE -> ATTACK.
extends CharacterBody3D
class_name ShadowMonster

@export var max_health: int = 100
@export var move_speed: float = 5.0
@export var attack_damage: int = 25
@export var attack_range: float = 2.0
@export var detection_range: float = 15.0
@export var attack_cooldown: float = 1.0

enum State { IDLE, WANDER, CHASE, ATTACK, DEAD }

var health: int = 100
var current_state: int = State.IDLE
var _target: Node3D = null
var _attack_timer: float = 0.0
var _wander_direction: Vector3 = Vector3.ZERO
var _wander_timer: float = 0.0

signal died(monster: Node3D)
signal hit_player(player: Node3D, damage: int)

func _ready() -> void:
    health = max_health
    current_state = State.WANDER
    _pick_new_wander_direction()

func take_damage(amount: int) -> void:
    if current_state == State.DEAD:
        return
    health = max(0, health - amount)
    if health == 0:
        die()

func die() -> void:
    current_state = State.DEAD
    died.emit(self)
    visible = false
    process_mode = Node.PROCESS_MODE_DISABLED

func _physics_process(delta: float) -> void:
    if current_state == State.DEAD:
        return
    _attack_timer = max(0.0, _attack_timer - delta)
    _update_state_machine(delta)
    move_and_slide()

func _update_state_machine(delta: float) -> void:
    var player: Node3D = _find_nearest_player()
    var dist_to_player: float = global_position.distance_to(player.global_position) if player else INF

    match current_state:
        State.IDLE:
            if player and dist_to_player < detection_range:
                current_state = State.CHASE
                _target = player
            else:
                _wander_timer -= delta
                if _wander_timer <= 0.0:
                    current_state = State.WANDER
                    _pick_new_wander_direction()

        State.WANDER:
            if player and dist_to_player < detection_range:
                current_state = State.CHASE
                _target = player
            else:
                velocity = _wander_direction * move_speed * 0.5
                _wander_timer -= delta
                if _wander_timer <= 0.0:
                    _pick_new_wander_direction()

        State.CHASE:
            if not _target or not is_instance_valid(_target):
                current_state = State.WANDER
                return
            if dist_to_player <= attack_range:
                current_state = State.ATTACK
            elif dist_to_player > detection_range * 1.5:
                current_state = State.WANDER
                _target = null
            else:
                var direction: Vector3 = (_target.global_position - global_position).normalized()
                velocity = direction * move_speed

        State.ATTACK:
            if not _target or not is_instance_valid(_target):
                current_state = State.WANDER
                return
            if dist_to_player > attack_range * 1.2:
                current_state = State.CHASE
            elif _attack_timer <= 0.0:
                hit_player.emit(_target, attack_damage)
                _attack_timer = attack_cooldown
            velocity = Vector3.ZERO

func _find_nearest_player() -> Node3D:
    var players: Array[Node] = get_tree().get_nodes_in_group("players")
    var nearest: Node3D = null
    var nearest_dist: float = INF
    for p in players:
        if not p is Node3D:
            continue
        var d: float = global_position.distance_to(p.global_position)
        if d < nearest_dist and d < detection_range:
            nearest_dist = d
            nearest = p
    return nearest

func _pick_new_wander_direction() -> void:
    var rand_angle: float = randf() * TAU
    _wander_direction = Vector3(cos(rand_angle), 0.0, sin(rand_angle))
    _wander_timer = randf_range(2.0, 5.0)
"""

WEAPONS_REGISTRY = """# File: scripts/autoload/weapons_registry.gd
# FOSTAS: Toybox Terror — Central registry of all weapon classes
extends Node

const WEAPON_SCRIPTS: Dictionary = {
    "BumbleBeeAR": "res://scripts/weapons/bumblebee_ar.gd",
    "PlasmaCarbine": "res://scripts/weapons/plasma_carbine.gd",
    "LaserMarksman": "res://scripts/weapons/laser_marksman.gd",
    "BuzzBeeSMG": "res://scripts/weapons/buzzbee_smg.gd",
    "HornetSMG": "res://scripts/weapons/hornet_smg.gd",
    "StarSniper": "res://scripts/weapons/star_sniper.gd",
    "StingerLMG": "res://scripts/weapons/stinger_lmg.gd",
    "ConfettiCannon": "res://scripts/weapons/confetti_cannon.gd",
    "BubbleBlaster": "res://scripts/weapons/bubble_blaster.gd",
    "PartyPopper": "res://scripts/weapons/party_popper.gd",
    "BalloonBomber": "res://scripts/weapons/balloon_bomber.gd",
}

func get_weapon_script(weapon_name: String) -> GDScript:
    var path: String = WEAPON_SCRIPTS.get(weapon_name, "")
    if path.is_empty():
        push_warning("Unknown weapon: " + weapon_name)
        return null
    return load(path) as GDScript

func list_weapons() -> Array:
    return WEAPON_SCRIPTS.keys()
"""

MONSTERS_REGISTRY = """# File: scripts/autoload/monsters_registry.gd
# FOSTAS: Toybox Terror — Central registry of all monster classes
extends Node

const MONSTER_SCRIPTS: Dictionary = {
    "ShadowMonster": "res://scripts/monsters/shadow_monster.gd",
}

func get_monster_script(monster_name: String) -> GDScript:
    var path: String = MONSTER_SCRIPTS.get(monster_name, "")
    if path.is_empty():
        push_warning("Unknown monster: " + monster_name)
        return null
    return load(path) as GDScript

func list_monsters() -> Array:
    return MONSTER_SCRIPTS.keys()
"""

NETWORK_SCRIPT = """# File: scripts/network/player_network.gd
# FOSTAS: Toybox Terror — Client-side interpolation + prediction
# Attached to each networked player avatar.
extends Node

# Snapshot interpolation buffer (100ms = 3 snapshots at 20Hz tick)
const INTERP_DELAY: float = 0.1
const INTERP_MAX_BUFFER: int = 10

var pending_states: Array = []
var _last_applied_pos: Vector3 = Vector3.ZERO

func _physics_process(delta: float) -> void:
    var now: float = Time.get_ticks_msec() / 1000.0
    while pending_states.size() > 1 and pending_states[1].t <= now - INTERP_DELAY:
        pending_states.pop_front()
    if pending_states.size() >= 2:
        var s0: Dictionary = pending_states[0]
        var s1: Dictionary = pending_states[1]
        var t0: float = s0.t
        var t1: float = s1.t
        if t1 > t0:
            var alpha: float = clamp((now - INTERP_DELAY - t0) / (t1 - t0), 0.0, 1.0)
            var interp_pos: Vector3 = (s0.pos as Vector3).lerp(s1.pos as Vector3, alpha)
            get_parent().global_position = interp_pos
            _last_applied_pos = interp_pos

func receive_snapshot(t: float, pos: Vector3, rot: Vector3) -> void:
    pending_states.append({"t": t, "pos": pos, "rot": rot})
    if pending_states.size() > INTERP_MAX_BUFFER:
        pending_states.pop_front()

func reset() -> void:
    pending_states.clear()
"""

MAIN_SCENE = """[gd_scene load_steps=2 format=3 uid="uid://fostas_main"]

[ext_resource type="Script" path="res://scripts/main.gd" id="1"]

[node name="Main" type="Node3D"]
script = ExtResource("1")

[node name="DirectionalLight3D" type="DirectionalLight3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 0.707107, 0.707107, 0, -0.707107, 0.707107, 0, 30, 0)
light_color = Color(1.0, 0.95, 0.85, 1)
light_energy = 1.2
shadow_enabled = true

[node name="Camera3D" type="Camera3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 5, 20)
fov = 75.0
"""

MAIN_SCRIPT = """# File: scripts/main.gd
# FOSTAS: Toybox Terror — Main scene entry point
extends Node3D

func _ready() -> void:
    print("FOSTAS: Toybox Terror — main scene loaded")
    print("Weapons available: ", WeaponsRegistry.list_weapons() if has_node("/root/WeaponsRegistry") else [])
    print("Monsters available: ", MonstersRegistry.list_monsters() if has_node("/root/MonstersRegistry") else [])
"""

ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <rect width="128" height="128" fill="#1a1a2e"/>
  <circle cx="64" cy="64" r="40" fill="#e63946" stroke="#fff" stroke-width="4"/>
  <text x="64" y="78" font-family="Arial" font-size="40" font-weight="bold" text-anchor="middle" fill="#fff">F</text>
</svg>
"""


# ============================================================
# SEEDER
# ============================================================


def seed_knowledge() -> None:
    km = get_knowledge_manager()
    for name, content in KNOWLEDGE_DOCS.items():
        path = km.write_doc(name, content)
        print(f"  [knowledge] {path.name} ({len(content)} bytes)")


def seed_godot_project() -> None:
    settings = get_settings()
    godot_dir = settings.godot_project_dir
    godot_dir.mkdir(parents=True, exist_ok=True)

    files: dict[str, str] = {
        "project.godot": GODOT_PROJECT_FILE,
        "icon.svg": ICON_SVG,
        "scripts/main.gd": MAIN_SCRIPT,
        "scripts/weapons/weapon.gd": WEAPON_BASE_SCRIPT,
        "scripts/weapons/bumblebee_ar.gd": EXISTING_WEAPON_RIFLE,
        "scripts/monsters/shadow_monster.gd": MONSTER_BASE_SCRIPT,
        "scripts/network/player_network.gd": NETWORK_SCRIPT,
        "scripts/autoload/weapons_registry.gd": WEAPONS_REGISTRY,
        "scripts/autoload/monsters_registry.gd": MONSTERS_REGISTRY,
        "scenes/main.tscn": MAIN_SCENE,
    }

    for rel_path, content in files.items():
        full = godot_dir / rel_path
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(content, encoding="utf-8")
        print(f"  [godot] {rel_path} ({len(content)} bytes)")


def main() -> None:
    print("=" * 60)
    print("FOSTAS OS — Seeding Knowledge Base & Godot Project")
    print("=" * 60)
    print("\n[1/2] Seeding knowledge base...")
    seed_knowledge()
    print("\n[2/2] Seeding Godot sample project...")
    seed_godot_project()
    print("\n" + "=" * 60)
    print("DONE. FOSTAS OS is ready to boot.")
    print("=" * 60)


if __name__ == "__main__":
    main()
