"""
FOSTAS OS — Global Configuration

Loads settings from environment variables (.env file).
NEVER hardcode API keys. All secrets come from env.
"""
from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path
from typing import List

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


# Project root: FOSTAS_OS/
ROOT_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """Application settings loaded from environment."""

    model_config = SettingsConfigDict(
        env_file=str(ROOT_DIR / ".env"),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ---- API Keys ----
    zai_api_key: str = Field(default="", alias="ZAI_API_KEY")
    gemini_api_key: str = Field(default="", alias="GEMINI_API_KEY")
    tripo_api_key: str = Field(default="", alias="TRIPO_API_KEY")

    # ---- Provider Modes ----
    zai_real: bool = Field(default=True, alias="ZAI_REAL")
    gemini_real: bool = Field(default=True, alias="GEMINI_REAL")
    tripo_real: bool = Field(default=False, alias="TRIPO_REAL")

    # ---- Server ----
    backend_host: str = Field(default="0.0.0.0", alias="BACKEND_HOST")
    backend_port: int = Field(default=8000, alias="BACKEND_PORT")
    frontend_port: int = Field(default=8501, alias="FRONTEND_PORT")

    # ---- Paths (resolved relative to ROOT_DIR) ----
    workspace_dir_name: str = Field(default="workspace", alias="WORKSPACE_DIR")
    knowledge_dir_name: str = Field(default="knowledge", alias="KNOWLEDGE_DIR")
    cache_dir_name: str = Field(default="cache", alias="CACHE_DIR")
    downloads_dir_name: str = Field(default="downloads", alias="DOWNLOADS_DIR")
    uploads_dir_name: str = Field(default="uploads", alias="UPLOADS_DIR")
    logs_dir_name: str = Field(default="logs", alias="LOGS_DIR")
    godot_project_dir_name: str = Field(default="godot", alias="GODOT_PROJECT_DIR")

    # ---- Godot CLI ----
    godot_bin: str = Field(default="", alias="GODOT_BIN")

    # ---- Multi-project switcher ----
    # When set (by /api/projects/switch), overrides godot_project_dir to point
    # at the user-selected project under workspace/projects/<name>.
    # Not a Field — set as a plain attribute after Settings instantiation.
    godot_project_override: Path | None = None

    # ---- Limits ----
    max_download_size_mb: int = Field(default=100, alias="MAX_DOWNLOAD_SIZE_MB")
    max_upload_size_mb: int = Field(default=100, alias="MAX_UPLOAD_SIZE_MB")
    max_log_file_size_mb: int = Field(default=10, alias="MAX_LOG_FILE_SIZE_MB")

    # ---- Cache ----
    cache_ttl_hours: int = Field(default=24, alias="CACHE_TTL_HOURS")

    # ---- Security ----
    cors_origins: str = Field(
        default="http://localhost:8501,http://localhost:8000",
        alias="CORS_ORIGINS",
    )
    auth_enabled: bool = Field(default=False, alias="AUTH_ENABLED")
    fostas_api_key: str = Field(default="", alias="FOSTAS_API_KEY")
    rate_limit_enabled: bool = Field(default=True, alias="RATE_LIMIT_ENABLED")
    rate_limit_per_minute: int = Field(default=120, alias="RATE_LIMIT_PER_MINUTE")
    max_request_body_size_mb: int = Field(default=10, alias="MAX_REQUEST_BODY_SIZE_MB")

    # ---- Performance ----
    cache_lru_max_entries: int = Field(default=512, alias="CACHE_LRU_MAX_ENTRIES")

    # ---- Derived (computed) ----
    @property
    def workspace_dir(self) -> Path:
        return ROOT_DIR / self.workspace_dir_name

    @property
    def knowledge_dir(self) -> Path:
        return ROOT_DIR / self.knowledge_dir_name

    @property
    def cache_dir(self) -> Path:
        return ROOT_DIR / self.cache_dir_name

    @property
    def downloads_dir(self) -> Path:
        return ROOT_DIR / self.downloads_dir_name

    @property
    def uploads_dir(self) -> Path:
        return ROOT_DIR / self.uploads_dir_name

    @property
    def logs_dir(self) -> Path:
        return ROOT_DIR / self.logs_dir_name

    @property
    def godot_project_dir(self) -> Path:
        # Multi-project switcher: if an override is set, use it; otherwise
        # fall back to the default `godot/` directory at the project root.
        if self.godot_project_override is not None:
            return self.godot_project_override
        return ROOT_DIR / self.godot_project_dir_name

    @property
    def cors_origins_list(self) -> List[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def godot_binary(self) -> str | None:
        """Resolve Godot binary path. Returns None if not installed."""
        if self.godot_bin:
            return self.godot_bin
        # Auto-detect common install paths
        import shutil
        for name in ("godot4", "godot"):
            path = shutil.which(name)
            if path:
                return path
        return None

    @field_validator("zai_real", "gemini_real", "tripo_real", mode="before")
    @classmethod
    def _parse_bool(cls, v):
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            return v.strip().lower() in ("true", "1", "yes", "y")
        return bool(v)

    @field_validator("auth_enabled", "rate_limit_enabled", mode="before")
    @classmethod
    def _parse_bool_security(cls, v):
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            return v.strip().lower() in ("true", "1", "yes", "y")
        return bool(v)

    def ensure_directories(self) -> None:
        """Create all required directories if they don't exist."""
        for d in (
            self.workspace_dir,
            self.knowledge_dir,
            self.cache_dir,
            self.downloads_dir,
            self.uploads_dir,
            self.logs_dir,
            self.godot_project_dir,
        ):
            d.mkdir(parents=True, exist_ok=True)

    def validate_api_keys(self) -> list[str]:
        """Validate that every provider in REAL mode has its API key set.

        Returns a list of human-readable error messages. Empty list = OK.

        This is called at startup (run.py + backend/main.py) and the process
        REFUSES TO START if any error is returned — preventing silent fallback
        to mock mode when the user intended real mode.

        Per security requirements:
          - NEVER prints the API keys themselves
          - Only reports which provider is missing its key
          - Suggests the env var name to set
        """
        errors: list[str] = []

        if self.zai_real and not self.zai_api_key:
            errors.append(
                "Z.AI is set to REAL mode (ZAI_REAL=true) but ZAI_API_KEY is "
                "missing or empty. Either set ZAI_API_KEY in your .env file, "
                "or set ZAI_REAL=false to use mock mode."
            )

        if self.gemini_real and not self.gemini_api_key:
            errors.append(
                "Google Gemini is set to REAL mode (GEMINI_REAL=true) but "
                "GEMINI_API_KEY is missing or empty. Either set GEMINI_API_KEY "
                "in your .env file, or set GEMINI_REAL=false to use mock mode."
            )

        if self.tripo_real and not self.tripo_api_key:
            errors.append(
                "Tripo AI is set to REAL mode (TRIPO_REAL=true) but "
                "TRIPO_API_KEY is missing or empty. Either set TRIPO_API_KEY "
                "in your .env file, or set TRIPO_REAL=false to use mock mode."
            )

        # Auth-enabled but no FOSTAS_API_KEY
        if self.auth_enabled and not self.fostas_api_key:
            errors.append(
                "Auth is enabled (AUTH_ENABLED=true) but FOSTAS_API_KEY is "
                "missing or empty. Set FOSTAS_API_KEY in your .env file to "
                "a strong random string, or set AUTH_ENABLED=false."
            )

        return errors

    def mask_api_keys(self) -> dict[str, str]:
        """Return a masked summary of all API keys for safe logging/display.
        Per security requirements: NEVER returns the actual key values."""
        def _mask(key: str) -> str:
            if not key:
                return "EMPTY"
            if len(key) <= 8:
                return "***"
            return f"***...{key[-4:]}"

        return {
            "ZAI_API_KEY": _mask(self.zai_api_key),
            "GEMINI_API_KEY": _mask(self.gemini_api_key),
            "TRIPO_API_KEY": _mask(self.tripo_api_key),
            "FOSTAS_API_KEY": _mask(self.fostas_api_key),
        }


class ConfigurationError(RuntimeError):
    """Raised when required configuration (API keys, etc.) is missing.
    The process should refuse to start when this is raised."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        msg = "FOSTAS OS configuration error(s):\n" + "\n".join(f"  - {e}" for e in errors)
        super().__init__(msg)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Cached settings singleton."""
    s = Settings()
    s.ensure_directories()
    return s


def validate_configuration_or_exit() -> None:
    """Validate configuration at startup. Raises ConfigurationError if any
    provider in REAL mode is missing its API key.

    Called by run.py and backend/main.py before the server starts.
    Prints a clear error message and exits with code 1 if validation fails.
    """
    settings = get_settings()
    errors = settings.validate_api_keys()
    if errors:
        print("=" * 60, file=sys.stderr)
        print("FOSTAS OS — STARTUP CONFIGURATION ERROR", file=sys.stderr)
        print("=" * 60, file=sys.stderr)
        print("", file=sys.stderr)
        print("The following required configuration is missing:", file=sys.stderr)
        print("", file=sys.stderr)
        for e in errors:
            print(f"  ❌ {e}", file=sys.stderr)
        print("", file=sys.stderr)
        print("To fix:", file=sys.stderr)
        print("  1. Copy .env.example to .env (if not done):  cp .env.example .env", file=sys.stderr)
        print("  2. Edit .env and fill in the missing API keys", file=sys.stderr)
        print("  3. Or set the corresponding *_REAL=false to use mock mode", file=sys.stderr)
        print("", file=sys.stderr)
        print("FOSTAS OS refuses to start with missing configuration.", file=sys.stderr)
        print("=" * 60, file=sys.stderr)
        raise ConfigurationError(errors)
