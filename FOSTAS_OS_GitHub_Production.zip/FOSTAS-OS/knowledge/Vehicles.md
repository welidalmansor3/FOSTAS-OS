# FOSTAS Vehicles System

## Design Philosophy

FOSTAS: Toybox Terror is primarily a 5v5 infantry FPS, but vehicles appear as map objectives and event rewards. All vehicles use the stylized toy aesthetic — bright plastic colors, oversized wheels, cartoon proportions. Vehicles are intentionally rare (1–2 per match) to keep the focus on infantry combat; they serve as force multipliers for the team that controls them.

## Toy Kart (Map Objective)

- Spawns once per round at the mid-field playground center.
- 2 seats: driver + gunner.
- Driver: WASD movement, Boost (Shift — 3-second burst, 10 s cooldown).
- Gunner: Toy Blaster turret (infinite ammo, 300 RPM, 15 DMG).
- HP: 200 (destroyed → respawns after 60 s at the same spawn point).
- Speed: 12 m/s normal, 18 m/s boost.
- Model: original Kart GLB (not in 11-weapon manifest — must be sourced or modeled separately; not in the iq-free.zip asset pack).
- Use case: fast rotation between castles; gunner provides suppressive fire onArtifact carrier's lane.

## Toy Tank (FOSTAS Event Reward)

- Spawns for the team that kills the most Shadow Monsters during the Hunt phase (tie → no tank for either team).
- 1 driver, 1 gunner.
- Main cannon: 150 DMG, 4 RPM, 100 m range, splash radius 5 m.
- Coaxial MG: 25 DMG, 600 RPM.
- HP: 500.
- Speed: 6 m/s (slower than sprint — vulnerable to flanking).
- Limited duration: 60 seconds, then despawns (prevents stalemate via tank camping).
- Use case: post-Hunt push to break a tied round; main cannon can clear a castle interior in 2 shots.

## Toy Helicopter (Rare Pickup)

- Spawns at a random rooftop every 3 minutes.
- 1 pilot, 1 gunner.
- Pilot: WASD + Space/Ctrl for altitude.
- Gunner: dual Toy Blasters (300 RPM each, 12 DMG).
- HP: 150.
- Flight time: unlimited until destroyed.
- Fuel: NONE (simplified for arcade feel — gameplay over realism).
- Use case: aerial reconnaissance + gunner suppresses enemy ramparts; vulnerable to Star Sniper / Whisper Sniper from tower.

## Vehicle Damage Model

- Vehicles use a single HP pool (not the Hardcore limb system — they are machines).
- Vehicle damage is unaffected by the ×4 headshot multiplier (no head).
- Vehicles take full damage from: main cannon, plasma carbine, all shotguns (close range), LMG (sustained fire).
- Vehicles take reduced damage (×0.5) from: SMG, sidearm pistol, spell VFX.
- Vehicles are immune to: potion effects (Speed/Rage potions don't buff vehicles), bounty rune (vehicles don't get killstreaks).
- Vehicle destruction: 3-second explosion VFX, 5 m splash damage (50 DMG to infantry in radius), then despawn.

## Vehicle Networking

- Vehicle positions are server-authoritative (same as players).
- Driver inputs are sent at 60 Hz (same as player inputs).
- Vehicle snapshots are broadcast at 20 Hz (same as players).
- Vehicle entry/exit is a reliable RPC (`@rpc("any_peer", "call_local", "reliable")`).
- Server validates entry (only one driver + one gunner per vehicle; nearest player to entry point gets the seat).

## Missing Assets for Vehicles (P2 — not in iq-free.zip)

- Toy Kart model (must be sourced or modeled — ~5K tris, 4 wheels, 2 seats).
- Toy Tank model (must be sourced or modeled — ~10K tris, treads, turret, 2 seats).
- Toy Helicopter model (must be sourced or modeled — ~8K tris, main rotor + tail rotor, 2 seats).
- Vehicle SFX: engine idle/rev, turret rotation, cannon fire, helicopter rotor wash, vehicle explosion.
- Vehicle VFX: muzzle flash for turret, cannon shell trail, rotor wash dust, explosion fireball.

## Adding a New Vehicle via FOSTAS OS

1. Create `godot/scripts/vehicles/<vehicle_name>.gd` extending `VehicleBody3D` (for physics-based) or `RigidBody3D` (for arcade-style).
2. Define `@export` stats: `max_speed`, `hp`, `seats`, `weapons`, `duration_seconds` (optional).
3. Implement `_physics_process()` for movement (use `apply_central_force()` for arcade feel).
4. Add driver/gunner input mapping (driver: WASD + Space/Ctrl; gunner: mouse + LMB).
5. Implement `enter(player, seat)` and `exit(seat)` server-validated RPCs.
6. Create matching `.tscn` scene with model + collision shapes + entry-point markers.
7. Register in `godot/autoload/vehicles_registry.gd`.
8. Add a spawn point to the map (mid-field for Kart, rooftop for Helicopter, post-Hunt for Tank).
