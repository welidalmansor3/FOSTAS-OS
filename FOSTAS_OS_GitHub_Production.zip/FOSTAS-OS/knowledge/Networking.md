# FOSTAS Multiplayer Networking

## Architecture

- **Dedicated-server authoritative** (standard competitive FPS architecture).
- Server tick rate: 20 Hz (50 ms per tick).
- Client input rate: 60 Hz.
- Snapshot interpolation: 100 ms buffer (3 snapshots at 20 Hz).
- Lag compensation: 200 ms rewind window for hit validation.
- Reconnect window: 90 seconds after disconnect.

The networking stack is server-authoritative: the server runs the full game simulation at 20 Hz and is the single source of truth for all gameplay state. Clients send inputs at 60 Hz and interpolate between server snapshots. No client trust — every action (movement, fire, spell cast, item use) is validated server-side before being applied. This is the correct architecture for a competitive FPS with monetized cosmetics (anti-cheat is monetization-protective).

## Server Authority

- Server runs full game simulation at 20 Hz.
- Clients send inputs (movement, look, fire) at 60 Hz.
- Server validates all actions (no client trust):
  - Movement: server checks against NavMesh, max speed, no-clip prevention.
  - Fire: server validates fire rate, ammo, line-of-sight at fire time (with lag comp).
  - Spell cast: server validates cooldown, quest completion, Soul Contract penalty.
  - Item use: server validates carry limit, cooldown, line-of-sight to target.
- Server broadcasts world snapshots at 20 Hz.
- Clients interpolate between snapshots (100 ms buffer = 3 snapshots).

## Hit Validation (Lag Compensation)

- Client fires → predicts hit locally (immediate visual feedback).
- Client sends fire event to server with their position + direction at fire time.
- Server rewinds world state by up to 200 ms (using its own snapshot history).
- Server validates shot from client's perspective at fire time.
- If hit confirmed server-side, damage applied to target.
- If miss, no rollback needed (client prediction was wrong; target is unharmed).
- **Clamp**: rewind window = `min(client_ping, 200 ms)`. Reject shots from clients with ping > 300 ms (kicks back to lobby with "high ping" warning).
- **Anti-cheat**: server rejects impossible fire rates (e.g. 1000 RPM weapon firing at 2000 RPM), impossible headshot ratios (statistical outlier detection over 30 s window), and impossible movement speeds.

## Client-Side Prediction

- **Movement**: client predicts own position using input + local physics, server corrects if mismatch.
- **Reconciliation**: client rewinds to server-confirmed state, replays buffered inputs (last 200 ms = 12 inputs at 60 Hz).
- **Visual smoothing**: 0.1 s lerp to avoid rubber-banding on minor corrections (< 0.5 m tolerance). Hard teleport on major corrections (> 0.5 m) to prevent exploit of correction lag.
- **Implementation reference**: `godot/scripts/network/player_network.gd` provides the canonical pattern (input buffer, snapshot buffer, interpolation, reconciliation, server correction).

## Snapshot Interpolation

- Buffer 3 snapshots (150 ms) before rendering.
- Linear interpolation between snapshots for position; slerp for rotation.
- Extrapolation cap: 100 ms (then freeze entity — prevents ghost players running into walls).
- Snapshot priority by proximity: closer players get higher update rate; distant players downsampled.

## Snapshot Compression (Network Optimization)

- **Delta compression**: send only changes from last acknowledged snapshot per client.
- **Position quantization**: 16-bit per axis (±327 m, 1 mm precision) — sufficient for 252 m × 112 m × 60 m map.
- **Rotation quantization**: quaternion packed in 32 bits (smallest-three encoding).
- **Bandwidth budget**:
  - Server → client: 64 Kbps per client (10 clients = 640 Kbps server upload).
  - Client → server: 16 Kbps per client (inputs only).
- **Re-sync**: server broadcasts full state every 5 seconds (handles missed snapshots and deterministic physics divergence).

## FOSTAS Event Networking (most fragile subsystem)

The FOSTAS event is the project's signature mechanic and the most network-sensitive subsystem. Frame-accurate phase timing across 12 clients with up to 200 ms lag-comp window is fragile.

- Server rolls trigger time at match start (random 1:30–6:30, once per match) and stores it in the match-state.
- Server broadcasts all phase transitions as reliable events with **match-time-clock timestamps** (not wall-clock — prevents drift under packet loss).
- Clients schedule phase transitions on local match-time clock (synced from server at match start, drift-corrected every 5 s).
- Phase transitions:
  - **Phase 1 Blackout (0.4 s)** — all clients blackout simultaneously (server-broadcast event).
  - **Phase 2 Warning (1.0 s)** — all clients see warning text.
  - **Phase 3 Hunt (20 s)** — server spawns 5 monsters at server-rolled positions, broadcasts positions, clients instantiate locally; monster AI runs server-side, positions broadcast at 20 Hz.
  - **Phase 4 Recovery (2 s)** — all clients fade back to cute palette; match state preserved.
- If a client disconnects mid-event and reconnects within 90 s, it re-syncs to the current phase via match-time clock; if past Phase 3, it sees only the post-event state (no replay).
- Integration test under simulated 50/100/200/250 ms pings is mandatory before Gate 7 passes.

## Reconnect Window

- 90 seconds after disconnect.
- Client reconnects with same session token; server restores state from last snapshot (limb HP, ammo, position, quest progress).
- If 90 s elapsed, slot is released to a bot or backfill player; original client rejoins as spectator next round.
- Reconnect does NOT preserve FOSTAS event state — reconnected clients see only post-event state if event has ended.

## Anti-Cheat (Server-Side Rule-Based)

Server-side anti-cheat is sufficient for a server-authoritative model; no client-side anti-cheat is required (and would be bypassable anyway). The server enforces:

- **Fire-rate hack rejection**: server tracks last-fire-time per weapon; rejects fire events that arrive faster than weapon's RPM allows (with 5 ms tolerance for clock skew).
- **Speed hack rejection**: server tracks position delta per tick; rejects movement events that exceed max move speed × delta × 1.1 (10% tolerance for interpolation).
- **Spell-cooldown hack rejection**: server tracks spell last-cast-time per Mage; rejects spell-cast events that arrive during cooldown (with 50 ms tolerance for clock skew).
- **Headshot ratio anomaly detection**: statistical outlier check over 30 s sliding window — flag players with headshot ratio > 90% for review (not auto-ban; false positive risk too high).
- **Wallhack mitigation**: server does not broadcast enemy positions to clients that don't have line-of-sight (occlusion-aware snapshot filtering — expensive, optional for v1).
- **Gate 9 acceptance**: anti-cheat rejects a fire-rate hack, a speed hack, and a spell-cooldown hack in unit tests.

## Common Issues & Fixes

### Lag / Rubber-banding
- **Symptom**: players teleport, hit registration feels off.
- **Root cause**: snapshot interpolation buffer underrun, or client prediction mismatch.
- **Fix**: increase interpolation buffer to 150 ms, add input delta compression, validate movement server-side with tolerance window.

### Desync
- **Symptom**: clients see different world states.
- **Root cause**: missed snapshots, deterministic physics divergence.
- **Fix**: server broadcasts full state every 5 s (re-sync), client rewinds and replays.

### High Ping Player
- **Symptom**: lag compensation abused (getting shot around corners).
- **Root cause**: 200 ms rewind window too generous for 300 ms+ ping players.
- **Fix**: clamp rewind to `min(client_ping, 200 ms)`, reject shots from ping > 300 ms.

### FOSTAS Event Drift
- **Symptom**: phase transitions visible at different times on different clients.
- **Root cause**: wall-clock scheduling drift under packet loss.
- **Fix**: schedule on match-time clock (synced from server, drift-corrected every 5 s), not wall-clock.

## Adding New Network Features via FOSTAS OS

1. Define RPC in `godot/scripts/network/rpc_manager.gd`.
2. Use `@rpc("any_peer", "call_local", "reliable")` for state changes (FOSTAS phase transitions, spell casts, item pickups).
3. Use `@rpc("any_peer", "unreliable")` for high-frequency updates (movement, look) — these are delta-compressed.
4. Server validates all peer requests before applying; never trust client state.
5. Add a `NetworkManager` autoload at `/root/NetworkManager` (project.godot) that exposes `register_local_player(player)` and routes snapshots / corrections. `player_network.gd:_ready()` calls this on the local player.
