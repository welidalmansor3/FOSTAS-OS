# FOSTAS Weapons System

## Toy Reskin Pipeline (8 steps, applied to all imported weapon GLTFs)

1. Load imported GLTF as-is (no re-modeling).
2. Swap every metallic/dark material for `PlasticToy` material.
3. Apply `team_color_override` (RED: `#E63946`, BLUE: `#1D6FB8`).
4. Replace muzzle flash with toy sparkle particle (team-color plasma burst, 0.08 s, scale 0.2 → 0.6 → 0).
5. Replace bullet tracer with candy-colored streak (1 m, additive, fades over 0.3 s).
6. Add subtle cartoon outline shader (the `Outline_001` material from `soldat_low_poly` is the project's reference).
7. **Normalize scale to 1 m bounding-box longest axis** (source assets range from 0.38 m to 604 m — see Scale Normalization table below).
8. Attach `Toy Blaster Pistol` as universal sidearm (Last-Stand-prone-fire uses sidearm only).

## Damage Model

- Headshot: ×4 (×12 with Mage's Weapon Enchantment Tier-2 active)
- Torso: ×1
- Limb: ×0.75
- TTK target: 0.3–0.8 s at optimal range (0.25 floor, 1.2 ceiling)

## Weapon Manifest (11 imported GLTFs — corrected from dev report Appendix A)

The dev report's audit of the actual `iq-free.zip` asset pack confirmed the authoritative 11 weapons. The earlier manifest listing `Party Popper` (tactical_shotgun) and `Balloon Bomber` (gl6) was incorrect — those GLTFs are not in the pack. The correct list is:

| # | Folder | Real Weapon | In-Game Toy Name | Slot | DMG | RPM | Mag | Range | License |
|---|--------|-------------|------------------|------|-----|-----|-----|-------|---------|
| 1 | low-poly_aug_a1 | Steyr AUG A1 (bullpup AR) | BumbleBee AR | AR | 22 | 700 | 30 | 60 m | CC-BY-4.0 |
| 2 | low-poly_fn_arka | FN ARKA / AR-15 | Plasma Carbine | BR | 28 | 600 | 30 | 80 m | CC-BY-4.0 |
| 3 | low-poly_hk_mr762 | H&K MR762 (DMR) | Laser Marksman | DMR | 55 | 300 | 20 | 120 m | CC-BY-4.0 |
| 4 | low-poly_kriss_vector | KRISS Vector (SMG) | BuzzBee SMG | SMG | 16 | 1100 | 25 | 25 m | CC-BY-4.0 |
| 5 | low-poly_pp-19_vityaz-sn | PP-19 Vityaz-SN | Hornet SMG | SMG | 18 | 800 | 30 | 30 m | CC-BY-4.0 |
| 6 | low-poly_psl_rifle | PSL (Romanian DMR) | Star Sniper | Sniper | 110 (HS one-shot) | 60 | 10 | 200 m | CC-BY-4.0 |
| 7 | low-poly_rpk-74n | RPK-74N (LMG) | Stinger LMG | LMG | 24 | 600 | 75 | 80 m, bipod | CC-BY-4.0 |
| 8 | low-poly_saiga_410 | Saiga-410 (semi shotgun) | Confetti Cannon | Shotgun | 12×8 pellets | 200 | 8 | 15 m | CC-BY-4.0 |
| 9 | low-poly_six_12 | Six12 (cylinder shotgun) | Bubble Blaster | Shotgun | 14×6 pellets | 240 | 6 | 18 m | CC-BY-4.0 |
| 10 | low-poly_sko-12 | SKO-12 (bullpup shotgun) | Pop-Pop-12 | Shotgun | 13×7 pellets | 180 | 10 | 16 m | CC-BY-4.0 |
| 11 | low-poly_vsk-94 | VSK-94 (suppressed sniper) | Whisper Sniper | Suppressed Sniper | 75 | 90 | 20 | 150 m, suppressed | CC-BY-4.0 |

## Universal Sidearm (NOT from imported GLTF)

**Toy Blaster Pistol**: single low-poly mesh ~3K tris, toy plastic, every class spawns with it. DMG 12, RPM 300, Mag 10, Range 20 m, infinite reserve. Used during Last-Stand prone state. Must be modeled from scratch (no source GLTF in pack). Team-colored emissive plastic, 1st-person + 3rd-person variants required.

## Scale Normalization (per Appendix A technical inventory)

All 11 weapon GLTFs were authored at wildly inconsistent scales. The table below shows the source bounding box and the required normalization multiplier. Apply uniformly via `MeshInstance3D` scale on import.

| Folder | Source BBox (m) | Source Longest Axis | Target Longest | Multiplier |
|--------|----------------|---------------------|----------------|------------|
| low-poly_aug_a1 | 55.8 × 29.1 × 19.2 | 55.8 | 1.0 | 0.0179 |
| low-poly_fn_arka | 4.7 × 2.1 × 0.7 | 4.7 | 1.0 | 0.213 |
| low-poly_hk_mr762 | 6.3 × 2.0 × 0.7 | 6.3 | 1.0 | 0.159 |
| low-poly_kriss_vector | 22.0 × 21.8 × 9.2 | 22.0 | 1.0 | 0.0455 |
| low-poly_pp-19_vityaz-sn | 0.4 × 1.8 × 3.9 | 3.9 | 1.0 | 0.256 |
| low-poly_psl_rifle | 604 × 17 × 123 | 604 ⚠ | 1.0 | 0.00166 (clearly source-unit error) |
| low-poly_rpk-74n | 0.5 × 1.8 × 5.5 | 5.5 | 1.0 | 0.182 |
| low-poly_saiga_410 | 53.9 × 16.2 × 7.5 | 53.9 | 1.0 | 0.0186 |
| low-poly_six_12 | 64.4 × 17.2 × 8.4 | 64.4 | 1.0 | 0.0155 |
| low-poly_sko-12 | 62.1 × 15.0 × 6.5 | 62.1 | 1.0 | 0.0161 |
| low-poly_vsk-94 | 0.4 × 1.4 × 5.9 | 5.9 | 1.0 | 0.169 |

⚠ The PSL rifle's 604 m bounding box is almost certainly a source-unit error in the GLTF (likely authored in centimeters and exported as meters). Visual inspection confirms the model is roughly 1 m long. Apply the multiplier above and verify in-editor; do not trust the source scale.

## Critical Gaps (P1 + P2 from Risk Register)

- **All 11 weapon GLTFs ship with ZERO animations** — must author reload/fire/inspect/ADS-in/ADS-out/idle/Last-Stand-prone-fire for all 11 + sidearm pistol, for both 1st-person viewmodel (~3K tris) and 3rd-person body (~8K tris). Estimated 132+ clips.
- **Scale normalization required** — bounding boxes range from 0.38 m (PP-19) to 604 m (PSL — source error); see table above.
- **Material name drift** — GLTF material names (`02___Default`, `Outline_001`, `Material.001`) don't map cleanly to PlasticToy. Need a name-normalization pass during import (rename to `PlasticToy_<weapon>` + apply team_color_override uniform).
- **Universal Sidearm mesh missing** — Toy Blaster Pistol has no source GLTF. Must be modeled (~500 tris, team-colored emissive plastic, 1st-person + 3rd-person variants).
- **Muzzle flash plasma burst mesh missing** — 0.08 s team-colored plasma burst (sphere mesh, additive shader, scale 0.2 → 0.6 → 0).
- **Plasma tracer trail mesh missing** — team-colored, 1 m long, additive, fades over 0.3 s. Used by both projectile and hitscan weapons.
- **1st-Person arm rig meshes missing** — Medic arms (red/blue sleeves + white cross armband), Mage arms (red/blue sleeves + arcane rune armband). Required for all weapon viewmodel rendering.

## Animation Set Required per Weapon

For each of the 11 weapons + sidearm pistol, the following 8 clips × 2 rigs (1st-person viewmodel + 3rd-person body) = 16 clips per weapon × 12 weapons = **192 clips total** (revised upward from earlier 132 estimate to account for sidearm and Last-Stand-prone-fire on every weapon):

1. `idle` (loop)
2. `fire` (single-shot, blends back to idle)
3. `reload` (full + tactical variants where applicable)
4. `swap_in` (equip animation)
5. `inspect` (cosmetic)
6. `ads_in` (aim-down-sights raise)
7. `ads_out` (lower)
8. `last_stand_prone_fire` (prone, sidearm only)

## Adding a New Weapon via FOSTAS OS

1. Create `godot/scripts/weapons/<weapon_name>.gd` extending `Weapon` base class.
2. Define `@export` stats matching the manifest table above.
3. Implement `fire()`, `reload()`, `_physics_process()` (or rely on parent's).
4. Create matching `.tscn` scene with model placeholder.
5. Register in `godot/autoload/weapons_registry.gd`.
6. Verify via the orchestrator's validation step (Godot CLI syntax check).
