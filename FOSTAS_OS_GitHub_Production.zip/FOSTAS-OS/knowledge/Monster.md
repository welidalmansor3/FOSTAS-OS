# FOSTAS Monster System

## Shadow Monster (FOSTAS Event creature)

- Asset: `decraniated_low_poly_retro_pixel` (1 mesh, 1 skin, 1 animation — likely idle).
- Re-shaded to pure black (`#0A0A0F`) with red emissive eyes (`#FF0000`).
- 5 instances spawn during the 20-second Hunt phase.
- AI-driven: state machine IDLE → WANDER → CHASE → ATTACK → DEAD (see `godot/scripts/monsters/shadow_monster.gd`).
- HP: 100 (respawns after 5 s if destroyed — cannot be permanently killed during Hunt).
- Speed: 5 m/s (slightly slower than player sprint of 6 m/s).
- Attack: melee, 25 DMG per hit, 1.0 s cooldown. Attack is a one-shot kill on caught players during Hunt phase (per master prompt — jumpscare kill).
- Detection range: 15 m, FOV 180°.
- Scale: 1.8 × 2.0 × 0.4 m (source); apply ×1.4 multiplier for final in-game scale (2.5 × 2.8 × 0.56 m) to tower over players.

## FOSTAS Event Phases (4-phase, server-authoritative)

The FOSTAS event is the project's signature mechanic and the most network-sensitive subsystem. All phase transitions are scheduled on the **match-time clock** (server-tracked, frame-accurate), not wall-clock — this ensures all 12 clients observe identical phase boundaries even under 200 ms lag compensation.

### Phase 1 — Blackout (0.4 s)
- Every player's screen snaps to pure black simultaneously (server-broadcast phase-start packet).
- Cute ambient music cuts to dead silence.
- All team VOIP mutes.
- No fade — sudden and total.
- Skybox lerps from "playground blue" → "void black" over the 0.4 s.

### Phase 2 — Warning (1.0 s)
- Massive blood-red glowing text appears centered on every player's screen: "FOSTAS MONSTER IS COMING! HIDE!"
- Heavy sub-bass rumble plays (single sustained note).
- VOIP remains muted.
- Black screen fades to reveal horror-phase lighting (real-time GI, point-lights disabled).

### Phase 3 — Hunt (20 s)
- 5 Shadow Monsters spawn from server-rolled random courtyard points (positions broadcast at phase start; clients instantiate locally).
- Players debuffed: −15% movement speed (panic slow), screen-shake ×3, minimap disabled, VOIP muted.
- Monsters hunt players via state machine; players can fight back but monster respawns after 5 s.
- Tactical Mage's `Soul Harvest` Tier-3 can clear monsters in 30 m radius (once per round, 240 s cooldown).
- Max 8 dynamic lights per frame during Hunt (5 monster point-lights + 3 reserved for spell VFX).

### Phase 4 — Recovery (2 s)
- Screen fades back to cute palette.
- Sun returns, ambient music resumes (cute stem).
- Match continues from where interrupted (round timer, artifact state, bleed-outs, limb HP all preserved).
- Monsters dissolve-death VFX; no monster persists into cute phase.

## Lighting Transition

- 0.4 s lerp from baked cute-phase GI to real-time horror-phase GI.
- Cold point-light follows each shadow monster (single light per monster, no shadow casting — perf cost too high).
- Rest of map is in darkness during Hunt.
- Max 8 dynamic lights per frame (5 monster + 3 reserved).

## Adaptive Music (4 stems)

- **Cute base**: ~120 BPM marimba / glockenspiel / bouncy bass.
- **Cute combat**: same tempo + percussion layer, triggered when player is in combat within 5 s.
- **Horror base**: industrial drone + low brass + detuned piano stabs + sub-bass.
- **Horror combat**: horror base + percussive hits, triggered during Hunt when monster is within 10 m of any player.
- 0.5 s crossfades between stems.
- During FOSTAS event: silence at Phase 1 (cut), sub-bass rumble at Phase 2 (single note), horror combat stem at Phase 3, fade back to cute at Phase 4.

## Network Replication (most fragile subsystem)

- Server rolls FOSTAS trigger time at match start (random 1:30–6:30, once per match).
- Server broadcasts all phase transitions as reliable events with match-time-clock timestamps.
- Clients schedule phase transitions on local match-time clock (synced from server), not wall-clock — prevents drift under packet loss.
- Monster spawn positions are server-rolled at Phase 3 start; clients instantiate from a network scene + apply server-broadcast transforms.
- Monster AI runs server-side; clients receive monster position snapshots at 20 Hz and interpolate.
- If a client disconnects mid-event and reconnects within 90 s, it re-syncs to the current phase; if past Phase 3, it sees only the post-event state (no replay).

## Required VFX + SFX (must be sourced — P2)

- **Monster motion-blur trail**: heavy motion-blur trail VFX attached to each of the 5 monster instances during Hunt.
- **Dissolve-death VFX**: when a monster is destroyed (5 s respawn) or at Phase 4.
- **Jumpscare scream**: 1.2-second piercing female scream + sub-bass drop. Full-volume on killed client, muffled-distant on others.
- **Sub-bass rumble**: 1.0 s sustained note for Phase 2 warning.
- **Skybox lerp**: 0.4 s crossfade cute → horror → 2.0 s crossfade horror → cute at Phase 4.

## Required Animations (must be authored — P1)

Shadow Monster needs 5 animation clips (source asset ships with only 1 — likely idle):
1. `idle` (loop, sourced from asset).
2. `sprint` (loop, fast arm/leg movement — for CHASE state).
3. `attack_lunge` (single, for ATTACK state trigger).
4. `jumpscare_trigger` (single, plays on caught-player kill — full-body lunge + scream).
5. `dissolve_death` (single, plays on monster destruction / Phase 4 cleanup).

## Adding a New Monster via FOSTAS OS

1. Create `godot/scripts/monsters/<monster_name>.d` extending `CharacterBody3D`.
2. Define `@export` stats: `max_health`, `move_speed`, `attack_damage`, `detection_range`, `attack_range`, `attack_cooldown`.
3. Implement state machine: IDLE → WANDER → CHASE → ATTACK → DEAD (use the `shadow_monster.gd` and `new_monster.gd` patterns as reference; do NOT rely on Area3D child nodes — use `get_tree().get_nodes_in_group("players")` for player detection).
4. Implement `take_damage(amount)` and `die()`.
5. Create matching `.tscn` scene with model placeholder.
6. Register in `godot/autoload/monsters_registry.gd`.
7. (Optional) Request 3D model generation from Tripo.
