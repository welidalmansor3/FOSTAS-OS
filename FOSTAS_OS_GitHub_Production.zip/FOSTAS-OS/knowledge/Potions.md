# FOSTAS Potions System

Potions are consumable items that grant short-duration buffs. They spawn on potions racks in each castle's courtyard and respawn every 45 seconds after pickup (max 3 per rack at any time). Potions interact with the Hardcore Injury System (limb HP pools) and the FOSTAS event (most are disabled during Hunt phase to prevent abuse).

## Healing Potion (Toy Green)
- Restores 50 HP to the **torso** limb pool (does not heal limbs; use Medic's Heal Pulse for limb healing).
- Carry limit: 2 per life.
- Use key: F.
- VFX: toy-green sparkle burst, "drink" animation on character.
- Models reuse `medkit` asset with green tint shader.
- Disabled during FOSTAS Hunt phase (cannot outheal a jumpscare kill).

## Speed Potion (Toy Yellow)
- +30% movement speed for 8 seconds (stacks with sprint, NOT with Mage's Mass Teleport debuff).
- Carry limit: 1 per life.
- Use key: G.
- VFX: yellow motion trail, cartoon dust clouds at feet.
- Cooldown after use: 5 seconds (anti-spam).
- Disabled during FOSTAS Hunt phase (panic slow debuff overrides; using Speed Potion during Hunt is wasteful).

## Rage Potion (Toy Red)
- +25% damage for 6 seconds (stacks with Artifact round-win buff, capped at +15% from that source — total max +40%).
- Carry limit: 1 per life.
- Use key: H.
- VFX: red eye glow, weapon barrel flame aura.
- Risk: highlights user on enemy minimap (visible during cute phase only — minimap disabled during FOSTAS Hunt).
- Pairs well with high-fire-rate weapons (BuzzBee SMG, Hornet SMG) for maximum damage-per-second during the 6-second window.

## Invisibility Potion (Toy Blue)
- 4 seconds of 90% transparency (faint shimmer on movement visible to alert enemies).
- Carry limit: 1 per life.
- Use key: J.
- VFX: blue dissolve effect, faint shimmer on movement.
- Breaks on damage dealt OR damage taken (any limb hit breaks invisibility).
- Use case: flank behind enemy castle during Artifact carry; evade bounty-rune hunters.
- Disabled during FOSTAS Hunt phase (Shadow Monsters detect by sound, not sight — invisibility is useless).

## Potion Spawn Rules
- Spawn at fixed map points (potions rack in each castle's courtyard).
- Respawn every 45 seconds after pickup.
- Maximum 3 potions per rack at any time.
- Both teams have equal access to their own rack (no cross-team theft).
- Potion type per rack slot is randomized on each respawn (1 of 4 types, weighted: Healing 40%, Speed 25%, Rage 20%, Invisibility 15%).

## FOSTAS Event Interaction

- All potions except Healing are disabled during FOSTAS Hunt phase (using one during Hunt wastes the cooldown with no effect).
- Healing Potion is also disabled during Hunt (cannot outheal a jumpscare kill).
- The 45-second respawn timer continues during Hunt — when Hunt ends (Phase 4), the rack may immediately restock.
- Potions in a player's inventory at death are dropped at the death location (can be picked up by any player, including enemies — risk/reward for being a potion hoarder).

## Adding a New Potion via FOSTAS OS

1. Create `godot/scripts/items/<potion_name>.gd` extending `Item` base class.
2. Define `@export` stats: `effect_type`, `magnitude`, `duration`, `carry_limit`, `cooldown`.
3. Implement `use(player)` method that applies the effect (server-side validation required).
4. Implement `is_disabled_during_fostas()` returning `true` for combat-affecting potions.
5. Register in `godot/autoload/items_registry.gd`.
6. Add a spawn point to the map's potions rack.
