# FOSTAS Maps System

## Primary Map — Castle Wars

Assembled from TWO imported GLTFs:

### Base: `castle_wars_pavlov_vr/scene.gltf`
- 19 meshes, 21 nodes, 19 materials, 5 textures
- Bounding box: 137 m × 40 m × 18.7 m
- Two opposing castles: AlliesC.001 → RED, AxisC → BLUE
- Each castle has 3 floors: courtyard gate, ramparts, sniper tower
- Disk size: 731 KB
- ⚠ **LICENSE: CC-BY-NC-SA-4.0 — NON-COMMERCIAL Share-Alike. P0 BLOCKER for Steam release.**

### Mid-field: `lowpoly__map__asset__by_resoforge`
- Massive 1684-mesh, 2746-node, 11-material set
- Bounding box: 252 m × 112 m × 60 m
- Materials: PLANE, YELLOW, WHITE, etc.
- Provides containers, ramps, crates for cover
- Disk size: 32.6 MB (largest asset by far)
- License: CC-BY-4.0 (commercial OK)
- Recolor BLUE → yellow to avoid team-color confusion

## P0 License Blocker — Resolution Required

`castle_wars_pavlov_vr` is the only non-commercial asset in the pack. The NC clause prohibits use for commercial purposes AND requires derivative works to inherit the same non-commercial share-alike license. **Any Steam release — free-to-play or paid — is blocked until one of these is done:**

1. **Replace**: model a custom castle of equivalent layout (two opposing 3-floor castles, courtyard gate / ramparts / sniper tower, ~19 meshes, comparable bounding box). Estimated 2–4 weeks of senior environment artist time.
2. **License**: contact author `FlunkedPunk` via Sketchfab to negotiate a separate commercial license. Document the terms in `docs/Credits.md` and retain written permission in `docs/legal/`.
3. **Switch primary map**: if neither option is viable, designate a different map as primary and demote Castle Wars to a non-shipping internal prototype.

Until this is resolved, the orchestrator's `scan_project` task should mark any prompt that touches `godot/scenes/maps/castle_wars*` as `risk = blocker` and refuse to write changes.

## Map Layout

- Two castles at opposite ends (RED on west, BLUE on east).
- Courtyard in the middle (artifact spawn point — 30 s delay after round start).
- 3 lanes: north, middle, south.
- Vertical play: each castle's sniper tower overlooks courtyard.
- Health/ammo racks in each castle's courtyard; potions rack in each castle's courtyard.

## Lighting

- **Cute phase (default)**: baked global illumination, soft pastel GI, warm sun.
- **Horror phase (FOSTAS event)**: real-time GI, single cold point-light per shadow monster (max 5 active), rest of map in darkness.
- Transition: 0.4-second lerp (matches FOSTAS event Phase 1 Blackout duration).
- 4K lightmap resolution for castle interiors; 2K for outdoor areas.

## Verticality

- Each castle: gate level (courtyard entry), ramparts (mid — defensive position), sniper tower (top — Star Sniper / Whisper Sniper optimal).
- Tower windows overlook courtyard; snipers in tower are vulnerable to flank via ramparts.
- 3-floor vertical play is mandatory per master prompt — do not flatten.

## Skybox

Two skyboxes required (not in asset pack — must be authored):
- **Cute skybox**: "playground blue" — soft pastel blue with smiley clouds.
- **Horror skybox**: "void black" — pure black with faint red stars.
- 0.4-second lerp between them is part of the FOSTAS event transition.

## Future Maps (planned, not in scope for v1)

1. **Toy Workshop** — assembly line conveyor belts, toy parts as cover.
2. **Playground** — swing sets, slides, sandcastle bunkers.
3. **Toy Store** — shelving aisles, display cases, checkout counter control point.

## Missing Assets for Maps (P2 from Risk Register)

- **Castle Banners / Flags / Trim**: team-color overlays to apply on top of the castle_wars base mesh (which has no native team-color decoration).
- **Skybox Textures**: cute "playground blue" + horror "void black".
- **Collision Meshes**: NONE of the 19 imported GLTFs ship with collision geometry. Must be generated in-engine (Godot's `MeshInstance3D.create_trimesh_collision()` for concave, `create_convex_collision()` for convex props).
- **NavMesh**: required for bot navigation (cover points, flanking lanes) and Shadow Monster A* pathfinding. Must be baked in-engine after final map geometry is locked.
- **LOD Groups**: every mesh needs LOD0 (100% tris), LOD1 (30%), LOD2 (10%). Manual authoring in Godot.
- **Baked GI**: the cute-phase global illumination must be baked after final map geometry and lighting are locked. Re-baking after each level-design iteration is expensive — batch these iterations.

## Per-Asset Scale Issues

- `castle_wars_pavlov_vr`: 137 × 40 × 18.7 m — reasonable, no normalization needed.
- `lowpoly__map__asset__by_resoforge`: 252 × 112 × 60 m — reasonable, no normalization needed.
- `medkit`: 133 × 177 × 84 m ⚠ — clearly a source-unit error (likely centimeters). Must scale to hand-scale ~0.2 m longest axis. Multiplier: 0.00113.
- `soldat_low_poly`: 1310 × 1993 × 513 m ⚠ — same source-unit error. Must scale to character-scale ~1.8 m longest axis. Multiplier: 0.000903.
- `old_fantasy_book`: 5.3 × 7.2 × 2.7 m — slightly oversized; scale to ~0.3 m longest axis for hand-held prop. Multiplier: 0.0417.

## Adding a New Map via FOSTAS OS

1. Create `godot/scenes/maps/<map_name>.tscn` extending `Node3D`.
2. Import the base GLTF as a child scene.
3. Add spawn points (player, weapon, potion, vehicle).
4. Add light probes for baked GI (cute phase).
5. Add real-time light sources for horror phase.
6. Bake collision meshes (`create_trimesh_collision()` for static geometry).
7. Bake NavMesh for bot + Shadow Monster navigation.
8. Register in `godot/autoload/maps_registry.gd`.
9. Verify license compatibility before importing (P0 blocker prevention).
