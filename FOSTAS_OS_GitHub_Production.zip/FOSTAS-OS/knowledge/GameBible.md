# FOSTAS: Toybox Terror — Game Bible

## Vision

FOSTAS: Toybox Terror is engineered around a single tonal-contrast premise: from the outside it looks like a cute, brightly-colored, child-friendly toy world — soft plastic weapons, candy colors, smiley clouds — but mid-match, hardcore tactical mechanics and a sudden psychological-horror event subvert that surface. The game is an online 5v5 multiplayer first-person shooter for PC (Steam), built in Godot 4.3, with a match length of 8–12 minutes and a Best-of-3 round structure in the ranked Artifact Mode.

The signature mechanic is the FOSTAS Monster event: a server-rolled random window between 1:30 and 6:30 into the match triggers a 0.4-second blackout, a 1.0-second warning, a 20-second hunt phase in which five Shadow Monsters spawn and instantly kill any player they catch, and a 2-second recovery back to the cute palette. The event is identical across all 12 clients (10 players + 2 spectators) thanks to server-authoritative phase timing scheduled on the match-time clock, not wall-clock.

## Engine Choice

Godot 4.3 (Compatibility / OpenGL renderer) is committed. The master prompt permitted Unity 2023 LTS HDRP, Unreal 5.4, or Godot 4.3; Godot was selected for: open-source licensing, low build size, GDScript 2.0 typed syntax that maps cleanly to AI-generated code, and `class_name` discovery that makes the orchestrator's `apply_ai_response` pipeline straightforward. Engine choice is now locked — mixing engines mid-project is forbidden.

## Factions

Two factions only: **RED TEAM** vs **BLUE TEAM**. No other color is permitted anywhere in the project. This is enforced at the shader level — the `PlasticToy` material takes a `team_color_override` uniform (`RED: #E63946`, `BLUE: #1D6FB8`). The mid-field playground's `BLUE` material is recolored to yellow to avoid team-color confusion; castles keep team-tinted banners/flags/trim as the only color differentiator on the base mesh.

## Match Structure

- 5v5 lobby-based; bots fill empty slots to guarantee 5v5 minimum.
- 4-minute round timer in ranked Artifact Mode.
- 30-second artifact-spawn delay (no objective active for first 30s).
- FOSTAS event triggers ONCE per match at server-rolled random 1:30–6:30.
- Reconnect window: 90 seconds after disconnect.
- Best-of-3 rounds per match; round win grants +15% primary damage buff (non-stacking, capped at +15%).

## Classes

1. **Combat Medic** — support/close-range. Body mesh: `low_poly_solider_character` (⚠ ships UNRIGGED — must re-rig via Mixamo or custom Humanoid before any Medic animation can be authored). Carries `medkit` in left hand. Abilities: Heal Pulse (Q), Revive (E). On 3-killstreak, gains Bloodlust: 5-second full-HP + zero-recoil + +20% speed + red tint + 1-second-stun-end.
2. **Tactical Mage** — mid-range caster. Body mesh: `soldat_low_poly`. Carries `old_fantasy_book` floating beside left hand; book opens and glows when casting. Spell system is gated behind per-life randomized quests (see `Magic.md`).

## Performance Targets

- 60 FPS sustained on GTX 1060 @ 1080p medium (during 5v5 + FOSTAS event triggered).
- 120–144 FPS on RTX 4070.
- Frame-time budget: 16.6 ms total, broken down in `Optimization.md`.
- Authoritative dedicated server: 20 Hz tick, 200 ms lag-compensated hit validation.

## Damage Model

- Headshot: ×4 multiplier (×12 with Mage's Weapon Enchantment Tier-2 active)
- Torso: ×1
- Limb: ×0.75 (corrected from earlier ×0.7 — matches dev-report acceptance gates)
- TTK target: 0.3–0.8 s at optimal range (0.25 floor, 1.2 ceiling)

## Hardcore Injury System (Six-Limb HP Pools)

Each player has six separate HP pools: **head, torso, left arm, right arm, left leg, right leg**. Damage to a limb reduces only that limb's pool. Four thresholds trigger escalating debuffs:

- **100%–75%**: full capability.
- **75%–50%**: limb-specific minor debuff (arm: +10% weapon sway; leg: −5% move speed).
- **50%–25%**: significant debuff (arm: +25% sway, −20% reload speed; leg: −15% move speed, no sprint).
- **<25%**: crippled (arm: cannot ADS, droppable weapon; leg: prone-only movement).
- **Head < 25%**: blurred vision + muffled audio until healed above 50%.
- **Torso < 25%**: Last Stand state — player drops to prone, can crawl, can fire sidearm only (Toy Blaster Pistol), and bleeds out in 15 seconds unless revived by Medic. Revive restores torso to 50% and all limbs to 25%.

This system is the single most unusual micro-loop feature and must be implemented before any acceptance gate can pass (see Gate 3 below).

## Bots

Fill empty lobby slots to guarantee 5v5 minimum. Reuse Medic/Mage meshes with Toy Reskin Pass. Three skill levels:
- **Easy**: random wander, fires at visible enemies with 50% accuracy, no ability use.
- **Medium**: uses cover, flanks, 70% accuracy, uses class ability on cooldown.
- **Hard**: cover + flanking + basic spell combos, 85% accuracy, predictive aiming, communicates "FOSTAS incoming" via chat.

## Progression Systems (3 Layers + Seasonal Track)

1. **Account Level**: 1–100, XP from match participation, unlocks cosmetic slots.
2. **Weapon Mastery**: 1–5 per weapon, tracked separately for each of the 11 weapons. XP from kills/objectives with that weapon. Mastery is permanent across seasons.
3. **Class Mastery**: 1–5 per class (Medic, Mage). XP from class-specific actions (heals, revives, spell casts).
4. **Seasons**: 90-day cycle. Season track overlays all three layers with seasonal cosmetics, weapon-skin variants, and a seasonal questline. Mastery progress (layers 2 & 3) is permanent and carries across seasons; only the seasonal cosmetic track resets.

## Economy & Monetization (Cosmetic-Only)

- **Cosmetic-only**: no pay-to-win, no gameplay-affecting purchases.
- **Weapon skins**: plastic reskins (gold chrome, candy stripe, team-flag wraps) — visual only.
- **Character skins**: outfit variants for Medic and Mage — visual only.
- **Spellbook covers**: alternative `old_fantasy_book` textures — visual only.
- **In-game currency** (not specified in master prompt, requires design): earned through play, used to unlock seasonal cosmetics. Season Pass optional purchase accelerates earn rate.
- **Artifact round-win buff** (+15% primary damage) is a gameplay buff, NOT an economy currency.
- **Anti-cheat is monetization-protective**: a cosmetic economy depends on fair play; any cheater devalues every legitimate purchase.

## Steam Acceptance Gates (10 Gates — Gate 10 = No Placeholders)

These gates must all pass before the build is considered shippable. The orchestrator's validation step (Step 7) checks gates 1, 2, 7, 8, 9 automatically where feasible.

1. **Gate 1 — End-to-end match flow**: 5v5 lobby → match → scoreboard works on dedicated server with 12 clients.
2. **Gate 2 — All 11 weapons fire/reload/respect stat block**: per-weapon smoke test passes (weapon_manifest.csv values match in-game behavior).
3. **Gate 3 — Medic revive + Bloodlust**: Medic can revive a Last-Stand player; Bloodlust triggers correctly (5-second full-HP + zero-recoil + +20% speed + red tint + 1-second-stun-end, all five components in correct sequence).
4. **Gate 4 — Mage spell quests + Soul Contract**: Mage can complete both spell quests and cast both Tier-2 spells; Soul Contract penalty applies on Tier-3.
5. **Gate 5 — Bounty rune**: appears on 3-killstreak players; killer gets Ultimate spell.
6. **Gate 6 — Artifact Mode round win + damage buff**: round can be won by either team; +15% damage buff persists into next round (non-stacking, capped at +15%).
7. **Gate 7 — FOSTAS event**: triggers at random time, replicates identically to all 12 clients, jumpscare kills, map returns to cute phase.
8. **Gate 8 — 60 FPS sustained**: GTX 1060 @ 1080p medium during 5v5 + FOSTAS event.
9. **Gate 9 — Anti-cheat**: rejects fire-rate hack, speed hack, and spell-cooldown hack in unit tests.
10. **Gate 10 — No placeholders**: zero placeholder meshes, textures, animations, audio, or "TODO" markers anywhere in the build.

## Documentation Deliverables (must ship with build)

- `docs/GDD.md` — Game Design Document (this Game Bible + linked .md files)
- `docs/TDD.md` — Technical Design Document (architecture, networking, optimization)
- `docs/AssetManifest.csv` — full 19-asset inventory with licenses
- `docs/Balance.csv` — per-weapon, per-spell, per-potion balance values
- `docs/Credits.md` — attribution block for all CC-BY assets (Steam credits page)
- `docs/RiskRegister.md` — current P0–P4 risk register (see below)
- `docs/PatchingAndDLC.md` — post-launch content plan

## Risk Register (P0–P4)

### P0 — Blocker (cannot ship without resolution)
- **castle_wars_pavlov_vr CC-BY-NC-SA-4.0**: The primary map asset is non-commercial share-alike. Steam release (free or paid) requires either (a) replacing with a custom-modeled castle of equivalent layout, or (b) obtaining a separate commercial license from the author `FlunkedPunk` via Sketchfab. Resolution is required before any production work touches the map.

### P1 — Critical (delays a major phase)
- **low_poly_solider_character ships UNRIGGED**: 0 skins despite manifest claim of "Rigged". Medic 3rd-person body cannot animate until re-rigged (Mixamo Humanoid or custom rig). Blocker for Medic animations.
- **All 11 weapon GLTFs ship with 0 animations**: must author reload/fire/inspect/ADS/idle/Last-Stand-prone-fire for all 11 + sidearm pistol, for both 1st-person viewmodel (~3K tris) and 3rd-person body (~8K tris). Estimated 132+ clips.
- **Weapon scale normalization**: bounding-box longest axis ranges from 0.38 m (PP-19 Vityaz) to 604 m (PSL — clearly a unit-system error in source). Must normalize all 11 to 1 m longest axis.
- **medkit and soldat_low_poly scale**: 133 m and 1310 m longest axis respectively — same unit-system issue. Must scale to hand-scale (~0.2 m for medkit, ~1.8 m for character).

### P2 — High (delays a subsystem)
- **Zero audio assets supplied**: must source adaptive music (4 stems), per-weapon SFX (12 weapons), footsteps, jumpscare scream, spell SFX, UI SFX. ~40+ audio files.
- **Zero VFX textures supplied**: plasma burst, plasma tracer, cotton-candy blood (cute), red blood (horror), meteor, mass-resurrect souls, bounty rune, FOSTAS sky beam, pickup ring, monster motion-blur trail, dissolve-death.
- **Zero UI/HUD art supplied**: HP bar with 6 limb icons, weapon icon + ammo + reload, round timer + score, minimap, crosshair, teammate chevrons + HP bars, bounty rune, Mage spell bar.
- **Material name drift**: GLTF material names (`02___Default`, `Outline_001`, `Material.001`) don't map cleanly to PlasticToy — needs a name-normalization pass during import.

### P3 — Medium (scope or quality risk)
- **Engine choice**: now resolved (Godot 4.3), but late commitment delayed Phase 1.
- **Bot AI complexity**: 3 skill tiers with cover/flanking/spell-combos on hard tier — non-trivial, scope as late-production polish.
- **FOSTAS event replication fragility**: frame-accurate phase timing across 12 clients with up to 200 ms lag-comp window. Requires match-time-clock scheduling, not wall-clock. Must integration-test under simulated 250 ms pings.

### P4 — Low (cosmetic or workflow only)
- **Steam store-page assets**: capsule images, trailers, screenshots — separate marketing workflow, should begin 6–12 months pre-launch for wishlist accumulation. Not a build risk.

## Recommended Next Steps (priority order)

1. **Resolve P0 license blocker**: decide replace-vs-license for castle_wars_pavlov_vr before any map work.
2. **Commit engine = Godot 4.3** (done) and lock project settings.
3. **Re-rig low_poly_solider_character** to Humanoid rig; author baseline Medic idle/walk/run clips to unblock class-3 animation work.
4. **Normalize all 19 asset scales** to consistent units (1 m longest axis for weapons, 1.8 m for characters).
5. **Author the 11 weapon viewmodel fire/reload clips** + sidearm pistol — unblocks Gate 2 smoke test.
6. **Implement Hardcore injury system** (6-limb HP, Last Stand) — unblocks Gate 3.
7. **Implement FOSTAS event 4-phase state machine** with match-time-clock scheduling — unblocks Gate 7.
8. **Stand up dedicated server + 12-client soak test** — unblocks Gate 1.
9. **Implement server-side anti-cheat rules** (fire-rate, speed, spell-cooldown) — unblocks Gate 9.
10. **Source audio + VFX + UI art** — parallel track; unblocks polish for all gates.

## Bots (Recap)

Fill empty lobby slots to guarantee 5v5 minimum. See `## Bots` section above for the three skill tiers and their behavioral profiles.
