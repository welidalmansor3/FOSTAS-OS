# FOSTAS Performance Optimization

## Targets

- **60 FPS sustained** on GTX 1060 @ 1080p medium (during 5v5 + FOSTAS event triggered) — Gate 8.
- 120–144 FPS on RTX 4070.
- Frame-time budget: 16.6 ms (60 FPS) — see breakdown below.
- Authoritative dedicated server: 20 Hz tick, 200 ms lag-compensated hit validation.

## Frame-Time Budget Breakdown (60 FPS = 16.6 ms)

| Subsystem | Budget | % |
|-----------|--------|---|
| Rendering | 8.0 ms | 48% |
| Physics | 3.0 ms | 18% |
| Game logic | 3.0 ms | 18% |
| Networking | 1.0 ms | 6% |
| Audio | 0.5 ms | 3% |
| OS / overhead | 1.1 ms | 7% |

If any subsystem exceeds budget, the frame drops below 60 FPS. Profiling must verify each subsystem stays within budget during the worst-case scenario (5v5 + FOSTAS Hunt phase with 5 monsters + spell VFX).

## Profiling Tools

- Godot Built-in Profiler (Monitor tab) — per-frame subsystem timings.
- `--rendering-driver opengl3` for compatibility testing (matches the committed GL Compatibility renderer in `project.godot`).
- `--rendering-driver vulkan` for production (Forward+ renderer).
- Render debug: `--render-debug overdraw` to find overdraw hotspots (especially the 1684-mesh mid-field scene).

## Rendering Optimizations

### LOD (Level of Detail)
- 3 LOD levels per weapon model: full (0–15 m), medium (15–40 m), low (40 m+).
- 4 LOD levels per environment mesh (castle_wars is 19 meshes — each needs LOD0/1/2/3).
- Trigger: distance from camera.
- Use Godot's `LODManager` or manual `MeshInstance3D.lod_bias`.
- LOD0 = 100% tris, LOD1 = 30%, LOD2 = 10%, LOD3 = 3% (cull if < 0.5% screen coverage).

### Occlusion Culling
- Enable `OcclusionCulling` in project settings.
- Bake occlusion meshes for castle_wars and mid-field playground.
- Critical for 1684-mesh mid-field scene — without occlusion, all 1684 meshes are submitted every frame regardless of visibility.

### Baked Lighting (Cute Phase)
- Use `BakedLightmap` + `LightmapGI` for cute phase.
- 4K lightmap resolution for castle interiors.
- 2K for outdoor areas.
- Static geometry only — dynamic objects (players, monsters, weapons) use real-time light probes.

### Real-time Lighting (Horror Phase)
- Single cold point-light per shadow monster (max 5 active during Hunt).
- Disable shadow casting on point-lights (perf cost too high — soft shadows on 5 dynamic lights exceeds the 8 ms render budget).
- Use unlit materials for distant geometry during Hunt phase.
- Max 8 dynamic lights per frame: 5 monster point-lights + 3 reserved for spell VFX (Mass Shield ring, Mass Teleport column, Mass Resurrection columns).

### Material Optimizations
- Use `StandardMaterial3D` with `shading_mode = unshaded` where possible (VFX sprites, skybox, tracer trails).
- `PlasticToy` material: 1 texture, 1 uniform (`team_color_override`) — very cheap; reuse across all 11 weapons + castle banners.
- Avoid `BaseMaterial3D` features like `subsurface_scattering` for toys — no toy needs SSS.
- Material name drift: GLTF material names (`02___Default`, `Outline_001`, `Material.001`) must be normalized to `PlasticToy_<asset>` during import (P2 risk).

### Mesh Merging
- The 1684-mesh mid-field scene is a draw-call explosion risk.
- Merge static meshes via `MeshInstance3D.merge_meshes` (or Godot's `MeshLibrary`).
- Target: < 500 draw calls per frame on GTX 1060.
- Don't merge the 5 monster meshes (they move independently).

## Networking Optimizations

### Snapshot Compression
- Use delta compression (send only changes from last snapshot per client).
- Quantize positions to 16-bit per axis (±327 m, 1 mm precision) — sufficient for 252 m × 112 m × 60 m map.
- Quantize rotations to quaternion packed in 32 bits (smallest-three encoding).
- Snapshot priority by proximity: closer players get higher update rate; distant players downsampled.

### Bandwidth Budget
- Server → client: 64 Kbps per client (10 clients = 640 Kbps server upload).
- Client → server: 16 Kbps per client (inputs only).
- Re-sync: full state broadcast every 5 s (handles missed snapshots).

## Memory Optimizations

- **Asset streaming** for mid-field playground (load in chunks based on player position) — the 32.6 MB scene should not be resident in full at all times.
- **Texture streaming**: mipmaps streamed from disk (prevents VRAM bloat on GTX 1060's 6 GB).
- **Audio**: stream long stems (4 music stems × 2 minutes = 8 minutes of music), preload short SFX (footsteps, UI clicks).
- **Object pooling**: pool bullet casings, plasma tracer trails, muzzle flash particles — avoid per-frame instantiation.

## Common Performance Issues & Fixes

### Frame Drops During FOSTAS Event
- **Root cause**: 5 real-time point-lights + dynamic GI recalculation during Hunt phase.
- **Fix**: disable dynamic GI during Hunt, use baked "horror" lightmap + per-monster point-light. Cap dynamic lights at 8 per frame.

### Stuttering on Asset Load
- **Root cause**: synchronous texture streaming at match start.
- **Fix**: enable `ResourceLoader.load_async`, preload critical assets (player models, 11 weapons, 2 castles) at lobby → ready-check transition. Show loading screen until all critical assets are resident.

### High Draw Calls (1684-mesh mid-field)
- **Root cause**: too many small meshes submitted to GPU per frame.
- **Fix**: merge static meshes via `MeshInstance3D.merge_meshes`, target < 500 draw calls per frame. Use occlusion culling to cull meshes behind castle walls.

### Audio Glitches During Phase Transitions
- **Root cause**: stem crossfades (0.5 s) competing with sub-bass rumble (Phase 2) and silence cut (Phase 1).
- **Fix**: pre-load all 4 stems into memory at match start; use Godot's `AudioStreamPlayer` with built-in fade (don't manually tween volume).

## Missing Assets Affecting Performance (P2)

- **LOD groups** for all 11 weapons + 2 castles + 1684-mesh mid-field — without LODs, distant meshes render at full tri count.
- **Occlusion meshes** for castle_wars and mid-field — without these, all 1684 mid-field meshes submit every frame.
- **Baked GI** for cute phase — without baked GI, real-time GI is required at all times, exceeding the 8 ms render budget on GTX 1060.

## Performance Validation Workflow

1. Run Godot Profiler during 5v5 + FOSTAS event triggered (worst case).
2. Verify each subsystem stays within frame-time budget (table above).
3. Run `--render-debug overdraw` to find overdraw hotspots.
4. Verify draw call count < 500 per frame on GTX 1060.
5. Verify bandwidth < 64 Kbps per client (use Wireshark or Godot's network profiler).
6. Verify memory < 4 GB on GTX 1060 (6 GB VRAM total; leave 2 GB for OS + other apps).
7. Log results to `docs/perf/<date>.json` for trend tracking across builds.
