# FOSTAS Magic System (Tactical Mage only)

The magic system is exclusive to the Tactical Mage class. Combat Medic has no spell access — Medic's parallel path to power is the Bloodlust killstreak (3-killstreak → 5-second full-HP + zero-recoil + +20% speed + red tint + 1-second-stun-end). Mage's parallel path is the bounty rune (3-killstreak → Tier-2 spell unlocked without completing quest).

## Spell Gating (per-life randomized quest)

Each life, the Mage is assigned ONE of two quests at random. The quest is rolled server-side at spawn and displayed in the HUD. Quest progress is reset on death.

### Quest A — "3 Headshots"
Land three headshot kills. On completion, unlocks **Tier-2 Weapon Enchantment**.

### Quest B — "3 Teammate Heals"
Heal three teammates via Heal Pulse (shared with Medic cooldown). On completion, unlocks **Tier-2 Mass Shield**.

If the Mage dies before completing the quest, the quest resets and a new random quest is rolled on next spawn.

## Tier-2 Spells (quest reward)

### Weapon Enchantment
- Headshot damage multiplier jumps from ×4 to ×12.
- Mage's weapon glows purple (`#9D4EDD`).
- Duration: 15 seconds.
- Cooldown: 30 seconds.
- Pairs with high-fire-rate weapons (BuzzBee SMG, Hornet SMG) for maximum headshot opportunity.

### Mass Shield
- All teammates within 8 m gain 50 HP overshield.
- Shield glows team-color.
- Duration: 10 seconds.
- Cooldown: 45 seconds.
- Oversield stacks with Hardcore limb-HP pools (applied to torso pool first; overflow absorbed).

## Tier-3 Spells (Soul Contract — automatic penalty)

Tier-3 spells are powerful enough to require an automatic penalty. The Soul Contract is a server-side flag set the moment a Tier-3 spell is cast; the penalty persists through death for the rest of the round.

### Mass Teleport
- Teleports entire team to friendly castle spawn.
- Penalty: Mage loses 50 HP permanently for rest of round (cannot be healed above the new ceiling).
- Cooldown: 120 seconds.
- Use case: emergency extraction during FOSTAS Hunt phase if team is scattered.

### Soul Harvest
- Instantly kills all Shadow Monsters in 30 m radius (only effective during FOSTAS event Hunt phase).
- Penalty: Mage's next 3 respawns take +50% damage.
- Cooldown: 240 seconds.
- Use case: clutch save during FOSTAS Hunt; clears path for team to regroup.

### Mass Resurrection (third Tier-3 spell — added per dev report)
- Revives all dead teammates within line-of-sight (60 m cone) to 50% torso HP and 25% all limbs (Last-Stand recovery state).
- Penalty: Mage immediately drops to 25% torso HP (Last-Stand prone state themselves) — essentially trading their own continued uptime for the team's.
- Cooldown: 300 seconds.
- Use case: clutch round-save when 2+ teammates are bleeding out simultaneously.
- VFX: team-color column of light on each revived teammate; rising-souls particle effect; chime SFX.

## Bounty → Ultimate Shortcut

Any player on a 3-killstreak gets a glowing red rune above their head (visible through walls to enemies only — creates risk/reward tension) AND automatically unlocks their class's Tier-2 ability without completing the quest:

- **Medic on 3-killstreak**: unlocks Bloodlust (Ultimate). Killer of the bounty-rune player gets their own Ultimate spell cast for free.
- **Mage on 3-killstreak**: unlocks their Quest B or Quest A Tier-2 spell (whichever they hadn't completed). Killer of the bounty-rune Mage gets Ultimate spell cast for free.

This is the parallel path to spell power that bypasses the quest gate. The bounty rune is a high-visibility risk: enemies see your rune through walls, so the 3-killstreak player becomes a marked target. The economy here is risk (visibility) vs. reward (Tier-2 spell).

The +15% damage buff from winning an Artifact round is a separate mechanic — it is a team-wide buff, non-stacking, capped at +15%, and persists for the rest of the match (not round).

## Spellbook Prop & VFX

- Mage carries `old_fantasy_book` asset floating beside left hand.
- Book opens and glows when casting any spell.
- `Weapon Enchantment` VFX: purple particle trail on bullets, weapon barrel aura.
- `Mass Shield` VFX: team-color expanding ring on cast.
- `Mass Teleport` VFX: team-color column of light, players dissolve and reform at castle.
- `Soul Harvest` VFX: purple shockwave + soul-particle dissolve on monsters in radius.
- `Mass Resurrection` VFX: team-color columns of light on each revived teammate, rising-souls particles, white-gold chime.

## Spell SFX (must be sourced — P2 risk)

- Enchantment shimmer (sustained 15 s, layered over weapon fire SFX).
- Cleanse chime (Mass Shield cast).
- Meteor impact (not currently in spell list — placeholder for future).
- Teleport whoosh (Mass Teleport cast + arrival).
- Mass-resurrect chime (sustained 2 s, choir + bell).
- Soul Harvest dissipation sound (low rumble + sparkle tail).

## Adding a New Spell via FOSTAS OS

1. Create `godot/scripts/spells/<spell_name>.gd` extending `Spell` base class.
2. Define `@export` stats: tier (1/2/3), duration, cooldown, range, penalty.
3. Implement `cast(mage)` method that applies the effect server-side.
4. If Tier-3, implement `apply_penalty(mage)` that sets the Soul Contract flag.
5. Register in `godot/autoload/spells_registry.gd`.
6. Add VFX + SFX references to the spell's `.tscn`.
