"""
FOSTAS OS — Streamlit Frontend (Single-Page App)

Dark theme. Six panels via sidebar navigation:
  1. Prompt         — main NL → AI pipeline interface
  2. Workspace      — Godot project browser
  3. AI Activity    — recent AI provider calls
  4. Logs           — full event log viewer
  5. Downloads      — download manager
  6. Knowledge      — view/edit knowledge docs

Talks to the FastAPI backend at http://localhost:8000.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional

import httpx
import streamlit as st

# Allow direct script execution
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config.settings import get_settings  # noqa: E402


# ----------------------------------------------------------------
# Backend client
# ----------------------------------------------------------------


@st.cache_resource
def get_backend_url() -> str:
    s = get_settings()
    return f"http://{s.backend_host.rstrip('0.0.0.0').rstrip('.') or 'localhost'}:{s.backend_port}".replace(
        "://.", "://localhost:"
    )


def backend_get(path: str, params: Optional[Dict] = None, timeout: float = 30.0) -> Dict:
    url = get_backend_url() + path
    try:
        resp = httpx.get(url, params=params, timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"_error": str(e)}


def backend_post(path: str, json_body: Dict, timeout: float = 300.0) -> Dict:
    url = get_backend_url() + path
    try:
        resp = httpx.post(url, json=json_body, timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"_error": str(e)}


def backend_upload(path: str, file_bytes: bytes, filename: str) -> Dict:
    url = get_backend_url() + path
    try:
        files = {"file": (filename, file_bytes)}
        resp = httpx.post(url, files=files, timeout=120.0)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"_error": str(e)}


def backend_delete(path: str, params: Optional[Dict] = None) -> Dict:
    url = get_backend_url() + path
    try:
        resp = httpx.delete(url, params=params, timeout=30.0)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"_error": str(e)}


# ----------------------------------------------------------------
# Page config + theme
# ----------------------------------------------------------------


st.set_page_config(
    page_title="FOSTAS OS",
    page_icon="🎮",
    layout="wide",
    initial_sidebar_state="expanded",
)


# Inject dark theme CSS
st.markdown(
    """
    <style>
    /* Dark theme */
    .stApp {
        background: #0e1117;
        color: #e6edf3;
    }
    .stSidebar {
        background: #161b22;
        border-right: 1px solid #30363d;
    }
    /* Headers */
    h1, h2, h3, h4 {
        color: #f0f6fc !important;
        font-family: 'Inter', 'Segoe UI', sans-serif;
    }
    /* Cards */
    .stCard, .stAlert {
        background: #161b22 !important;
        border: 1px solid #30363d !important;
        border-radius: 8px !important;
    }
    /* Status badge */
    .fostas-badge {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .badge-real { background: #1a7f37; color: #fff; }
    .badge-mock { background: #9a6700; color: #fff; }
    .badge-error { background: #cf222e; color: #fff; }
    .badge-ok { background: #1a7f37; color: #fff; }
    /* Code blocks */
    pre {
        background: #1c2128 !important;
        border: 1px solid #30363d !important;
        border-radius: 6px !important;
        font-family: 'JetBrains Mono', 'Menlo', monospace !important;
        font-size: 12px !important;
    }
    /* Prompt input */
    .stTextArea textarea {
        background: #1c2128 !important;
        color: #e6edf3 !important;
        border: 1px solid #30363d !important;
        font-family: 'JetBrains Mono', monospace !important;
    }
    /* Metrics */
    .stMetric {
        background: #161b22;
        padding: 12px;
        border-radius: 8px;
        border: 1px solid #30363d;
    }
    /* Sidebar nav */
    .stSidebar .stRadio label, .stSidebar .stSelectbox label {
        color: #c9d1d9 !important;
    }
    /* Footer */
    .fostas-footer {
        margin-top: 40px;
        padding: 12px;
        text-align: center;
        color: #6e7681;
        font-size: 11px;
        border-top: 1px solid #21262d;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# ----------------------------------------------------------------
# Sidebar — global nav + system status
# ----------------------------------------------------------------


def render_sidebar() -> str:
    """Render sidebar with nav + system health. Returns selected page."""
    st.sidebar.markdown("## 🎮 FOSTAS OS")
    st.sidebar.caption("AI Operating System for Game Development")
    st.sidebar.caption("`v1.0.0 — Toybox Terror`")

    st.sidebar.divider()

    page = st.sidebar.radio(
        "Navigate",
        options=[
            "🎯 Prompt",
            "📁 Workspace",
            "🤖 AI Activity",
            "📜 Logs",
            "⬇️ Downloads",
            "📤 Uploads",
            "📚 Knowledge",
            "⚙️ System",
        ],
        index=0,
    )

    st.sidebar.divider()

    # Backend health
    health = backend_get("/health", timeout=5.0)
    if "_error" in health:
        st.sidebar.error(f"⚠️ Backend offline\n`{health['_error']}`")
    else:
        st.sidebar.success("✅ Backend online")
        st.sidebar.caption(f"Godot CLI: {'✅' if health.get('godot_cli_available') else '❌'}")
        providers = health.get("providers", {})
        for name, info in providers.items():
            mode = "REAL" if info.get("real_mode") else "MOCK"
            badge_cls = "badge-real" if info.get("real_mode") else "badge-mock"
            st.sidebar.markdown(
                f"<span class='fostas-badge {badge_cls}'>{name} {mode}</span>",
                unsafe_allow_html=True,
            )

    st.sidebar.divider()
    st.sidebar.markdown(
        "<div class='fostas-footer'>"
        "FOSTAS OS v1.0.0<br/>"
        "Z.AI + Gemini + Tripo<br/>"
        "Godot 4.3 • FastAPI • Streamlit"
        "</div>",
        unsafe_allow_html=True,
    )

    return page


# ----------------------------------------------------------------
# Page: Prompt
# ----------------------------------------------------------------


DEMO_PROMPTS = [
    "Add a new weapon: Toy Sniper Rifle, 80 dmg, 60 RPM, bolt-action, 10-round mag, 200m range",
    "Create a monster: 100 HP, melee attacker, spawns at night, 5 m/s speed, 25 dmg per hit",
    "Fix multiplayer lag in player movement — players are rubber-banding",
    "Scan my project and report all weapons and monsters",
]


def page_prompt() -> None:
    st.markdown("# 🎯 Prompt Interface")
    st.markdown("Describe what you want in natural language. FOSTAS OS will analyze, plan, generate code, and apply it to the Godot project.")

    # Demo prompt quick-fill
    st.markdown("### Quick Demos")
    cols = st.columns(len(DEMO_PROMPTS))
    for i, demo in enumerate(DEMO_PROMPTS):
        if cols[i].button(f"Demo {i+1}", key=f"demo_{i}", help=demo):
            st.session_state["prompt_text"] = demo

    st.markdown("### Your Prompt")
    prompt_text = st.text_area(
        "Prompt",
        value=st.session_state.get("prompt_text", ""),
        height=120,
        placeholder="e.g. Add a new weapon: Toy Sniper Rifle, 80 dmg, 60 RPM...",
        label_visibility="collapsed",
    )

    col1, col2, col3 = st.columns([1, 1, 4])
    submit = col1.button("🚀 Run", type="primary", use_container_width=True)
    clear = col2.button("🧹 Clear", use_container_width=True)

    if clear:
        st.session_state["prompt_text"] = ""
        st.rerun()

    if submit:
        if not prompt_text.strip():
            st.error("Prompt cannot be empty.")
            return
        _run_prompt(prompt_text)


def _run_prompt(prompt: str) -> None:
    """Submit prompt to backend and render the result."""
    with st.spinner("FOSTAS OS is analyzing, generating, and applying..."):
        with st.status("Pipeline progress", expanded=True) as status:
            st.write("📤 Submitting prompt to orchestrator...")
            result = backend_post("/api/prompt", {"prompt": prompt}, timeout=300.0)

            if "_error" in result:
                st.error(f"❌ Backend error: {result['_error']}")
                status.update(label="Failed", state="error")
                return

            st.write("✅ Pipeline complete")
            status.update(label="Done", state="complete")

    _render_completion_report(result)


def _render_completion_report(report: Dict[str, Any]) -> None:
    """Render the orchestrator's CompletionReport."""
    st.markdown("---")
    st.markdown("## 📋 Completion Report")

    # Top metrics
    a = report.get("analysis", {})
    cols = st.columns(5)
    cols[0].metric("Intent", a.get("intent", "?"))
    cols[1].metric("Complexity", a.get("complexity", "?"))
    cols[2].metric("Risk", a.get("risk", "?"))
    cols[3].metric("Duration", f"{report.get('duration_ms', 0)} ms")
    success = report.get("success", False)
    cols[4].metric(
        "Status",
        "✅ Success" if success else "❌ Failed",
        delta="ok" if success else "err",
        delta_color="normal" if success else "inverse",
    )

    # Summary
    st.markdown("### Summary")
    st.markdown(report.get("summary", "_(no summary)_"))

    # Tabs for detail
    tabs = st.tabs(["📂 File Changes", "🤖 AI Interactions", "📚 Knowledge", "🧱 Tasks"])

    with tabs[0]:
        fcs = report.get("file_changes", [])
        if fcs:
            for fc in fcs:
                action = fc.get("action", "?")
                icon = {"create": "🟢", "edit": "✏️", "delete": "🗑️", "backup": "💾"}.get(action, "📄")
                st.markdown(f"{icon} **{action}** → `{fc.get('path', '')}`")
                if fc.get("backup_path"):
                    st.caption(f"backup: `{fc['backup_path']}`")
        else:
            st.info("No file changes.")

    with tabs[1]:
        ais = report.get("ai_interactions", [])
        if ais:
            for ai in ais:
                ok = "✅" if ai.get("success") else "❌"
                st.markdown(f"{ok} **{ai.get('provider', '?')}** ({ai.get('model', '?')}) — {ai.get('duration_ms', 0)} ms")
                with st.expander("Details"):
                    st.caption("Prompt:")
                    st.code(ai.get("prompt_summary", ""), language="text")
                    st.caption("Response:")
                    st.code(ai.get("response_summary", ""), language="text")
                    if ai.get("error"):
                        st.error(ai["error"])
        else:
            st.info("No AI interactions.")

    with tabs[2]:
        docs = report.get("knowledge_loaded", [])
        if docs:
            for d in docs:
                st.markdown(f"- 📚 `{d}`")
        else:
            st.info("No knowledge docs loaded.")

    with tabs[3]:
        plan = report.get("plan", {})
        tasks = plan.get("tasks", [])
        if tasks:
            for t in tasks:
                status = t.get("status", "?")
                icon = {"success": "✅", "failed": "❌", "pending": "⏳", "running": "🔄", "skipped": "⏭️"}.get(status, "❔")
                st.markdown(f"{icon} **Task {t.get('id')}** [{t.get('provider', '?')}] — {t.get('description', '')}")
                if t.get("error"):
                    st.error(t["error"])
        else:
            st.info("No tasks.")

    if report.get("overall_error"):
        st.error(f"Fatal error: {report['overall_error']}")


# ----------------------------------------------------------------
# Page: Workspace
# ----------------------------------------------------------------


def page_workspace() -> None:
    st.markdown("# 📁 Godot Workspace")

    col1, col2 = st.columns([1, 3])
    with col1:
        if st.button("🔄 Rescan Project", use_container_width=True):
            st.cache_data.clear()

    # Scan summary
    scan = backend_get("/api/workspace/scan")
    if "_error" in scan:
        st.error(f"Scan failed: {scan['_error']}")
        return

    if not scan.get("success"):
        st.error(f"Scan failed: {scan.get('error', 'unknown')}")
        return

    s = scan.get("scan", {})
    cols = st.columns(6)
    cols[0].metric("Scripts", s.get("scripts", 0))
    cols[1].metric("Scenes", s.get("scenes", 0))
    cols[2].metric("Models", s.get("models", 0))
    cols[3].metric("Textures", s.get("textures", 0))
    cols[4].metric("Sounds", s.get("sounds", 0))
    cols[5].metric("Total Files", s.get("total_files", 0))

    st.markdown(f"**Project:** `{s.get('project_path', '?')}`")
    st.markdown(f"**Godot version:** {s.get('godot_version', '?')}")
    st.markdown(f"**Size:** {s.get('total_size_mb', 0)} MB")

    st.markdown("---")
    st.markdown("### File Browser")

    # File list
    files_resp = backend_get("/api/workspace/files")
    files = files_resp.get("files", [])
    if files:
        selected = st.selectbox("Select a file to view", files, index=0)
        if selected:
            content_resp = backend_get("/api/workspace/file", params={"path": selected})
            if "_error" not in content_resp:
                st.code(content_resp.get("content", ""), language="gdscript")
            else:
                st.error(f"Read failed: {content_resp['_error']}")
    else:
        st.info("No files found.")


# ----------------------------------------------------------------
# Page: AI Activity
# ----------------------------------------------------------------


def page_ai_activity() -> None:
    st.markdown("# 🤖 AI Activity")
    st.markdown("Recent AI provider calls (Z.AI, Gemini, Tripo).")

    # Auto-refresh toggle
    auto = st.checkbox("Auto-refresh every 5s", value=False)
    if auto:
        st.rerun()

    events = backend_get("/api/logs", params={"limit": 200}).get("events", [])
    ai_events = [e for e in events if e.get("event") in ("ai_request", "ai_response")]

    if not ai_events:
        st.info("No AI activity yet. Submit a prompt to see calls here.")
        return

    for ev in reversed(ai_events[-50:]):
        etype = ev.get("event")
        if etype == "ai_request":
            icon = "📤"
            label = f"{ev.get('provider', '?')} REQUEST"
        else:
            ok = ev.get("success", True)
            icon = "✅" if ok else "❌"
            label = f"{ev.get('provider', '?')} RESPONSE ({ev.get('duration_ms', 0)} ms)"
        ts = ev.get("ts", "")[-12:]
        st.markdown(f"**{ts}** {icon} {label}")
        with st.expander("Details"):
            st.json(ev)


# ----------------------------------------------------------------
# Page: Logs
# ----------------------------------------------------------------


def page_logs() -> None:
    st.markdown("# 📜 Event Log")

    col1, col2 = st.columns([1, 4])
    limit = col1.slider("Limit", 50, 1000, 200, step=50)
    level = col1.selectbox("Level filter", ["ALL", "INFO", "WARNING", "ERROR", "DEBUG"])

    params = {"limit": limit}
    if level != "ALL":
        params["level"] = level
    events = backend_get("/api/logs", params=params).get("events", [])

    if not events:
        st.info("No events logged yet.")
        return

    st.markdown(f"### {len(events)} events (newest first)")
    for ev in reversed(events):
        lvl = ev.get("level", "INFO")
        icon = {"INFO": "ℹ️", "WARNING": "⚠️", "ERROR": "❌", "DEBUG": "🐛"}.get(lvl, "•")
        ts = ev.get("ts", "")[-12:]
        event_type = ev.get("event", "?")
        msg = ev.get("message") or ev.get("description") or ev.get("path") or ""
        st.markdown(f"`{ts}` {icon} **[{event_type}]** {msg}")
        with st.expander("Raw"):
            st.json(ev)


# ----------------------------------------------------------------
# Page: Downloads
# ----------------------------------------------------------------


def page_downloads() -> None:
    st.markdown("# ⬇️ Downloads")

    st.markdown("### Submit a new download")
    with st.form("download_form"):
        url = st.text_input("URL", placeholder="https://example.com/model.glb")
        fname = st.text_input("Filename (optional)", placeholder="model.glb")
        sha = st.text_input("Expected SHA-256 (optional)", placeholder="abc123...")
        submitted = st.form_submit_button("Download")

    if submitted and url:
        with st.spinner("Downloading..."):
            body = {"url": url}
            if fname:
                body["filename"] = fname
            if sha:
                body["expected_sha256"] = sha
            result = backend_post("/api/downloads", body, timeout=600.0)
            if "_error" in result:
                st.error(f"Failed: {result['_error']}")
            elif result.get("success"):
                st.success(f"✅ Downloaded {result.get('bytes_downloaded', 0)} bytes to `{result.get('path')}`")
                if result.get("checksum_verified"):
                    st.info("Checksum verified ✅")
            else:
                st.error(f"Download failed: {result.get('error')}")

    st.markdown("---")
    st.markdown("### Existing Downloads")
    files = backend_get("/api/downloads").get("files", [])
    if files:
        for f in files:
            cols = st.columns([4, 1, 1, 1])
            cols[0].markdown(f"📄 `{f['filename']}`")
            cols[1].metric("Size", f"{f['size_mb']} MB")
            cols[2].caption(f"modified: {f['modified']}")
    else:
        st.info("No downloads yet.")


# ----------------------------------------------------------------
# Page: Uploads
# ----------------------------------------------------------------


def page_uploads() -> None:
    st.markdown("# 📤 Uploads")

    st.markdown("### Upload a file (ZIP, FBX, GLB, OBJ, PNG, JPG, WAV, MP3 — max 100 MB)")
    uploaded = st.file_uploader(
        "Drop a file or click to browse",
        type=["zip", "fbx", "glb", "gltf", "obj", "png", "jpg", "jpeg", "webp", "svg", "wav", "mp3", "ogg"],
        accept_multiple_files=False,
    )

    if uploaded is not None:
        bytes_data = uploaded.read()
        st.info(f"Selected: `{uploaded.name}` ({len(bytes_data):,} bytes)")
        if st.button("Upload to FOSTAS OS", type="primary"):
            with st.spinner("Uploading + classifying..."):
                result = backend_upload("/api/uploads", bytes_data, uploaded.name)
                if "_error" in result:
                    st.error(f"Failed: {result['_error']}")
                elif result.get("success"):
                    st.success(
                        f"✅ Uploaded `{result.get('filename')}` "
                        f"({result.get('size_bytes', 0):,} bytes) "
                        f"→ category: **{result.get('category', '?')}**"
                    )
                    if result.get("unzipped"):
                        st.info(f"Extracted {result.get('files_added', 0)} files")
                    if result.get("saved_path"):
                        st.code(f"Saved to: {result['saved_path']}")
                else:
                    st.error(f"Upload failed: {result.get('error')}")

    st.markdown("---")
    st.markdown("### Existing Uploads")
    files = backend_get("/api/uploads").get("files", [])
    if files:
        for f in files:
            st.markdown(f"📄 `{f['filename']}` — {f['size_mb']} MB")
    else:
        st.info("No uploads yet.")


# ----------------------------------------------------------------
# Page: Knowledge
# ----------------------------------------------------------------


def page_knowledge() -> None:
    st.markdown("# 📚 Knowledge Base")
    st.markdown("Game-specific knowledge docs that the AI loads when processing prompts.")

    docs = backend_get("/api/knowledge").get("docs", [])
    if not docs:
        st.info("No knowledge docs. Run the seeder: `python scripts/seed.py`")
        return

    col1, col2 = st.columns([1, 3])
    selected = col1.selectbox("Select doc", docs)
    refresh = col1.button("🔄 Refresh")

    if selected:
        resp = backend_get(f"/api/knowledge/{selected}")
        if "_error" in resp:
            st.error(f"Failed: {resp['_error']}")
            return
        content = resp.get("content", "")
        col2.markdown(f"**`{selected}`** ({len(content)} bytes)")
        edited = col2.text_area("Content", value=content, height=500, label_visibility="collapsed")
        if col2.button("💾 Save"):
            save_resp = backend_put(f"/api/knowledge/{selected}", {"content": edited})
            # backend_put is a helper we still need to add
            if "_error" in save_resp:
                st.error(f"Save failed: {save_resp['_error']}")
            else:
                st.success(f"Saved `{selected}` ({len(edited)} bytes)")
                st.rerun()


def backend_put(path: str, json_body: Dict) -> Dict:
    url = get_backend_url() + path
    try:
        resp = httpx.put(url, json=json_body, timeout=30.0)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"_error": str(e)}


# ----------------------------------------------------------------
# Page: System
# ----------------------------------------------------------------


def page_system() -> None:
    st.markdown("# ⚙️ System")

    st.markdown("### Providers")
    providers = backend_get("/api/providers").get("providers", {})
    for name, info in providers.items():
        mode = "REAL" if info.get("real_mode") else "MOCK"
        badge_cls = "badge-real" if info.get("real_mode") else "badge-mock"
        st.markdown(
            f"<span class='fostas-badge {badge_cls}'>{name} {mode}</span> "
            f"<small>{info.get('role', '')}</small>",
            unsafe_allow_html=True,
        )

    st.markdown("---")
    st.markdown("### Cache")
    stats = backend_get("/api/cache/stats")
    cols = st.columns(2)
    cols[0].metric("Total entries", stats.get("total_entries", 0))
    cols[1].metric("Namespaces", stats.get("namespaces", 0))

    if st.button("🗑️ Clear cache"):
        result = backend_delete("/api/cache")
        if "_error" in result:
            st.error(f"Failed: {result['_error']}")
        else:
            st.success(f"Removed {result.get('removed', 0)} entries")


# ----------------------------------------------------------------
# Main
# ----------------------------------------------------------------


def main() -> None:
    page = render_sidebar()

    if page == "🎯 Prompt":
        page_prompt()
    elif page == "📁 Workspace":
        page_workspace()
    elif page == "🤖 AI Activity":
        page_ai_activity()
    elif page == "📜 Logs":
        page_logs()
    elif page == "⬇️ Downloads":
        page_downloads()
    elif page == "📤 Uploads":
        page_uploads()
    elif page == "📚 Knowledge":
        page_knowledge()
    elif page == "⚙️ System":
        page_system()


if __name__ == "__main__":
    main()
