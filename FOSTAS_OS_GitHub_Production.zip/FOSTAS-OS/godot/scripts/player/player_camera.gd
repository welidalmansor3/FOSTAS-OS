# File: scripts/player/player_camera.gd
# FOSTAS: Toybox Terror — FPS Camera
#
# First-person camera attached to the player's head bone (or eye offset).
# Per master prompt PART 2: "camera locked to 1st-person. Third-person body
# rendered for shadow/visibility only."
#
# Reads mouse-look deltas from PlayerInput and applies them with smoothing.
# Applies injury sway from InjuryEffects (camera tilt).
extends Camera3D
class_name PlayerCamera

# ---- Constants ----
const DEFAULT_FOV: float = 75.0
const ADS_FOV: float = 55.0  # zoom in when aiming down sights
const FOV_LERP_SPEED: float = 10.0
const PITCH_LIMIT_DEG: float = 89.0  # cannot look straight up/down past this

# ---- State ----
var yaw: float = 0.0   # rotation around Y axis (left/right)
var pitch: float = 0.0 # rotation around X axis (up/down)
var player_input: PlayerInput = null
var injury_effects: InjuryEffects = null
var target_fov: float = DEFAULT_FOV
var current_fov: float = DEFAULT_FOV

# ---- Lifecycle ----

func _ready() -> void:
    current_fov = DEFAULT_FOV
    fov = current_fov
    # Find siblings.
    var parent: Node = get_parent()
    if parent:
        player_input = parent.get_node_or_null("PlayerInput")
        injury_effects = parent.get_node_or_null("InjuryEffects")
    if player_input == null:
        push_warning("[PlayerCamera] No PlayerInput found on parent.")

func _process(delta: float) -> void:
    # 1. Consume look delta from input.
    if player_input:
        var look: Vector2 = player_input.consume_look_delta()
        yaw -= look.x
        pitch -= look.y
        # Clamp pitch to prevent over-rotation.
        var limit_rad: float = deg_to_rad(PITCH_LIMIT_DEG)
        pitch = clamp(pitch, -limit_rad, limit_rad)

    # 2. Apply injury sway (small offset on top of player-controlled rotation).
    var sway_offset: Vector2 = Vector2.ZERO
    if injury_effects:
        sway_offset = injury_effects.get_current_sway()

    # 3. Compose final rotation: yaw (player) + sway yaw, pitch (player) + sway pitch.
    var final_yaw: float = yaw + sway_offset.x
    var final_pitch: float = pitch + sway_offset.y
    # Re-clamp after sway.
    var limit_rad: float = deg_to_rad(PITCH_LIMIT_DEG)
    final_pitch = clamp(final_pitch, -limit_rad, limit_rad)

    # 4. Apply to camera transform.
    # Camera looks down -Z; yaw rotates around Y; pitch rotates around X.
    transform.basis = Basis(Vector3(0, 1, 0), final_yaw) * Basis(Vector3(1, 0, 0), final_pitch)

    # 5. FOV lerp toward target (for ADS transition).
    current_fov = lerp(current_fov, target_fov, delta * FOV_LERP_SPEED)
    fov = current_fov

# ---- Public API ----

func set_ads(ads: bool) -> void:
    target_fov = ADS_FOV if ads else DEFAULT_FOV

func get_look_direction() -> Vector3:
    """Returns the world-space direction the camera is looking (for raycasts)."""
    return -global_transform.basis.z

func get_yaw() -> float:
    return yaw

func get_pitch() -> float:
    return pitch

func force_yaw_pitch(new_yaw: float, new_pitch: float) -> void:
    """Used by server reconciliation to snap the camera to a corrected orientation."""
    yaw = new_yaw
    pitch = new_pitch
