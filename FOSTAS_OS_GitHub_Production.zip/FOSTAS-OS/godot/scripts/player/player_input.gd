# File: scripts/player/player_input.gd
# FOSTAS: Toybox Terror — Player Input (client-side)
#
# Gathers local input every frame and exposes it as a structured dictionary.
# The Player controller reads from this node; for networked play, the input is
# also sent to the server (Phase 4) for server-authoritative validation.
#
# Per master prompt Module B12: clients send inputs at 60 Hz to the server.
extends Node
class_name PlayerInput

# ---- State ----
var move_vector: Vector2 = Vector2.ZERO  # x=right, y=forward
var look_delta: Vector2 = Vector2.ZERO   # mouse delta (x=yaw, y=pitch)
var sprint_held: bool = false
var crouch_held: bool = false
var jump_pressed: bool = false
var jump_held: bool = false
var fire_held: bool = false
var fire_pressed: bool = false  # edge-triggered for semi-auto
var ads_held: bool = false
var reload_pressed: bool = false
var ability_q_pressed: bool = false
var ability_e_pressed: bool = false
var spell_slot_1_pressed: bool = false
var spell_slot_2_pressed: bool = false
var spell_slot_3_pressed: bool = false
var use_pressed: bool = false
var scoreboard_held: bool = false
var voice_held: bool = false

# Mouse sensitivity (configurable in settings; default per master prompt feel).
var mouse_sensitivity: float = 0.002  # radians per pixel
var mouse_inverted_y: bool = false

# Input capture state.
var input_captured: bool = false

# ---- Lifecycle ----

func _ready() -> void:
    set_process_unhandled_input(true)

func _unhandled_input(event: InputEvent) -> void:
    # Mouse look — only when input is captured (game has focus, not in menu).
    if event is InputEventMouseMotion and input_captured:
        var motion: InputEventMouseMotion = event as InputEventMouseMotion
        var dx: float = motion.relative.x * mouse_sensitivity
        var dy: float = motion.relative.y * mouse_sensitivity
        if mouse_inverted_y:
            dy = -dy
        look_delta += Vector2(dx, dy)

    # Edge-triggered actions (pressed this frame).
    if event.is_action_pressed("jump"):
        jump_pressed = true
    if event.is_action_pressed("fire"):
        fire_pressed = true
    if event.is_action_pressed("reload"):
        reload_pressed = true
    if event.is_action_pressed("ability_q"):
        ability_q_pressed = true
    if event.is_action_pressed("ability_e"):
        ability_e_pressed = true
    if event.is_action_pressed("spell_slot_1"):
        spell_slot_1_pressed = true
    if event.is_action_pressed("spell_slot_2"):
        spell_slot_2_pressed = true
    if event.is_action_pressed("spell_slot_3"):
        spell_slot_3_pressed = true
    if event.is_action_pressed("use"):
        use_pressed = true

func _process(delta: float) -> void:
    # Continuous (held) actions — polled every frame.
    move_vector = Vector2.ZERO
    move_vector.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
    move_vector.y = Input.get_action_strength("move_forward") - Input.get_action_strength("move_backward")

    sprint_held = Input.is_action_pressed("sprint")
    crouch_held = Input.is_action_pressed("crouch")
    jump_held = Input.is_action_pressed("jump")
    fire_held = Input.is_action_pressed("fire")
    ads_held = Input.is_action_pressed("aim")
    scoreboard_held = Input.is_action_pressed("scoreboard")
    voice_held = Input.is_action_pressed("voice")

# ---- Public API ----

func capture_input() -> void:
    """Lock the mouse cursor to the window for FPS look."""
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    input_captured = true

func release_input() -> void:
    """Release the mouse cursor (for menus / pause)."""
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    input_captured = false
    # Clear look delta so the camera doesn't jump when re-captured.
    look_delta = Vector2.ZERO

func consume_look_delta() -> Vector2:
    """Return the accumulated look delta and reset it to zero.
    Called once per frame by PlayerCamera."""
    var delta: Vector2 = look_delta
    look_delta = Vector2.ZERO
    return delta

func consume_edge_triggers() -> Dictionary:
    """Return all edge-triggered button states and reset them.
    Called once per frame by the Player controller."""
    var triggers: Dictionary = {
        "jump": jump_pressed,
        "fire": fire_pressed,
        "reload": reload_pressed,
        "ability_q": ability_q_pressed,
        "ability_e": ability_e_pressed,
        "spell_slot_1": spell_slot_1_pressed,
        "spell_slot_2": spell_slot_2_pressed,
        "spell_slot_3": spell_slot_3_pressed,
        "use": use_pressed,
    }
    jump_pressed = false
    fire_pressed = false
    reload_pressed = false
    ability_q_pressed = false
    ability_e_pressed = false
    spell_slot_1_pressed = false
    spell_slot_2_pressed = false
    spell_slot_3_pressed = false
    use_pressed = false
    return triggers

func serialize_for_network() -> Dictionary:
    """Serialize the current input state for sending to the server (Phase 4).
    Only includes inputs the server needs to validate."""
    return {
        "move": move_vector,
        "look": look_delta,
        "sprint": sprint_held,
        "crouch": crouch_held,
        "jump": jump_held,
        "fire": fire_held,
        "ads": ads_held,
        "timestamp": Time.get_ticks_msec(),
    }
