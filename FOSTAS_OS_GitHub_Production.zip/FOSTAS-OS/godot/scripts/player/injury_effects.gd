# File: scripts/player/injury_effects.gd
# FOSTAS: Toybox Terror — Injury Effects (visual + audio + sway)
#
# Per master prompt Module B5:
#   - Weapon sway driven by Perlin-noise 2D vector modulated by injury level +
#     stamina + ADS state.
#   - Bullet trajectory deviates from crosshair by the current sway vector
#     (bullets do NOT snap to crosshair).
#   - Screen-edge red pulse at HEAVY injury.
#   - Desaturated screen at CRITICAL injury.
#   - Heavy breathing audio at CRITICAL injury.
#
# This node reads from HealthSystem (sibling node) and exposes:
#   - get_current_sway() -> Vector2 (called by camera + weapons)
#   - apply_visual_effects() (called every frame to update post-FX)
extends Node
class_name InjuryEffects

# ---- Constants ----
# Perlin noise parameters for weapon sway.
const SWAY_FREQUENCY: float = 0.5  # Hz — slow drift
const SWAY_AMPLITUDE_BASE: float = 0.5  # radians, applied at CLEAN state
const SWAY_AMPLITUDE_ADS_MULTIPLIER: float = 0.3  # ADS reduces sway
const SWAY_PERLIN_SEED: int = 1337

# Visual effect strengths (lerped toward target each frame).
const RED_PULSE_INTENSITY_HEAVY: float = 0.15
const RED_PULSE_INTENSITY_CRITICAL: float = 0.35
const DESATURATION_CRITICAL: float = 0.4
const VIGNETTE_CRITICAL: float = 0.6

# ---- State ----
var health_system: HealthSystem = null
var _sway_time: float = 0.0
var _is_ads: bool = false
var _current_red_pulse: float = 0.0
var _current_desaturation: float = 0.0
var _current_vignette: float = 0.0

# ---- Lifecycle ----

func _ready() -> void:
    # Find sibling HealthSystem.
    var parent: Node = get_parent()
    if parent:
        health_system = parent.get_node_or_null("HealthSystem")
    if health_system == null:
        push_warning("[InjuryEffects] No HealthSystem found on parent — effects disabled.")

func _process(delta: float) -> None:
    if health_system == null:
        return
    _sway_time += delta
    _update_visual_effects(delta)

# ---- Sway (Perlin-noise) ----

func get_current_sway() -> Vector2:
    """Returns the current 2D sway offset in radians (x=yaw, y=pitch).
    Called by PlayerCamera (for camera tilt) and weapons (for bullet trajectory)."""
    if health_system == null:
        return Vector2.ZERO
    if health_system.is_in_bloodlust():
        return Vector2.ZERO  # zero recoil during Bloodlust

    var sway_mult: float = health_system.get_sway_multiplier()
    if sway_mult <= 0.0:
        return Vector2.ZERO

    var ads_mult: float = SWAY_AMPLITUDE_ADS_MULTIPLIER if _is_ads else 1.0
    var amplitude: float = SWAY_AMPLITUDE_BASE * sway_mult * ads_mult

    # 2D Perlin-like noise (use two offset sine waves for cheap pseudo-noise;
    # Godot's FastNoiseLite is also available but heavier per-call).
    var x: float = sin(_sway_time * SWAY_FREQUENCY * TAU) * amplitude * 0.5
    var y: float = cos(_sway_time * SWAY_FREQUENCY * TAU * 0.7 + 1.3) * amplitude * 0.3
    # Add a higher-frequency component for jitter at high injury.
    if sway_mult > 1.5:
        x += sin(_sway_time * SWAY_FREQUENCY * TAU * 3.1) * amplitude * 0.2
        y += cos(_sway_time * SWAY_FREQUENCY * TAU * 2.7 + 0.5) * amplitude * 0.15

    return Vector2(x, y)

func set_ads(ads: bool) -> void:
    _is_ads = ads

# ---- Visual effects ----

func _update_visual_effects(delta: float) -> void:
    if health_system == null:
        return
    var worst: int = health_system.get_worst_limb_state()

    # Target values based on worst injury.
    var target_red: float = 0.0
    var target_desat: float = 0.0
    var target_vig: float = 0.0

    match worst:
        HealthSystem.InjuryState.HEAVY:
            target_red = RED_PULSE_INTENSITY_HEAVY
        HealthSystem.InjuryState.CRITICAL:
            target_red = RED_PULSE_INTENSITY_CRITICAL
            target_desat = DESATURATION_CRITICAL
            target_vig = VIGNETTE_CRITICAL
        HealthSystem.InjuryState.CRIPPLED:
            target_red = RED_PULSE_INTENSITY_CRITICAL
            target_desat = DESATURATION_CRITICAL + 0.2
            target_vig = VIGNETTE_CRITICAL + 0.2

    # Bloodlust overrides with red tint.
    if health_system.is_in_bloodlust():
        target_red = 0.4
        target_desat = 0.0
        target_vig = 0.3

    # Lerp current toward target (smooth transition).
    var lerp_speed: float = 4.0  # 0.25s to reach target
    _current_red_pulse = lerp(_current_red_pulse, target_red, delta * lerp_speed)
    _current_desaturation = lerp(_current_desaturation, target_desat, delta * lerp_speed)
    _current_vignette = lerp(_current_vignette, target_vig, delta * lerp_speed)

    # Phase 9 will apply these to the actual post-FX profile.
    # For now, they're queryable via getters for the HUD to draw overlays.

func get_red_pulse_intensity() -> float:
    return _current_red_pulse

func get_desaturation() -> float:
    return _current_desaturation

func get_vignette() -> float:
    return _current_vignette

func should_play_heavy_breathing() -> bool:
    if health_system == null:
        return false
    var worst: int = health_system.get_worst_limb_state()
    return worst >= HealthSystem.InjuryState.CRITICAL
