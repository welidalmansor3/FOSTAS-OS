# File: scripts/player/player.gd
# FOSTAS: Toybox Terror — Player Controller (FPS)
#
# The core player character. CharacterBody3D with full FPS movement.
# Integrates HealthSystem (6-limb HP), InjuryEffects (sway + visuals),
# PlayerInput (input gathering), PlayerCamera (FPS view).
#
# Movement model (per master prompt PART 2 + Module B5):
#   - Walk: 5 m/s
#   - Sprint: 8 m/s (multiplied by leg injury state)
#   - Crouch: 2.5 m/s
#   - Last Stand crawl: 1.5 m/s (sidearm only)
#   - Jump: vertical impulse, gravity applies
#   - ADS: movement speed × 0.5
#
# Phase 1 scope: movement + look + HP system integration + debug damage.
# Phase 2 adds: weapon equip, fire, reload, ADS, recoil.
# Phase 3 adds: class abilities (Medic/Mage).
# Phase 4 adds: server-authoritative networking (extends player_network.gd).
extends CharacterBody3D
class_name Player

# ---- Exports ----
@export var walk_speed: float = 5.0
@export var sprint_speed: float = 8.0
@export var crouch_speed: float = 2.5
@export var last_stand_crawl_speed: float = 1.5
@export var ads_speed_multiplier: float = 0.5
@export var jump_velocity: float = 5.0
@export var gravity_scale: float = 1.0
@export var eye_height: float = 1.7
@export var crouch_eye_height: float = 1.0
@export var last_stand_eye_height: float = 0.4

# ---- Component references (assigned in _ready) ----
var health_system: HealthSystem = null
var injury_effects: InjuryEffects = null
var player_input: PlayerInput = null
var player_camera: PlayerCamera = null

# ---- State ----
var peer_id: int = 0
var is_local: bool = false  # true if this is the local player's character
var team: int = 0  # TeamManager.Team enum value
var current_speed: float = 0.0
var is_sprinting: bool = false
var is_crouching: bool = false
var is_in_ads: bool = false

# ---- Constants ----
const GRAVITY: float = 9.8

# ---- Lifecycle ----

func _ready() -> void:
    # Locate component children.
    health_system = $HealthSystem
    injury_effects = $InjuryEffects
    player_input = $PlayerInput
    player_camera = $Camera3D

    # Initial eye position.
    _update_camera_position()

    # Register with global state if local.
    if is_local:
        GameState.set_local_player(self)
        if player_input:
            player_input.capture_input()
        # Register with NetworkManager (the fix from player_network.gd).
        var nm: Node = get_node_or_null("/root/NetworkManager")
        if nm and nm.has_method("register_local_player"):
            nm.register_local_player(self)

    print("[Player] ready — local=%s peer_id=%d team=%d" % [is_local, peer_id, team])

func _process(delta: float) -> void:
    # Only the local player reads input and moves itself.
    # Remote players are positioned by snapshot interpolation (Phase 4).
    if not is_local:
        return
    if health_system and health_system.is_dead:
        return

    # Update ADS state on camera + injury effects for sway.
    if player_input and health_system:
        is_in_ads = player_input.ads_held and health_system.can_ads()
        if player_camera:
            player_camera.set_ads(is_in_ads)
        if injury_effects:
            injury_effects.set_ads(is_in_ads)

    # Update crouch state.
    if player_input:
        is_crouching = player_input.crouch_held or (health_system and health_system.in_last_stand)

    # Movement.
    _handle_movement(delta)

    # Update camera height (crouch lowers eye).
    _update_camera_position()

    # Process edge-triggered inputs (debug only in Phase 1).
    if player_input:
        var triggers: Dictionary = player_input.consume_edge_triggers()
        _handle_edge_triggers(triggers)

func _handle_movement(delta: float) -> void:
    if player_input == null or health_system == null:
        return

    # Apply gravity.
    if not is_on_floor():
        velocity.y -= GRAVITY * gravity_scale * delta

    # Handle jump.
    if player_input.consume_edge_triggers().get("jump", false) and is_on_floor():
        if not is_crouching and health_system.can_sprint():
            velocity.y = jump_velocity

    # Determine target movement speed.
    var target_speed: float = _get_target_speed()

    # Get input direction in world space (relative to camera yaw).
    var input_dir: Vector2 = player_input.move_vector
    var yaw_rad: float = player_camera.get_yaw() if player_camera else 0.0
    # Forward vector (XZ plane, based on yaw).
    var forward: Vector3 = Vector3(-sin(yaw_rad), 0.0, -cos(yaw_rad))
    var right: Vector3 = Vector3(cos(yaw_rad), 0.0, -sin(yaw_rad))
    var wish_dir: Vector3 = (forward * input_dir.y + right * input_dir.x).normalized()

    # Accelerate toward wish_dir at target_speed.
    var current_horizontal: Vector3 = Vector3(velocity.x, 0.0, velocity.z)
    var target_horizontal: Vector3 = wish_dir * target_speed
    # Lerp for smooth accel/decel.
    var accel: float = 12.0 if is_on_floor() else 4.0
    current_horizontal = current_horizontal.lerp(target_horizontal, delta * accel)
    velocity.x = current_horizontal.x
    velocity.z = current_horizontal.z

    # Track current speed for HUD.
    current_speed = Vector3(velocity.x, 0.0, velocity.z).length()
    is_sprinting = player_input.sprint_held and input_dir.y > 0.0 and not is_crouching

    move_and_slide()

func _get_target_speed() -> float:
    if health_system == null:
        return walk_speed
    # Last Stand crawl.
    if health_system.in_last_stand:
        return last_stand_crawl_speed
    # Crouch.
    if is_crouching:
        return crouch_speed
    # Sprint (with leg-injury multiplier).
    if player_input and player_input.sprint_held and health_system.can_sprint():
        var sprint_mult: float = health_system.get_sprint_multiplier()
        return sprint_speed * sprint_mult
    # ADS slows movement.
    var base: float = walk_speed
    if is_in_ads:
        base *= ads_speed_multiplier
    return base

func _update_camera_position() -> void:
    if player_camera == null:
        return
    var target_height: float = eye_height
    if health_system and health_system.in_last_stand:
        target_height = last_stand_eye_height
    elif is_crouching:
        target_height = crouch_eye_height
    # Smoothly lerp camera height for crouch/stand transitions.
    var current_pos: Vector3 = player_camera.position
    var target_pos: Vector3 = Vector3(0.0, target_height, 0.0)
    player_camera.position = current_pos.lerp(target_pos, get_process_delta_time() * 8.0)

func _handle_edge_triggers(triggers: Dictionary) -> void:
    # Phase 1: debug damage keys for testing the HP system.
    # These debug bindings are removed in Phase 12 (Gate 10: zero debug code in ship build).
    if triggers.get("use", false):
        # F key — heal full (debug).
        GameState.debug_heal_full()
    # Debug damage is handled via direct key binds in project.godot:
    #   F1 = head damage, F2 = torso damage.
    # These are read here to avoid requiring the InputMap to know about GameState.
    if Input.is_action_just_pressed("debug_damage_head"):
        GameState.debug_damage_limb("head", 25)
    if Input.is_action_just_pressed("debug_damage_torso"):
        GameState.debug_damage_limb("torso", 25)

# ---- Public API ----

func set_local(local: bool) -> void:
    is_local = local

func set_team(new_team: int) -> void:
    team = new_team

func get_team() -> int:
    return team

func get_health_system() -> HealthSystem:
    return health_system

func is_alive() -> bool:
    return health_system != null and not health_system.is_dead

func is_in_last_stand() -> bool:
    return health_system != null and health_system.in_last_stand

func is_in_bloodlust() -> bool:
    return health_system != null and health_system.is_in_bloodlust()

# ---- Network hooks (Phase 4 will populate these) ----
# These are stubs that Phase 4's player_network.gd will override or supplement.
# Kept here so the Player class is network-aware from day 1.

func receive_server_snapshot(snapshot: Dictionary) -> void:
    """Called by NetworkManager when a server snapshot arrives for this player.
    Phase 4: interpolate remote players; reconcile local player."""
    if is_local:
        return  # local player doesn't get snapshotted
    # Phase 4: position interpolation.
    if snapshot.has("position"):
        global_position = snapshot["position"]
    if snapshot.has("rotation"):
        global_rotation = snapshot["rotation"]
