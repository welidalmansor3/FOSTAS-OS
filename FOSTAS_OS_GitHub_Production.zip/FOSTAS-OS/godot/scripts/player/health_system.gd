# File: scripts/player/health_system.gd
# FOSTAS: Toybox Terror — Hardcore 6-Limb Health System
#
# Per master prompt PART 2 + Module B5:
#   - 6 separate HP pools per player: head, torso, left_arm, right_arm, left_leg, right_leg
#   - 4 injury thresholds (per-limb):
#       75-100: clean
#       50-74:  minor sway (×1.3 sway, -10% sprint)
#       25-49:  heavy sway (×1.8, -25% sprint, +30% reload, red pulse)
#       1-24:   critical (×2.5 sway, walk-only, desaturated, heavy breathing)
#       0:      limb crippled; for TORSO -> Last Stand; for others -> crippled state
#   - Damage model: headshot ×4, torso ×1, limb ×0.7
#   - Last Stand: torso HP reaches 0 -> player drops prone, can crawl at 1.5 m/s,
#     can fire sidearm only, 30s bleed-out, Medic revive restores
#   - Bleed-out: 30s timer; expires -> death -> respawn after 8s at friendly castle
#   - Bloodlust (on Medic revive): 5s full HP, zero recoil, +20% speed, red tint, 1s stun end
#
# This is a pure-data node — no visual effects (those are in InjuryEffects).
# Attaches as a child of the Player node.
extends Node
class_name HealthSystem

# ---- Signals ----
signal limb_damaged(limb_name: String, damage: int, new_hp: int)
signal injury_state_changed(limb_name: String, new_state: int)
signal last_stand_entered()
signal last_stand_exited()
signal bleed_out_expired()
signal bloodlust_started()
signal bloodlust_ended()
signal died()

# ---- Enums ----
enum Limb {
    HEAD,
    TORSO,
    LEFT_ARM,
    RIGHT_ARM,
    LEFT_LEG,
    RIGHT_LEG,
}

enum InjuryState {
    CLEAN,       # 75-100% HP
    MINOR,       # 50-74%
    HEAVY,       # 25-49%
    CRITICAL,    # 1-24%
    CRIPPLED,    # 0% (limb destroyed; for torso = Last Stand)
}

# ---- Constants ----
const MAX_LIMB_HP: int = 100
const HEADSHOT_MULTIPLIER: float = 4.0
const TORSO_MULTIPLIER: float = 1.0
const LIMB_MULTIPLIER: float = 0.7
const LAST_STAND_DURATION_S: float = 30.0
const BLEED_OUT_RESPAWN_DELAY_S: float = 8.0
const BLOODLUST_DURATION_S: float = 5.0
const BLOODLUST_STUN_END_S: float = 1.0
const BLOODLUST_SPEED_MULTIPLIER: float = 1.2

# Per-limb injury thresholds (HP values).
const THRESHOLDS: Dictionary = {
    InjuryState.CLEAN:    75,
    InjuryState.MINOR:    50,
    InjuryState.HEAVY:    25,
    InjuryState.CRITICAL: 1,
}

# ---- State ----
var limb_hp: Dictionary = {
    Limb.HEAD: MAX_LIMB_HP,
    Limb.TORSO: MAX_LIMB_HP,
    Limb.LEFT_ARM: MAX_LIMB_HP,
    Limb.RIGHT_ARM: MAX_LIMB_HP,
    Limb.LEFT_LEG: MAX_LIMB_HP,
    Limb.RIGHT_LEG: MAX_LIMB_HP,
}
var limb_states: Dictionary = {}  # filled in _ready
var in_last_stand: bool = false
var bleed_out_timer: float = 0.0
var in_bloodlust: bool = false
var bloodlust_timer: float = 0.0
var bloodlust_stun_end_timer: float = 0.0
var is_dead: bool = false

# ---- Lifecycle ----

func _ready() -> void:
    for limb in limb_hp:
        limb_states[limb] = InjuryState.CLEAN

func _process(delta: float) -> void:
    # Last Stand bleed-out countdown.
    if in_last_stand and not is_dead:
        bleed_out_timer -= delta
        if bleed_out_timer <= 0.0:
            _bleed_out_expired()

    # Bloodlust timer countdown.
    if in_bloodlust:
        bloodlust_timer -= delta
        if bloodlust_timer <= 0.0:
            # Transition to stun-end phase.
            bloodlust_stun_end_timer = BLOODLUST_STUN_END_S
            in_bloodlust = false
            bloodlust_ended.emit()

    # Bloodlust stun-end countdown.
    if bloodlust_stun_end_timer > 0.0:
        bloodlust_stun_end_timer -= delta
        if bloodlust_stun_end_timer <= 0.0:
            print("[HealthSystem] Bloodlust stun-end complete.")

# ---- Damage application ----

func apply_damage_to_limb(limb_name: String, base_damage: int) -> void:
    """Apply damage to a named limb. limb_name is case-insensitive: head/torso/left_arm/etc."""
    if is_dead:
        return
    var limb: int = _parse_limb_name(limb_name)
    if limb == -1:
        push_warning("[HealthSystem] Unknown limb: %s" % limb_name)
        return

    var current_hp: int = limb_hp[limb]
    var new_hp: int = max(0, current_hp - base_damage)
    limb_hp[limb] = new_hp

    limb_damaged.emit(_limb_name(limb), base_damage, new_hp)
    _update_injury_state(limb)

    # Check for Last Stand trigger (torso HP reaches 0).
    if limb == Limb.TORSO and new_hp == 0 and not in_last_stand:
        _enter_last_stand()

    print("[HealthSystem] %s took %d dmg -> HP %d (state=%s)" % [
        _limb_name(limb), base_damage, new_hp, _state_name(limb_states[limb])
    ])

func apply_damage_with_multiplier(limb_name: String, base_damage: int) -> void:
    """Apply damage with the per-limb multiplier (head ×4, torso ×1, limb ×0.7).
    This is the canonical damage entry point for weapon hits."""
    var limb: int = _parse_limb_name(limb_name)
    if limb == -1:
        return
    var multiplier: float = _get_limb_multiplier(limb)
    # Round to nearest int (minimum 1 damage if hit landed).
    var scaled: int = max(1, int(round(base_damage * multiplier)))
    apply_damage_to_limb(limb_name, scaled)

func heal_limb(limb_name: String, amount: int) -> void:
    """Heal a specific limb by amount (capped at MAX_LIMB_HP)."""
    var limb: int = _parse_limb_name(limb_name)
    if limb == -1:
        return
    limb_hp[limb] = min(MAX_LIMB_HP, limb_hp[limb] + amount)
    _update_injury_state(limb)

func heal_all_limbs(amount: int) -> void:
    """Heal all 6 limbs by amount."""
    for limb in limb_hp:
        limb_hp[limb] = min(MAX_LIMB_HP, limb_hp[limb] + amount)
        _update_injury_state(limb)

func heal_full() -> void:
    """Restore all limbs to full HP and exit Last Stand."""
    for limb in limb_hp:
        limb_hp[limb] = MAX_LIMB_HP
        limb_states[limb] = InjuryState.CLEAN
    if in_last_stand:
        _exit_last_stand()
    is_dead = false

# ---- Last Stand / Bleed-out ----

func _enter_last_stand() -> void:
    in_last_stand = true
    bleed_out_timer = LAST_STAND_DURATION_S
    last_stand_entered.emit()
    print("[HealthSystem] LAST STAND entered — bleed-out %.1fs" % LAST_STAND_DURATION_S)

func _exit_last_stand() -> void:
    in_last_stand = false
    bleed_out_timer = 0.0
    last_stand_exited.emit()

func _bleed_out_expired() -> void:
    """Bleed-out timer expired — player dies."""
    is_dead = true
    in_last_stand = false
    bleed_out_expired.emit()
    died.emit()
    print("[HealthSystem] BLEED OUT — player died. Respawn in %.1fs" % BLEED_OUT_RESPAWN_DELAY_S)

func revive() -> void:
    """Medic revive — restores torso to 50%, all limbs to 25%, triggers Bloodlust."""
    if not in_last_stand:
        push_warning("[HealthSystem] revive() called but player not in Last Stand.")
        return
    limb_hp[Limb.TORSO] = 50
    limb_hp[Limb.HEAD] = max(limb_hp[Limb.HEAD], 25)
    limb_hp[Limb.LEFT_ARM] = max(limb_hp[Limb.LEFT_ARM], 25)
    limb_hp[Limb.RIGHT_ARM] = max(limb_hp[Limb.RIGHT_ARM], 25)
    limb_hp[Limb.LEFT_LEG] = max(limb_hp[Limb.LEFT_LEG], 25)
    limb_hp[Limb.RIGHT_LEG] = max(limb_hp[Limb.RIGHT_LEG], 25)
    for limb in limb_hp:
        _update_injury_state(limb)
    _exit_last_stand()
    _start_bloodlust()

# ---- Bloodlust ----

func _start_bloodlust() -> void:
    in_bloodlust = true
    bloodlust_timer = BLOODLUST_DURATION_S
    bloodlust_stun_end_timer = 0.0
    # Full HP during Bloodlust.
    for limb in limb_hp:
        limb_hp[limb] = MAX_LIMB_HP
        limb_states[limb] = InjuryState.CLEAN
    bloodlust_started.emit()
    print("[HealthSystem] BLOODLUST started — %.1fs (then %.1fs stun-end)" % [
        BLOODLUST_DURATION_S, BLOODLUST_STUN_END_S
    ])

func is_in_bloodlust() -> bool:
    return in_bloodlust

func is_in_bloodlust_stun_end() -> bool:
    return bloodlust_stun_end_timer > 0.0

# ---- Query API ----

func get_limb_hp(limb: int) -> int:
    return limb_hp.get(limb, 0)

func get_limb_state(limb: int) -> int:
    return limb_states.get(limb, InjuryState.CLEAN)

func get_worst_limb_state() -> int:
    """Return the worst injury state across all limbs (for global effects)."""
    var worst: int = InjuryState.CLEAN
    for limb in limb_states:
        if limb_states[limb] > worst:
            worst = limb_states[limb]
    return worst

func get_sprint_multiplier() -> float:
    """Returns the movement sprint multiplier based on leg injury states."""
    if in_last_stand or is_dead:
        return 0.0  # cannot sprint
    if in_bloodlust:
        return BLOODLUST_SPEED_MULTIPLIER
    var left_state: int = limb_states[Limb.LEFT_LEG]
    var right_state: int = limb_states[Limb.RIGHT_LEG]
    # Use the worse of the two legs.
    var worst: int = max(left_state, right_state)
    match worst:
        InjuryState.CLEAN: return 1.0
        InjuryState.MINOR: return 0.9   # -10%
        InjuryState.HEAVY: return 0.75  # -25%
        InjuryState.CRITICAL: return 0.0  # walk only
        InjuryState.CRIPPLED: return 0.0
        _: return 1.0

func get_sway_multiplier() -> float:
    """Returns the weapon sway multiplier based on arm injury states + bloodlust."""
    if in_bloodlust:
        return 0.0  # zero recoil during Bloodlust
    var left_state: int = limb_states[Limb.LEFT_ARM]
    var right_state: int = limb_states[Limb.RIGHT_ARM]
    var worst: int = max(left_state, right_state)
    match worst:
        InjuryState.CLEAN: return 1.0
        InjuryState.MINOR: return 1.3
        InjuryState.HEAVY: return 1.8
        InjuryState.CRITICAL: return 2.5
        InjuryState.CRIPPLED: return 3.0
        _: return 1.0

func get_reload_multiplier() -> float:
    """Returns the reload time multiplier based on arm injury states."""
    if in_bloodlust:
        return 0.5  # faster reloads during Bloodlust (zero-recoil theme)
    var left_state: int = limb_states[Limb.LEFT_ARM]
    var right_state: int = limb_states[Limb.RIGHT_ARM]
    var worst: int = max(left_state, right_state)
    match worst:
        InjuryState.HEAVY: return 1.3  # +30%
        InjuryState.CRITICAL: return 1.5
        InjuryState.CRIPPLED: return 2.0
        _: return 1.0

func can_sprint() -> bool:
    return get_sprint_multiplier() > 0.0

func can_ads() -> bool:
    # Cannot ADS with critical+ arm injury.
    var worst: int = max(limb_states[Limb.LEFT_ARM], limb_states[Limb.RIGHT_ARM])
    return worst < InjuryState.CRITICAL

func can_fire_primary() -> bool:
    # Cannot fire primary during Last Stand (sidearm only).
    return not in_last_stand and not is_dead

func get_hp_summary() -> Dictionary:
    """Return a summary of all limb HPs for debug display."""
    var summary: Dictionary = {}
    for limb in limb_hp:
        summary[_limb_name(limb)] = {
            "hp": limb_hp[limb],
            "state": _state_name(limb_states[limb]),
        }
    summary["in_last_stand"] = in_last_stand
    summary["bleed_out_remaining"] = bleed_out_timer
    summary["in_bloodlust"] = in_bloodlust
    summary["is_dead"] = is_dead
    return summary

# ---- Internal helpers ----

func _update_injury_state(limb: int) -> void:
    var old_state: int = limb_states[limb]
    var new_state: int = _compute_injury_state(limb_hp[limb])
    if old_state != new_state:
        limb_states[limb] = new_state
        injury_state_changed.emit(_limb_name(limb), new_state)

func _compute_injury_state(hp: int) -> int:
    if hp == 0:
        return InjuryState.CRIPPLED
    if hp < THRESHOLDS[InjuryState.CRITICAL]:
        return InjuryState.CRIPPLED  # shouldn't reach, but safe
    if hp < THRESHOLDS[InjuryState.HEAVY]:
        return InjuryState.CRITICAL
    if hp < THRESHOLDS[InjuryState.MINOR]:
        return InjuryState.HEAVY
    if hp < THRESHOLDS[InjuryState.CLEAN]:
        return InjuryState.MINOR
    return InjuryState.CLEAN

func _get_limb_multiplier(limb: int) -> float:
    match limb:
        Limb.HEAD: return HEADSHOT_MULTIPLIER
        Limb.TORSO: return TORSO_MULTIPLIER
        _: return LIMB_MULTIPLIER

func _parse_limb_name(name: String) -> int:
    match name.to_lower():
        "head": return Limb.HEAD
        "torso": return Limb.TORSO
        "left_arm", "larm", "l_arm": return Limb.LEFT_ARM
        "right_arm", "rarm", "r_arm": return Limb.RIGHT_ARM
        "left_leg", "lleg", "l_leg": return Limb.LEFT_LEG
        "right_leg", "rleg", "r_leg": return Limb.RIGHT_LEG
        _: return -1

func _limb_name(limb: int) -> String:
    match limb:
        Limb.HEAD: return "head"
        Limb.TORSO: return "torso"
        Limb.LEFT_ARM: return "left_arm"
        Limb.RIGHT_ARM: return "right_arm"
        Limb.LEFT_LEG: return "left_leg"
        Limb.RIGHT_LEG: return "right_leg"
        _: return "unknown"

func _state_name(state: int) -> String:
    match state:
        InjuryState.CLEAN: return "CLEAN"
        InjuryState.MINOR: return "MINOR"
        InjuryState.HEAVY: return "HEAVY"
        InjuryState.CRITICAL: return "CRITICAL"
        InjuryState.CRIPPLED: return "CRIPPLED"
        _: return "UNKNOWN"
