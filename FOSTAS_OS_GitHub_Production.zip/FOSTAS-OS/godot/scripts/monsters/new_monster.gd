# File: scripts/monsters/new_monster.gd
# FOSTAS: Toybox Terror — Generic Monster (reusable AI creature template)
# A clean re-implementation of the ShadowMonster pattern: CharacterBody3D with a
# state machine (IDLE / WANDER / CHASE / ATTACK / DEAD) that finds players via
# the "players" group instead of relying on Area3D child nodes that may not exist.
# Designed to be safely spawned at runtime by the FOSTAS orchestrator or by a
# level script without requiring a pre-built scene hierarchy.
extends CharacterBody3D
class_name NewMonster

@export var max_health: int = 100
@export var move_speed: float = 5.0
@export var attack_damage: int = 25
@export var detection_range: float = 15.0
@export var attack_range: float = 2.0
@export var attack_cooldown: float = 1.0
@export var respawn_time: float = 5.0
@export var wander_interval_range: Vector2 = Vector2(2.0, 5.0)

enum State { IDLE, WANDER, CHASE, ATTACK, DEAD }

var current_health: int = 100
var current_state: int = State.IDLE
var _target: Node3D = null
var _attack_timer: float = 0.0
var _wander_direction: Vector3 = Vector3.ZERO
var _wander_timer: float = 0.0
var _respawn_timer: float = 0.0

signal died(monster: Node3D)
signal hit_player(player: Node3D, damage: int)
signal respawned(monster: Node3D)

func _ready() -> void:
    current_health = max_health
    current_state = State.WANDER
    _pick_new_wander_direction()

func take_damage(amount: int) -> void:
    if current_state == State.DEAD:
        return
    current_health = max(0, current_health - amount)
    if current_health == 0:
        die()

func die() -> void:
    current_state = State.DEAD
    _target = null
    velocity = Vector3.ZERO
    visible = false
    set_physics_process(false)  # Halt AI; respawn timer runs via _process.
    set_process(true)  # Ensure _process keeps running for respawn countdown.
    died.emit(self)

func _process(delta: float) -> void:
    # Respawn countdown runs in _process so it works even when physics is paused.
    if current_state == State.DEAD:
        _respawn_timer -= delta
        if _respawn_timer <= 0.0:
            _respawn()

func _physics_process(delta: float) -> void:
    if current_state == State.DEAD:
        return
    _attack_timer = max(0.0, _attack_timer - delta)
    _update_state_machine(delta)
    move_and_slide()

func _update_state_machine(delta: float) -> void:
    var player: Node3D = _find_nearest_player()
    var dist_to_player: float = (
        global_position.distance_to(player.global_position)
        if player and is_instance_valid(player) else INF
    )

    match current_state:
        State.IDLE:
            if player and dist_to_player < detection_range:
                current_state = State.CHASE
                _target = player
            else:
                _wander_timer -= delta
                if _wander_timer <= 0.0:
                    current_state = State.WANDER
                    _pick_new_wander_direction()

        State.WANDER:
            if player and dist_to_player < detection_range:
                current_state = State.CHASE
                _target = player
            else:
                velocity = _wander_direction * move_speed * 0.5
                _wander_timer -= delta
                if _wander_timer <= 0.0:
                    current_state = State.IDLE
                    _wander_timer = randf_range(1.0, 2.0)

        State.CHASE:
            if not _target or not is_instance_valid(_target):
                current_state = State.WANDER
                _target = null
                return
            if dist_to_player <= attack_range:
                current_state = State.ATTACK
            elif dist_to_player > detection_range * 1.5:
                current_state = State.WANDER
                _target = null
            else:
                var direction: Vector3 = (_target.global_position - global_position).normalized()
                velocity = direction * move_speed

        State.ATTACK:
            if not _target or not is_instance_valid(_target):
                current_state = State.WANDER
                _target = null
                return
            if dist_to_player > attack_range * 1.2:
                current_state = State.CHASE
            elif _attack_timer <= 0.0:
                hit_player.emit(_target, attack_damage)
                _attack_timer = attack_cooldown
            velocity = Vector3.ZERO

func _find_nearest_player() -> Node3D:
    # Robust lookup that doesn't require any Area3D child nodes — matches the
    # pattern used by ShadowMonster. Players add themselves to the "players"
    # group on _ready().
    var players: Array[Node] = get_tree().get_nodes_in_group("players")
    var nearest: Node3D = null
    var nearest_dist: float = INF
    for p in players:
        if not (p is Node3D) or not is_instance_valid(p):
            continue
        var d: float = global_position.distance_to(p.global_position)
        if d < nearest_dist and d < detection_range:
            nearest_dist = d
            nearest = p
    return nearest

func _pick_new_wander_direction() -> void:
    var rand_angle: float = randf() * TAU
    _wander_direction = Vector3(cos(rand_angle), 0.0, sin(rand_angle))
    _wander_timer = randf_range(wander_interval_range.x, wander_interval_range.y)

func _respawn() -> void:
    current_health = max_health
    current_state = State.WANDER
    _target = null
    _attack_timer = 0.0
    visible = true
    set_physics_process(true)
    _pick_new_wander_direction()
    respawned.emit(self)
