# File: scripts/monsters/shadow_monster.gd
# FOSTAS: Toybox Terror — Shadow Monster (FOSTAS Event creature)
# Spawns during the 20-second Hunt phase. AI state machine: IDLE -> WANDER -> CHASE -> ATTACK.
extends CharacterBody3D
class_name ShadowMonster

@export var max_health: int = 100
@export var move_speed: float = 5.0
@export var attack_damage: int = 25
@export var attack_range: float = 2.0
@export var detection_range: float = 15.0
@export var attack_cooldown: float = 1.0

enum State { IDLE, WANDER, CHASE, ATTACK, DEAD }

var health: int = 100
var current_state: int = State.IDLE
var _target: Node3D = null
var _attack_timer: float = 0.0
var _wander_direction: Vector3 = Vector3.ZERO
var _wander_timer: float = 0.0

signal died(monster: Node3D)
signal hit_player(player: Node3D, damage: int)

func _ready() -> void:
    health = max_health
    current_state = State.WANDER
    _pick_new_wander_direction()

func take_damage(amount: int) -> void:
    if current_state == State.DEAD:
        return
    health = max(0, health - amount)
    if health == 0:
        die()

func die() -> void:
    current_state = State.DEAD
    died.emit(self)
    visible = false
    process_mode = Node.PROCESS_MODE_DISABLED

func _physics_process(delta: float) -> void:
    if current_state == State.DEAD:
        return
    _attack_timer = max(0.0, _attack_timer - delta)
    _update_state_machine(delta)
    move_and_slide()

func _update_state_machine(delta: float) -> void:
    var player: Node3D = _find_nearest_player()
    var dist_to_player: float = global_position.distance_to(player.global_position) if player else INF

    match current_state:
        State.IDLE:
            if player and dist_to_player < detection_range:
                current_state = State.CHASE
                _target = player
            else:
                _wander_timer -= delta
                if _wander_timer <= 0.0:
                    current_state = State.WANDER
                    _pick_new_wander_direction()

        State.WANDER:
            if player and dist_to_player < detection_range:
                current_state = State.CHASE
                _target = player
            else:
                velocity = _wander_direction * move_speed * 0.5
                _wander_timer -= delta
                if _wander_timer <= 0.0:
                    _pick_new_wander_direction()

        State.CHASE:
            if not _target or not is_instance_valid(_target):
                current_state = State.WANDER
                return
            if dist_to_player <= attack_range:
                current_state = State.ATTACK
            elif dist_to_player > detection_range * 1.5:
                current_state = State.WANDER
                _target = null
            else:
                var direction: Vector3 = (_target.global_position - global_position).normalized()
                velocity = direction * move_speed

        State.ATTACK:
            if not _target or not is_instance_valid(_target):
                current_state = State.WANDER
                return
            if dist_to_player > attack_range * 1.2:
                current_state = State.CHASE
            elif _attack_timer <= 0.0:
                hit_player.emit(_target, attack_damage)
                _attack_timer = attack_cooldown
            velocity = Vector3.ZERO

func _find_nearest_player() -> Node3D:
    var players: Array[Node] = get_tree().get_nodes_in_group("players")
    var nearest: Node3D = null
    var nearest_dist: float = INF
    for p in players:
        if not p is Node3D:
            continue
        var d: float = global_position.distance_to(p.global_position)
        if d < nearest_dist and d < detection_range:
            nearest_dist = d
            nearest = p
    return nearest

func _pick_new_wander_direction() -> void:
    var rand_angle: float = randf() * TAU
    _wander_direction = Vector3(cos(rand_angle), 0.0, sin(rand_angle))
    _wander_timer = randf_range(2.0, 5.0)
