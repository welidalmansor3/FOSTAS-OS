# File: scripts/weapons/toy_sniper_rifle.gd
# FOSTAS: Toybox Terror — Toy Sniper Rifle (toy-reskin of a bolt-action marksman rifle)
# Long-range, high-damage, slow-cycling precision weapon. RED/BLUE team emissive trim.
# Reuses the parent Weapon class for fire()/reload()/ammo tracking and adds:
#   - bolt-action cycling delay between shots
#   - 4x headshot multiplier (inherited from base damage model)
#   - piercing hitscan ray (single target, server-authoritative in real multiplayer)
extends Weapon
class_name ToySniperRifle

# Sniper-specific tuning (overrides Weapon defaults via _ready).
# Damage model per GameBible: headshot x4 / torso x1 / limb x0.75.
@export var bolt_cycle_time: float = 1.0  # Seconds between shots (bolt action).
@export var ads_speed_multiplier: float = 0.45  # Move speed while aiming down sights.

# Internal cycling state.
var _bolt_cycling: bool = false
var _bolt_timer: float = 0.0

func _ready() -> void:
    weapon_name = "Toy Sniper Rifle"
    damage = 80
    fire_rate = 60.0  # 60 RPM = 1 shot/sec ceiling, further clamped by bolt_cycle_time.
    magazine_size = 10
    range_m = 200.0
    reload_time = 3.0
    team_color = Color(0.9, 0.22, 0.27)  # RED default; overridden by spawner for BLUE.
    super._ready()

func _process(delta: float) -> void:
    # Bolt-action cycling countdown (independent of magazine reload).
    if _bolt_cycling:
        _bolt_timer -= delta
        if _bolt_timer <= 0.0:
            _bolt_cycling = false
    super._process(delta)

func can_fire() -> bool:
    if _bolt_cycling:
        return false
    return super.can_fire()

func fire(from_position: Vector3, direction: Vector3) -> Dictionary:
    # Delegate the actual hit detection to the parent class, then enforce the
    # bolt-action cycling cooldown that is unique to this weapon.
    var hit_result: Dictionary = super.fire(from_position, direction)
    if hit_result.has("reason") and hit_result["reason"] == "cannot_fire":
        return hit_result
    if hit_result.get("hit", false) or hit_result.get("ammo_left", -1) != current_ammo + 1:
        # A round was actually consumed — start the bolt cycle.
        _bolt_cycling = true
        _bolt_timer = bolt_cycle_time
    return hit_result

func get_ads_move_multiplier() -> float:
    # Called by the player controller when ADS is held.
    return ads_speed_multiplier
