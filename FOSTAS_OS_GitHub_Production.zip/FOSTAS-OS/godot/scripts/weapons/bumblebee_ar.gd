# File: scripts/weapons/bumblebee_ar.gd
# FOSTAS: Toybox Terror — BumbleBee AR (Toy reskin of Steyr AUG A1)
extends Weapon
class_name BumbleBeeAR

func _ready() -> void:
    weapon_name = "BumbleBee AR"
    damage = 22
    fire_rate = 700.0
    magazine_size = 30
    range_m = 60.0
    reload_time = 2.2
    super._ready()
