# File: scripts/autoload/team_manager.gd
# FOSTAS: Toybox Terror — Team Manager (autoload)
#
# RED vs BLUE team assignment with auto-balance.
# Singleton at /root/TeamManager.
#
# Rules (per master prompt PART 2 + Module B4):
#   - Two factions only: RED (west castle spawn) and BLUE (east castle spawn).
#   - No other color permitted anywhere in the project.
#   - Max 3 of one class per 5-player team (auto-balance enforcement).
#   - Bots fill empty slots to guarantee 5v5 minimum.
extends Node
class_name TeamManager

# ---- Signals ----
signal team_assigned(peer_id: int, team: int)
signal class_assigned(peer_id: int, class_id: int)

# ---- Enums ----
enum Team {
    NONE = 0,
    RED = 1,
    BLUE = 2,
}

enum ClassID {
    NONE = 0,
    MEDIC = 1,
    MAGE = 2,
}

# ---- Constants ----
const TEAM_SIZE: int = 5
const MAX_SAME_CLASS_PER_TEAM: int = 3
const TEAM_COLORS: Dictionary = {
    Team.RED: Color(0.9, 0.22, 0.27),    # #E63946
    Team.BLUE: Color(0.114, 0.435, 0.722), # #1D6FB8
}
const CUTE_PALETTE: Dictionary = {
    "candy_red": Color(1.0, 0.231, 0.361),      # #FF3B5C
    "electric_blue": Color(0.231, 0.659, 1.0),  # #3BA8FF
    "sunshine_yellow": Color(1.0, 0.823, 0.231),# #FFD23B
    "mint_green": Color(0.294, 0.91, 0.659),    # #4BE8A8
    "soft_cream": Color(1.0, 0.965, 0.878),     # #FFF6E0
    "sky_blue": Color(0.749, 0.914, 1.0),       # #BFE9FF
}
const HORROR_PALETTE: Dictionary = {
    "pure_black": Color(0.039, 0.039, 0.059),  # #0A0A0F
    "blood_red": Color(0.69, 0.0, 0.125),       # #B00020
    "cold_cyan": Color(0.122, 0.714, 0.788),    # #1FB6C9
    "fog_white": Color(0.788, 0.839, 0.863),    # #C9D6DC
}

# ---- State (server-authoritative) ----
# peer_id -> {team, class, ready}
var _player_assignments: Dictionary = {}

# ---- Public API ----

func assign_team(peer_id: int, requested_team: int = Team.NONE) -> int:
    """Assign a player to a team. If requested_team is NONE or full, auto-balance.
    Returns the assigned team."""
    if not NetworkManager.is_server:
        push_warning("[TeamManager] assign_team called on non-server; ignored.")
        return Team.NONE

    # If already assigned, return current.
    if _player_assignments.has(peer_id):
        return _player_assignments[peer_id]["team"]

    # Validate requested team has space.
    var team: int = requested_team
    if team != Team.NONE and _count_team(team) >= TEAM_SIZE:
        team = Team.NONE  # requested team full, auto-balance
    if team == Team.NONE:
        team = _auto_balance_team()

    _player_assignments[peer_id] = {
        "team": team,
        "class": ClassID.NONE,
        "ready": false,
    }
    team_assigned.emit(peer_id, team)
    print("[TeamManager] Peer %d assigned to %s" % [peer_id, _team_name(team)])
    return team

func assign_class(peer_id: int, class_id: int) -> bool:
    """Assign a player to a class. Returns false if class cap reached."""
    if not NetworkManager.is_server:
        return false
    if not _player_assignments.has(peer_id):
        push_warning("[TeamManager] Cannot assign class to unassigned peer %d" % peer_id)
        return false

    var team: int = _player_assignments[peer_id]["team"]
    # Enforce max 3 of one class per team.
    if _count_class_in_team(team, class_id) >= MAX_SAME_CLASS_PER_TEAM:
        push_warning("[TeamManager] Class %s cap reached for %s" % [_class_name(class_id), _team_name(team)])
        return false

    _player_assignments[peer_id]["class"] = class_id
    class_assigned.emit(peer_id, class_id)
    return true

func set_ready(peer_id: int, ready: bool) -> void:
    if _player_assignments.has(peer_id):
        _player_assignments[peer_id]["ready"] = ready

func remove_player(peer_id: int) -> void:
    _player_assignments.erase(peer_id)

func get_team(peer_id: int) -> int:
    if _player_assignments.has(peer_id):
        return _player_assignments[peer_id]["team"]
    return Team.NONE

func get_class(peer_id: int) -> int:
    if _player_assignments.has(peer_id):
        return _player_assignments[peer_id]["class"]
    return ClassID.NONE

func is_ready(peer_id: int) -> bool:
    if _player_assignments.has(peer_id):
        return _player_assignments[peer_id]["ready"]
    return false

func all_ready() -> bool:
    """True if all assigned players are ready (min 2 per team for testing)."""
    var red_count: int = 0
    var blue_count: int = 0
    for peer_id in _player_assignments:
        var a: Dictionary = _player_assignments[peer_id]
        if not a["ready"]:
            return false
        if a["team"] == Team.RED:
            red_count += 1
        elif a["team"] == Team.BLUE:
            blue_count += 1
    return red_count >= 2 and blue_count >= 2

func get_team_color(team: int) -> Color:
    """Get the canonical team color for a team enum value."""
    return TEAM_COLORS.get(team, Color.WHITE)

func get_teammates(peer_id: int) -> Array:
    """Return all peer_ids on the same team as peer_id (excluding peer_id)."""
    if not _player_assignments.has(peer_id):
        return []
    var my_team: int = _player_assignments[peer_id]["team"]
    var teammates: Array = []
    for other_id in _player_assignments:
        if other_id == peer_id:
            continue
        if _player_assignments[other_id]["team"] == my_team:
            teammates.append(other_id)
    return teammates

# ---- Internal helpers ----

func _count_team(team: int) -> int:
    var count: int = 0
    for peer_id in _player_assignments:
        if _player_assignments[peer_id]["team"] == team:
            count += 1
    return count

func _count_class_in_team(team: int, class_id: int) -> int:
    var count: int = 0
    for peer_id in _player_assignments:
        var a: Dictionary = _player_assignments[peer_id]
        if a["team"] == team and a["class"] == class_id:
            count += 1
    return count

func _auto_balance_team() -> int:
    """Return the team with fewer players. If tied, pick RED."""
    var red: int = _count_team(Team.RED)
    var blue: int = _count_team(Team.BLUE)
    if red <= blue:
        return Team.RED
    return Team.BLUE

func _team_name(team: int) -> String:
    match team:
        Team.RED: return "RED"
        Team.BLUE: return "BLUE"
        _: return "NONE"

func _class_name(class_id: int) -> String:
    match class_id:
        ClassID.MEDIC: return "MEDIC"
        ClassID.MAGE: return "MAGE"
        _: return "NONE"
