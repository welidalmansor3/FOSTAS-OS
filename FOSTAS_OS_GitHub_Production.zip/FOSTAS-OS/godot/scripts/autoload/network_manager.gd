# File: scripts/autoload/network_manager.gd
# FOSTAS: Toybox Terror — Network Manager (autoload)
#
# Server-authoritative multiplayer framework. Singleton at /root/NetworkManager.
#
# Responsibilities:
#   - Track peer connections (server-side)
#   - Route RPCs between server and clients
#   - Maintain a snapshot history buffer for lag-compensated hit validation
#   - Provide a server-rolled match-time clock (drift-corrected on clients)
#   - Expose helpers for player registration (called by player_network.gd)
#
# Networking model:
#   - Dedicated server = peer 1 (always authoritative)
#   - Clients = peers 2..N
#   - Server ticks at 20 Hz (50 ms); clients send inputs at 60 Hz
#   - Snapshot interpolation buffer: 100 ms (3 server ticks)
#   - Lag compensation rewind window: 200 ms
#
# Phase 1 scope: this autoload provides the FRAMEWORK only — no gameplay RPCs yet.
# Phase 4 will add match-flow RPCs (lobby, ready-check, round transitions).
# Phase 2 will add combat RPCs (fire, hit validation).
extends Node
class_name NetworkManager

# ---- Signals ----
signal peer_connected(peer_id: int)
signal peer_disconnected(peer_id: int)
signal server_started()
signal connected_to_server()
signal connection_failed()
signal match_time_tick(match_time_seconds: float)

# ---- Constants ----
const SERVER_TICK_HZ: float = 20.0
const SERVER_TICK_DELTA: float = 1.0 / SERVER_TICK_HZ  # 0.05s
const CLIENT_SEND_HZ: float = 60.0
const SNAPSHOT_BUFFER_MS: float = 100.0
const LAG_COMP_MS: float = 200.0
const SNAPSHOT_HISTORY_SIZE: int = 16  # 16 * 50ms = 800ms of rewind history
const RECONNECT_WINDOW_S: float = 90.0

# ---- State ----
var is_server: bool = false
var is_online: bool = false
var local_peer_id: int = 0
var server_port: int = 7777
var server_address: String = "127.0.0.1"
var max_clients: int = 12  # 10 players + 2 spectators for 5v5

# Registered players (peer_id -> Player node path). Server-only authoritative.
var _registered_players: Dictionary = {}

# Snapshot history for lag compensation. Each entry: {tick, timestamp, world_state}
# world_state is a Dictionary of peer_id -> {position, rotation, etc.}
var _snapshot_history: Array = []
var _current_tick: int = 0
var _match_time_seconds: float = 0.0
var _tick_accumulator: float = 0.0

# ---- Lifecycle ----

func _ready() -> void:
    # Connect multiplayer signals (always — works for both server and client).
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_to_server)
    multiplayer.connection_failed.connect(_on_connection_failed)
    print("[NetworkManager] ready (offline). Call host_game() or join_game() to go online.")

func _process(delta: float) -> None:
    # Match-time clock advances on both server and client, but the server is
    # authoritative — clients drift-correct via _sync_match_time RPC.
    _tick_accumulator += delta
    if _tick_accumulator >= SERVER_TICK_DELTA:
        _tick_accumulator -= SERVER_TICK_DELTA
        _advance_tick()

func _advance_tick() -> void:
    _current_tick += 1
    _match_time_seconds += SERVER_TICK_DELTA
    match_time_tick.emit(_match_time_seconds)

    # Server-side: every tick, broadcast a snapshot to all clients.
    # (Phase 1 stub — actual snapshot broadcast added in Phase 4.)
    if is_server and is_online:
        _record_snapshot()
        # _broadcast_snapshot()  # enabled in Phase 4

# ---- Server / Client lifecycle ----

func host_game(port: int = 7777) -> bool:
    """Start as dedicated server. Returns true on success."""
    server_port = port
    is_server = true
    is_online = true
    local_peer_id = 1

    var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
    var err: int = peer.create_server(port, max_clients)
    if err != OK:
        push_error("[NetworkManager] Failed to create server on port %d: error %d" % [port, err])
        is_server = false
        is_online = false
        return false
    multiplayer.multiplayer_peer = peer
    print("[NetworkManager] Server started on port %d (max %d clients)" % [port, max_clients])
    server_started.emit()
    return true

func join_game(address: String, port: int = 7777) -> bool:
    """Join a server as client. Returns true on success (connection initiated)."""
    server_address = address
    server_port = port
    is_server = false
    is_online = false  # set true on connected_to_server signal

    var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
    var err: int = peer.create_client(address, port)
    if err != OK:
        push_error("[NetworkManager] Failed to create client to %s:%d: error %d" % [address, port, err])
        return false
    multiplayer.multiplayer_peer = peer
    print("[NetworkManager] Joining %s:%d ..." % [address, port])
    return true

func disconnect_game() -> void:
    """Disconnect from the current game (or stop hosting)."""
    if multiplayer.multiplayer_peer:
        multiplayer.multiplayer_peer.close()
        multiplayer.multiplayer_peer = null
    is_server = false
    is_online = false
    local_peer_id = 0
    _registered_players.clear()
    _snapshot_history.clear()
    print("[NetworkManager] Disconnected.")

# ---- Player registration (called by player_network.gd) ----

func register_local_player(player: Node) -> void:
    """Register the local player with this network manager."""
    local_peer_id = multiplayer.get_unique_id()
    _registered_players[local_peer_id] = player.get_path()
    print("[NetworkManager] Local player registered: peer_id=%d" % local_peer_id)

func register_remote_player(peer_id: int, player_path: NodePath) -> void:
    """Register a remote player (server-side authoritative)."""
    if is_server:
        _registered_players[peer_id] = player_path

func unregister_player(peer_id: int) -> void:
    _registered_players.erase(peer_id)

func get_player(peer_id: int) -> Node:
    """Get the player node for a given peer_id, or null if not registered."""
    var path: Variant = _registered_players.get(peer_id)
    if path == null:
        return null
    return get_node_or_null(path)

func get_all_players() -> Array:
    """Return all registered player nodes."""
    var players: Array = []
    for peer_id in _registered_players:
        var p: Node = get_player(peer_id)
        if p and is_instance_valid(p):
            players.append(p)
    return players

# ---- Snapshot history (for lag compensation) ----

func _record_snapshot() -> void:
    """Record the current world state into the snapshot history. Server-side only."""
    var snapshot: Dictionary = {
        "tick": _current_tick,
        "timestamp": Time.get_ticks_msec(),
        "players": {},
    }
    for peer_id in _registered_players:
        var player: Node = get_player(peer_id)
        if player and is_instance_valid(player) and player is Node3D:
            snapshot["players"][peer_id] = {
                "position": player.global_position,
                "rotation": player.global_rotation,
            }
    _snapshot_history.append(snapshot)
    # Trim to history size.
    while _snapshot_history.size() > SNAPSHOT_HISTORY_SIZE:
        _snapshot_history.pop_front()

func get_snapshot_at_time(rewind_ms: float) -> Dictionary:
    """Get the snapshot closest to (now - rewind_ms). Server-side only.
    Returns empty dict if no suitable snapshot found."""
    if not is_server:
        return {}
    var target_time: int = Time.get_ticks_msec() - int(rewind_ms)
    # Find the snapshot with timestamp closest to target_time.
    var best: Dictionary = {}
    var best_diff: int = 9223372036854775807  # INT_MAX
    for snap in _snapshot_history:
        var diff: int = abs(int(snap["timestamp"]) - target_time)
        if diff < best_diff:
            best_diff = diff
            best = snap
    # Reject if too far off (> 1.5 ticks = 75ms tolerance).
    if best_diff > 75:
        return {}
    return best

# ---- Match-time clock sync (server -> client) ----

@rpc("authority", "call_remote", "reliable")
func _sync_match_time(server_match_time: float, server_tick: int) -> void:
    """Server broadcasts match-time; client drift-corrects."""
    if is_server:
        return  # server is authoritative, ignore
    var drift: float = server_match_time - _match_time_seconds
    if abs(drift) > 0.05:  # > 50ms drift, hard-correct
        _match_time_seconds = server_match_time
        _current_tick = server_tick
        print("[NetworkManager] Match-time hard-corrected by %.3fs" % drift)

func get_match_time() -> float:
    return _match_time_seconds

func get_current_tick() -> int:
    return _current_tick

# ---- Signal handlers ----

func _on_peer_connected(peer_id: int) -> void:
    print("[NetworkManager] Peer connected: %d" % peer_id)
    peer_connected.emit(peer_id)

func _on_peer_disconnected(peer_id: int) -> void:
    print("[NetworkManager] Peer disconnected: %d" % peer_id)
    unregister_player(peer_id)
    peer_disconnected.emit(peer_id)

func _on_connected_to_server() -> void:
    is_online = true
    local_peer_id = multiplayer.get_unique_id()
    print("[NetworkManager] Connected to server as peer %d" % local_peer_id)
    connected_to_server.emit()

func _on_connection_failed() -> void:
    is_online = false
    push_error("[NetworkManager] Connection failed.")
    connection_failed.emit()
