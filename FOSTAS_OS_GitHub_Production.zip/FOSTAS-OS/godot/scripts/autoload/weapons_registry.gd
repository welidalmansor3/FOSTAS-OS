# File: scripts/autoload/weapons_registry.gd
# FOSTAS: Toybox Terror — Central registry of all weapon classes
#
# Corrected per FOSTAS Development Report Appendix A — the actual iq-free.zip
# asset pack contains 11 weapons. Earlier versions listed PartyPopper and
# BalloonBomber (incorrect — those GLTFs are not in the pack).
#
# The 11 weapons + sidearm:
#   1. BumbleBee AR (low-poly_aug_a1, Steyr AUG A1)
#   2. Plasma Carbine (low-poly_fn_arka, FN ARKA)
#   3. Laser Marksman (low-poly_hk_mr762, H&K MR762)
#   4. BuzzBee SMG (low-poly_kriss_vector, KRISS Vector)
#   5. Hornet SMG (low-poly_pp-19_vityaz-sn, PP-19 Vityaz)
#   6. Star Sniper (low-poly_psl_rifle, PSL DMR)
#   7. Stinger LMG (low-poly_rpk-74n, RPK-74N, bipod)
#   8. Confetti Cannon (low-poly_saiga_410, Saiga-410)
#   9. Bubble Blaster (low-poly_six_12, Six12)
#  10. Pop-Pop-12 (low-poly_sko-12, SKO-12 bullpup)
#  11. Whisper Sniper (low-poly_vsk-94, VSK-94 suppressed)
#  + Toy Blaster Pistol (sidearm — must be modeled, no source GLTF)
extends Node

# weapon_class_name -> script path. Populated lazily on first access.
# Sidearm is registered separately so it can be equipped during Last Stand.
const WEAPON_SCRIPTS: Dictionary = {
    # Primary weapons (11)
    "BumbleBeeAR": "res://scripts/weapons/bumblebee_ar.gd",
    "PlasmaCarbine": "res://scripts/weapons/plasma_carbine.gd",
    "LaserMarksman": "res://scripts/weapons/laser_marksman.gd",
    "BuzzBeeSMG": "res://scripts/weapons/buzzbee_smg.gd",
    "HornetSMG": "res://scripts/weapons/hornet_smg.gd",
    "StarSniper": "res://scripts/weapons/star_sniper.gd",
    "StingerLMG": "res://scripts/weapons/stinger_lmg.gd",
    "ConfettiCannon": "res://scripts/weapons/confetti_cannon.gd",
    "BubbleBlaster": "res://scripts/weapons/bubble_blaster.gd",
    "PopPop12": "res://scripts/weapons/pop_pop_12.gd",
    "WhisperSniper": "res://scripts/weapons/whisper_sniper.gd",
    # Sidearm (1) — usable during Last Stand
    "ToyBlasterPistol": "res://scripts/weapons/toy_blaster_pistol.gd",
}

# Per-master-prompt stat table (verbatim from Asset Manifest).
# Loaded from config/balance/weapons.csv at runtime; this is a fallback if the
# CSV is not yet loaded.
const WEAPON_STATS_FALLBACK: Dictionary = {
    "BumbleBeeAR": {"dmg": 22, "rpm": 700, "mag": 30, "range": 60.0, "slot": "AR"},
    "PlasmaCarbine": {"dmg": 28, "rpm": 600, "mag": 30, "range": 80.0, "slot": "BR"},
    "LaserMarksman": {"dmg": 55, "rpm": 300, "mag": 20, "range": 120.0, "slot": "DMR"},
    "BuzzBeeSMG": {"dmg": 16, "rpm": 1100, "mag": 25, "range": 25.0, "slot": "SMG"},
    "HornetSMG": {"dmg": 18, "rpm": 800, "mag": 30, "range": 30.0, "slot": "SMG"},
    "StarSniper": {"dmg": 110, "rpm": 60, "mag": 10, "range": 200.0, "slot": "Sniper"},
    "StingerLMG": {"dmg": 24, "rpm": 600, "mag": 75, "range": 80.0, "slot": "LMG"},
    "ConfettiCannon": {"dmg": 12, "pellets": 8, "rpm": 200, "mag": 8, "range": 15.0, "slot": "Shotgun"},
    "BubbleBlaster": {"dmg": 14, "pellets": 6, "rpm": 240, "mag": 6, "range": 18.0, "slot": "Shotgun"},
    "PopPop12": {"dmg": 13, "pellets": 7, "rpm": 180, "mag": 10, "range": 16.0, "slot": "Shotgun"},
    "WhisperSniper": {"dmg": 75, "rpm": 90, "mag": 20, "range": 150.0, "slot": "Suppressed Sniper"},
    "ToyBlasterPistol": {"dmg": 12, "rpm": 300, "mag": 10, "range": 20.0, "slot": "Sidearm"},
}

func get_weapon_script(weapon_name: String) -> GDScript:
    var path: String = WEAPON_SCRIPTS.get(weapon_name, "")
    if path.is_empty():
        push_warning("[WeaponsRegistry] Unknown weapon: " + weapon_name)
        return null
    return load(path) as GDScript

func get_weapon_stats(weapon_name: String) -> Dictionary:
    return WEAPON_STATS_FALLBACK.get(weapon_name, {})

func list_weapons() -> Array:
    return WEAPON_SCRIPTS.keys()

func list_primaries() -> Array:
    """Return all weapon names except the sidearm."""
    var result: Array = []
    for name in WEAPON_SCRIPTS:
        if name != "ToyBlasterPistol":
            result.append(name)
    return result

func list_sidearms() -> Array:
    return ["ToyBlasterPistol"]
