# File: scripts/autoload/monsters_registry.gd
# FOSTAS: Toybox Terror — Central registry of all monster classes
extends Node

const MONSTER_SCRIPTS: Dictionary = {
    "ShadowMonster": "res://scripts/monsters/shadow_monster.gd",
    "NewMonster": "res://scripts/monsters/new_monster.gd",
}

func get_monster_script(monster_name: String) -> GDScript:
    var path: String = MONSTER_SCRIPTS.get(monster_name, "")
    if path.is_empty():
        push_warning("[MonstersRegistry] Unknown monster: " + monster_name)
        return null
    return load(path) as GDScript

func list_monsters() -> Array:
    return MONSTER_SCRIPTS.keys()
