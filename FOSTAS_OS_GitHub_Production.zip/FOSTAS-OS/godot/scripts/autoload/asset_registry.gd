# File: scripts/autoload/asset_registry.gd
# FOSTAS: Toybox Terror — Asset Registry (autoload)
#
# Loads config/asset_registry.json on ready and validates that every declared
# asset path exists on disk. Per master prompt Module B1:
#   "no system may spawn an asset not present in this registry."
#
# Singleton at /root/AssetRegistry.
extends Node
class_name AssetRegistry

# ---- Signals ----
signal registry_loaded(asset_count: int)
signal validation_failed(missing_assets: Array)

# ---- Constants ----
const REGISTRY_PATH: String = "res://config/asset_registry.json"

# ---- State ----
# asset_folder -> {role, path, scale, team_color_override, toy_reskin, license, ...}
var _assets: Dictionary = {}
var _validated: bool = false
var _missing: Array = []

# ---- Lifecycle ----

func _ready() -> void:
    load_registry()

# ---- Public API ----

func load_registry() -> void:
    """Load the asset registry from config/asset_registry.json."""
    var file: FileAccess = FileAccess.open(REGISTRY_PATH, FileAccess.READ)
    if file == null:
        push_warning("[AssetRegistry] Registry file not found: %s" % REGISTRY_PATH)
        _assets = {}
        return

    var text: String = file.get_as_text()
    file.close()

    var json: JSON = JSON.new()
    var err: int = json.parse(text)
    if err != OK:
        push_error("[AssetRegistry] Failed to parse %s: %s at line %d" % [
            REGISTRY_PATH, json.get_error_message(), json.get_error_line()
        ])
        _assets = {}
        return

    var data: Variant = json.get_data()
    if not data is Dictionary or not data.has("assets"):
        push_error("[AssetRegistry] Invalid registry format — expected {\"assets\": [...]}")
        _assets = {}
        return

    _assets.clear()
    for entry in data["assets"]:
        if not entry is Dictionary or not entry.has("folder"):
            continue
        _assets[entry["folder"]] = entry

    _validated = _validate_paths()
    registry_loaded.emit(_assets.size())
    print("[AssetRegistry] Loaded %d assets (validated=%s)" % [_assets.size(), _validated])
    if not _validated:
        validation_failed.emit(_missing)
        for missing in _missing:
            push_warning("[AssetRegistry] Missing asset: %s" % missing)

func get_asset(folder: String) -> Dictionary:
    """Get a single asset entry by folder name. Returns empty dict if not found."""
    return _assets.get(folder, {})

func list_assets() -> Array:
    """Return all asset folder names."""
    return _assets.keys()

func list_by_role(role: String) -> Array:
    """Return all asset folder names with a given role (e.g. 'weapon', 'character', 'map')."""
    var result: Array = []
    for folder in _assets:
        if _assets[folder].get("role", "") == role:
            result.append(folder)
    return result

func is_validated() -> bool:
    return _validated

func get_missing() -> Array:
    return _missing

func get_team_color_override(folder: String) -> Color:
    """Get the team_color_override for an asset as a Color. Defaults to white."""
    var entry: Dictionary = get_asset(folder)
    if entry.is_empty():
        return Color.WHITE
    var hex: String = entry.get("team_color_override", "#FFFFFF")
    return Color.html(hex) if Color.html_is_valid(hex) else Color.WHITE

func get_scale_multiplier(folder: String) -> float:
    """Get the scale multiplier for an asset (per Appendix A normalization table)."""
    var entry: Dictionary = get_asset(folder)
    if entry.is_empty():
        return 1.0
    return float(entry.get("scale_multiplier", 1.0))

# ---- Internal ----

func _validate_paths() -> bool:
    """Check that every declared asset path exists on disk. Returns true if all present."""
    _missing.clear()
    for folder in _assets:
        var entry: Dictionary = _assets[folder]
        var path: String = entry.get("path", "")
        if path.is_empty():
            continue
        # Strip "res://" prefix for filesystem check.
        var fs_path: String = path
        if fs_path.begins_with("res://"):
            fs_path = fs_path.substr(6)
        var abs_path: String = ProjectSettings.globalize_path("res://") + fs_path
        if not FileAccess.file_exists(abs_path) and not DirAccess.dir_exists_absolute(abs_path):
            _missing.append(folder)
    return _missing.is_empty()
