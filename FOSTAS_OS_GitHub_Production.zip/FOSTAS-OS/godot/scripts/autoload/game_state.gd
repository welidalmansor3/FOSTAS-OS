# File: scripts/autoload/game_state.gd
# FOSTAS: Toybox Terror — Global Game State (autoload)
#
# Holds cross-system state that doesn't belong to a single subsystem.
# Singleton at /root/GameState.
#
# Phase 1 scope: minimal — just holds the current player reference and provides
# debug commands for testing the HP system. Phase 4 will expand with match-level
# scoreboard data; Phase 11 with progression state.
extends Node
class_name GameState

# ---- Signals ----
signal local_player_changed(player: Node)

# ---- State ----
var local_player: Node = null  # The local player's Player node (client-side).

# ---- Public API ----

func set_local_player(player: Node) -> void:
    local_player = player
    local_player_changed.emit(player)

func get_local_player() -> Node:
    return local_player

# ---- Debug helpers (Phase 1 testing only — removed before ship) ----

func debug_damage_limb(limb_name: String, amount: int = 25) -> void:
    """Apply damage to a specific limb on the local player for testing.
    Valid limb_name: head, torso, left_arm, right_arm, left_leg, right_leg."""
    if local_player == null or not is_instance_valid(local_player):
        push_warning("[GameState] No local player to damage.")
        return
    var health: Node = local_player.get_node_or_null("HealthSystem")
    if health == null:
        push_warning("[GameState] Local player has no HealthSystem.")
        return
    if not health.has_method("apply_damage_to_limb"):
        push_warning("[GameState] HealthSystem.apply_damage_to_limb not found.")
        return
    health.apply_damage_to_limb(limb_name, amount)
    print("[GameState] Debug damage %d to %s" % [amount, limb_name])

func debug_heal_full() -> void:
    """Restore all limbs to full HP on the local player."""
    if local_player == null or not is_instance_valid(local_player):
        return
    var health: Node = local_player.get_node_or_null("HealthSystem")
    if health == null:
        return
    if health.has_method("heal_full"):
        health.heal_full()
        print("[GameState] Debug heal full.")

func debug_print_hp() -> void:
    """Print the current HP of all 6 limbs on the local player."""
    if local_player == null or not is_instance_valid(local_player):
        print("[GameState] No local player.")
        return
    var health: Node = local_player.get_node_or_null("HealthSystem")
    if health == null:
        return
    if health.has_method("get_hp_summary"):
        print("[GameState] HP: ", health.get_hp_summary())
