# File: scripts/autoload/match_state.gd
# FOSTAS: Toybox Terror — Match State (autoload)
#
# Server-authoritative match state machine + match-time clock owner.
# Singleton at /root/MatchState.
#
# Match phases (linear progression):
#   LOBBY      -> players join, pick team/class/weapon, ready-up
#   LOAD_IN    -> cute-phase lighting baked, ambient music starts, all players spawn
#   ROUND      -> 4-minute round timer + Artifact Mode (Phase 4) + FOSTAS event (Phase 5)
#   INTERMISSION -> 15s breather between rounds; shows round result
#   MATCH_END  -> scoreboard, XP, mastery; returns to LOBBY after 30s
#
# FOSTAS event scheduling:
#   At ROUND phase start, server rolls a random trigger time in [90s, 390s]
#   (1:30 to 6:30 match-time). The event fires ONCE per match.
#   Implemented in Phase 5; this autoload exposes the schedule hook.
extends Node
class_name MatchState

# ---- Signals ----
signal phase_changed(old_phase: int, new_phase: int)
signal round_timer_tick(seconds_remaining: float)
signal match_ended(winning_team: int)

# ---- Phases ----
enum Phase {
    LOBBY,
    LOAD_IN,
    ROUND,
    INTERMISSION,
    MATCH_END,
}

# ---- Teams ----
enum Team {
    NONE = 0,
    RED = 1,
    BLUE = 2,
}

# ---- Constants ----
const ROUND_DURATION_S: float = 240.0  # 4 minutes
const LOAD_IN_DURATION_S: float = 5.0
const INTERMISSION_DURATION_S: float = 15.0
const MATCH_END_DURATION_S: float = 30.0
const FOSTAS_TRIGGER_MIN_S: float = 90.0   # 1:30
const FOSTAS_TRIGGER_MAX_S: float = 390.0  # 6:30
const BEST_OF: int = 3  # Best-of-3 (first to 2 round wins)
const RECONNECT_WINDOW_S: float = 90.0

# ---- State (server-authoritative) ----
var current_phase: int = Phase.LOBBY
var round_time_elapsed: float = 0.0
var phase_time_elapsed: float = 0.0
var current_round: int = 1
var red_round_wins: int = 0
var blue_round_wins: int = 0
var fostas_trigger_time_s: float = -1.0  # -1 = not yet scheduled; >0 = scheduled; -2 = already fired
var fostas_has_fired: bool = false
var artifact_round_win_team: int = Team.NONE  # team that won the round via artifact carry
var damage_buff_winner: int = Team.NONE  # team with +15% damage buff this match

# ---- Lifecycle ----

func _ready() -> void:
    print("[MatchState] ready (phase=LOBBY)")

func _process(delta: float) -> void:
    # Only the server advances match state.
    if not NetworkManager.is_server:
        return
    phase_time_elapsed += delta
    match current_phase:
        Phase.LOBBY:
            # Phase 4 will add ready-check logic to transition out of LOBBY.
            pass
        Phase.LOAD_IN:
            if phase_time_elapsed >= LOAD_IN_DURATION_S:
                _set_phase(Phase.ROUND)
        Phase.ROUND:
            round_time_elapsed += delta
            round_timer_tick.emit(ROUND_DURATION_S - round_time_elapsed)
            # Check round end conditions (Phase 4 will add artifact carry win).
            if round_time_elapsed >= ROUND_DURATION_S:
                _end_round(Team.NONE)  # timeout — draw or team-with-flask wins (Phase 4)
            # Check FOSTAS event trigger.
            if not fostas_has_fired and fostas_trigger_time_s > 0.0:
                if round_time_elapsed >= fostas_trigger_time_s:
                    _trigger_fostas_event()
        Phase.INTERMISSION:
            if phase_time_elapsed >= INTERMISSION_DURATION_S:
                if red_round_wins >= 2 or blue_round_wins >= 2:
                    _set_phase(Phase.MATCH_END)
                else:
                    current_round += 1
                    _set_phase(Phase.LOAD_IN)
        Phase.MATCH_END:
            if phase_time_elapsed >= MATCH_END_DURATION_S:
                _reset_match()

# ---- Phase transitions (server-authoritative) ----

func _set_phase(new_phase: int) -> void:
    var old_phase: int = current_phase
    current_phase = new_phase
    phase_time_elapsed = 0.0
    if new_phase == Phase.ROUND:
        round_time_elapsed = 0.0
        _schedule_fostas_event()
    elif new_phase == Phase.LOAD_IN:
        # Roll FOSTAS trigger time for the upcoming round (once per match).
        if fostas_trigger_time_s < 0.0 and not fostas_has_fired:
            fostas_trigger_time_s = randf_range(FOSTAS_TRIGGER_MIN_S, FOSTAS_TRIGGER_MAX_S)
    print("[MatchState] Phase: %s -> %s" % [_phase_name(old_phase), _phase_name(new_phase)])
    phase_changed.emit(old_phase, new_phase)
    # Broadcast phase change to clients (Phase 4 implements the RPC).
    # _broadcast_phase_change.rpc(old_phase, new_phase)

func _end_round(winning_team: int) -> void:
    if winning_team == Team.RED:
        red_round_wins += 1
    elif winning_team == Team.BLUE:
        blue_round_wins += 1
    # Track damage buff winner (persists across rounds).
    if winning_team != Team.NONE:
        damage_buff_winner = winning_team
    print("[MatchState] Round %d ended. RED %d - %d BLUE" % [current_round, red_round_wins, blue_round_wins])
    _set_phase(Phase.INTERMISSION)

func _reset_match() -> void:
    current_phase = Phase.LOBBY
    round_time_elapsed = 0.0
    phase_time_elapsed = 0.0
    current_round = 1
    red_round_wins = 0
    blue_round_wins = 0
    fostas_trigger_time_s = -1.0
    fostas_has_fired = false
    artifact_round_win_team = Team.NONE
    damage_buff_winner = Team.NONE
    print("[MatchState] Match reset to LOBBY")
    phase_changed.emit(Phase.MATCH_END, Phase.LOBBY)

# ---- FOSTAS event scheduling ----

func _schedule_fostas_event() -> void:
    # FOSTAS fires once per MATCH, not once per round. Only schedule if not yet fired.
    if fostas_has_fired:
        return
    if fostas_trigger_time_s < 0.0:
        fostas_trigger_time_s = randf_range(FOSTAS_TRIGGER_MIN_S, FOSTAS_TRIGGER_MAX_S)
        print("[MatchState] FOSTAS event scheduled for match-time %.1fs" % fostas_trigger_time_s)

func _trigger_fostas_event() -> void:
    # Phase 5 implements the full 4-phase FOSTAS event (Blackout -> Warning -> Hunt -> Recovery).
    fostas_has_fired = true
    print("[MatchState] FOSTAS event TRIGGERED at match-time %.1fs" % round_time_elapsed)
    # FOSTASEvent.start_event()  # enabled in Phase 5

# ---- Public query API (callable by client or server) ----

func get_round_time_remaining() -> float:
    return max(0.0, ROUND_DURATION_S - round_time_elapsed)

func is_fostas_active() -> bool:
    # Phase 5 will track the actual 4-phase state; for now, just whether it has fired.
    return fostas_has_fired

func get_winning_team() -> int:
    if red_round_wins > blue_round_wins:
        return Team.RED
    elif blue_round_wins > red_round_wins:
        return Team.BLUE
    return Team.NONE

func has_damage_buff(team: int) -> bool:
    return team == damage_buff_winner and team != Team.NONE

# ---- Helpers ----

func _phase_name(p: int) -> String:
    match p:
        Phase.LOBBY: return "LOBBY"
        Phase.LOAD_IN: return "LOAD_IN"
        Phase.ROUND: return "ROUND"
        Phase.INTERMISSION: return "INTERMISSION"
        Phase.MATCH_END: return "MATCH_END"
        _: return "UNKNOWN(%d)" % p

# ---- Server RPCs (Phase 4 will implement these) ----
# @rpc("authority", "call_remote", "reliable")
# func _broadcast_phase_change(old_phase: int, new_phase: int) -> void:
#     current_phase = new_phase
#     phase_time_elapsed = 0.0
#     phase_changed.emit(old_phase, new_phase)
