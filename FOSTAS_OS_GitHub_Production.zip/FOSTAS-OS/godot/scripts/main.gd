# File: scripts/main.gd
# FOSTAS: Toybox Terror — Main scene entry point
#
# Boot sequence:
#   1. Verify all autoloads are present (NetworkManager, MatchState, TeamManager,
#      AssetRegistry, GameState, WeaponsRegistry, MonstersRegistry).
#   2. Print system status (engine version, renderer, asset registry validation).
#   3. Spawn the local player at origin (Phase 1 — for movement testing).
#   4. Phase 4 will replace this with the lobby screen flow.
extends Node3D

const PLAYER_SCENE: PackedScene = preload("res://scenes/test/player_test.tscn")

func _ready() -> void:
    print("========================================")
    print("FOSTAS: Toybox Terror — booting...")
    print("========================================")
    print("Engine: Godot %s" % Engine.get_version_info()["string"])
    print("Renderer: %s" % ProjectSettings.get_setting("rendering/renderer/rendering_method"))

    # 1. Verify autoloads.
    _verify_autoloads()

    # 2. Asset registry status.
    if AssetRegistry:
        var asset_count: int = AssetRegistry.list_assets().size()
        var validated: bool = AssetRegistry.is_validated()
        print("AssetRegistry: %d assets loaded (validated=%s)" % [asset_count, validated])
        if not validated:
            var missing: Array = AssetRegistry.get_missing()
            print("  Missing assets (expected in Phase 6 when GLTFs are imported):")
            for m in missing:
                print("    - %s" % m)
    else:
        push_error("AssetRegistry autoload not found!")

    # 3. Network status (offline by default).
    if NetworkManager:
        print("NetworkManager: offline (call host_game() or join_game() to go online)")
    else:
        push_error("NetworkManager autoload not found!")

    # 4. Match state.
    if MatchState:
        print("MatchState: phase=%s" % MatchState._phase_name(MatchState.current_phase))
    else:
        push_error("MatchState autoload not found!")

    # 5. Spawn local player at origin for movement testing.
    _spawn_local_player()

    # 6. Capture input for FPS controls (handled by Player._ready).
    print("========================================")
    print("FOSTAS boot complete. Use WASD to move, mouse to look.")
    print("Debug: F1=damage head, F2=damage torso, F=heal full")
    print("========================================")

func _verify_autoloads() -> void:
    var required: Array = [
        "NetworkManager", "MatchState", "TeamManager",
        "AssetRegistry", "GameState", "WeaponsRegistry", "MonstersRegistry"
    ]
    for name in required:
        var node: Node = get_node_or_null("/root/" + name)
        if node == null:
            push_error("Missing autoload: %s" % name)
        else:
            print("  ✓ %s" % name)

func _spawn_local_player() -> void:
    var player: Node = PLAYER_SCENE.instantiate()
    player.set_local(true)
    player.set_team(TeamManager.Team.RED)
    player.global_position = Vector3(0, 2, 0)  # spawn slightly above floor
    add_child(player)
    print("Local player spawned at origin (team=RED).")
