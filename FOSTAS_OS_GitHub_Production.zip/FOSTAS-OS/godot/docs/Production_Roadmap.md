# FOSTAS: Toybox Terror — Production Roadmap

**Version:** 1.0
**Engine:** Godot 4.3 (GL Compatibility renderer)
**Target:** PC (Steam) — 5v5 multiplayer FPS
**Lead Technical Director:** FOSTAS OS

---

## Document Purpose

This roadmap is the single source of truth for production order. Every phase
depends on the previous one. No phase may begin until its dependencies are
validated. No file ships with placeholders.

The roadmap reconciles the FOSTAS master prompt (4-part production brief) with
the FOSTAS Development Report (15-section technical audit) and the current
state of the Godot project.

---

## Reconciled Design Decisions

The master prompt and dev report contain 6 internal inconsistencies. These
are the locked resolutions for production:

| Issue | Resolution |
|---|---|
| Limb damage multiplier | **×0.7** (master prompt PART 2 + Module B3 agree) |
| Class mastery range | **1–10** (PART 2 + Module B16 agree) |
| Respawn timer | **8 seconds** (PART 2 PROGRESSION is authoritative; death-screen "5s" is a UI label refresh interval, not the respawn delay) |
| Meteor Storm dual-role | **One spell, two acquisition paths**: Tier-3 Soul Contract (with tunnel-vision penalty) AND Mage Ultimate via bounty kill (no penalty — the bounty kill IS the cost). Same VFX, same damage. |
| Per-limb HP vs. overall death | **Per-limb pools only.** A player dies only when torso HP reaches 0 (Last Stand) AND the 30s bleed-out timer expires. Head HP 0 = instant Last Stand. Limb HP 0 = crippled but alive. |
| Sidearm (Toy Blaster Pistol) stats | **DMG 12, RPM 300, Mag 10, Range 20m, infinite reserve.** (Filled gap — matches the "TTK 0.3-0.8s at optimal range" target for a sidearm.) |
| Vehicles | **Out of scope.** The master prompt does not mention vehicles. The `knowledge/Vehicles.md` doc is non-canonical and will be removed. |

---

## Phase 0: Foundation Infrastructure (COMPLETE)

**Goal:** AI Operating System that builds, maintains, and extends FOSTAS via natural language.

**Status:** ✅ Complete. FOSTAS OS v1.1.0 ships with:
- FastAPI backend (16 endpoints, modular routers, WebSocket streaming)
- 3 AI providers (Z.AI real, Gemini real, Tripo mock + dormant real)
- 8-step orchestrator pipeline with parallel task execution
- 9-doc knowledge base merged with dev-report content
- Godot project manager with backups + path-traversal protection
- GDScript validator + secret scanner (pre-write gate)
- Auth + rate-limit + audit middleware
- Two-tier LRU cache
- Multi-project switcher
- Docker + CI

**Gate:** FOSTAS OS can boot, accept prompts, and apply AI-generated code to the Godot project with validation. ✅

---

## Phase 1: Core Game Foundation

**Goal:** Build the foundational systems that every future gameplay system depends on. No combat, no classes, no map — just the skeleton that everything else hangs from.

**Modules:** B1 (subset) — project init, asset registry schema, autoloads.

### Systems
1. **Project structure** — directory layout per master prompt Module B1
2. **Autoloads** — NetworkManager, MatchState, TeamManager, AssetRegistry, GameState
3. **NetworkManager** — server-authoritative RPC framework, snapshot/reconciliation infrastructure (no gameplay yet)
4. **MatchState** — match-time clock (server-authoritative), match phase machine (lobby → load_in → round → intermission → match_end)
5. **TeamManager** — RED/BLUE assignment, auto-balance (max 3 of one class per 5-player team)
6. **AssetRegistry** — loads `config/asset_registry.json`, validates all 19 assets exist (assets themselves not yet imported)
7. **Player controller** — CharacterBody3D with FPS movement (walk, sprint, crouch, jump), mouse look, ADS skeleton
8. **HealthSystem** — 6-limb HP pools (head, torso, L arm, R arm, L leg, R leg), 4 injury thresholds, Last Stand, bleed-out timer
9. **InjuryEffects** — Perlin-noise weapon sway (affects camera + bullet trajectory), screen effects (red pulse, desaturation), heavy breathing audio hook
10. **Input system** — extended input map (movement, look, fire, reload, ADS, sprint, crouch, jump, ability Q/E, spell slots 1/2/3, use F, scoreboard TAB, voice V)

### Dependencies
- None (this is the foundation)

### Files
- `project.godot` (updated: autoloads + input map + renderer)
- `config/asset_registry.json` (19-asset schema)
- `config/balance/weapons.csv` (11 weapons + sidearm, verbatim stats)
- `config/balance/spells.csv` (all spells with cooldowns/durations/penalties)
- `docs/GDD.md` (skeleton — full GDD grows per phase)
- `docs/TDD.md` (skeleton — architecture, network protocol, data schemas)

### Godot Scenes
- `scenes/main.tscn` (updated — boot scene that initializes all autoloads + spawns player)
- `scenes/test/movement_test.tscn` (test scene with floor + light + player spawner; clearly labeled as test, NOT production map)

### Scripts
- `scripts/autoload/network_manager.gd`
- `scripts/autoload/match_state.gd`
- `scripts/autoload/team_manager.gd`
- `scripts/autoload/asset_registry.gd`
- `scripts/autoload/game_state.gd`
- `scripts/player/player.gd`
- `scripts/player/player_camera.gd`
- `scripts/player/player_input.gd`
- `scripts/player/health_system.gd`
- `scripts/player/injury_effects.gd`
- `scripts/main.gd` (updated — boot sequence)

### Assets
- None imported yet (19 GLTFs arrive in Phase 6)

### Testing
- GDScript validator passes on every file (no extends errors, no tabs, no TODOs, no placeholders)
- Boot scene loads without errors
- Player can move (walk/sprint/crouch/jump) + look (mouse) in movement_test scene
- 6-limb HP system: damage to each limb reduces only that pool; thresholds trigger correct debuffs
- Last Stand triggers when torso HP reaches 0; bleed-out timer counts down; revive restores

### Validation
- `python scripts/validate_gdscript.py` (run via FOSTAS OS validator) — 0 errors
- Manual: boot scene loads; player spawns; movement works; HP system responds to debug damage commands
- Network: NetworkManager singleton exists; MatchState tick advances; TeamManager assigns teams

### Estimated Complexity
**Medium-High.** The networking framework is the hardest part — it must be server-authoritative from day 1 because retrofitting client-authoritative code is catastrophic. The 6-limb HP system is unusual and must be exactly right (every future combat system depends on it).

### Development Order
1. Project structure + project.godot
2. AssetRegistry + config/asset_registry.json + balance CSVs
3. NetworkManager (singleton only — no gameplay RPCs yet)
4. MatchState (match-time clock + phase machine)
5. TeamManager
6. GameState
7. HealthSystem (6-limb HP — pure data, no visual)
8. InjuryEffects (Perlin sway + screen effects)
9. PlayerInput (client-side input gathering)
10. PlayerCamera (FPS mouse look)
11. Player (CharacterBody3D, integrates HealthSystem + InjuryEffects + Input + Camera)
12. Boot scene + movement test scene
13. Validate everything

---

## Phase 2: Combat Core

**Goal:** All 11 weapons + sidearm fire, reload, and respect their stat blocks. Hardcore injury system + sway affects bullet trajectory. Last Stand + Bloodlust fully implemented.

**Modules:** B3 (Weapon System), B5 (Hardcore Injury & Sway).

### Systems
1. **Weapon base class extension** — recoil pattern (per-weapon vertical + horizontal), spread bloom, ADS accuracy bonus, fire modes (full-auto, semi-auto, bolt-action, pump)
2. **11 weapon scripts + scenes** — BumbleBee AR, Plasma Carbine, Laser Marksman, BuzzBee SMG, Hornet SMG, Star Sniper, Stinger LMG (bipod), Confetti Cannon, Bubble Blaster, Pop-Pop-12, Whisper Sniper (suppressed)
3. **Toy Blaster Pistol** — universal sidearm (must be modeled — no source GLTF; ~500 tris, team-color emissive plastic)
4. **Bullet system** — hitscan (raycast) for most weapons; projectile (spawned RigidBody3D) for Balloon Bomber arc
5. **Damage application** — hitscan hit → determine limb hit → apply damage with multiplier (head ×4, torso ×1, limb ×0.7) → reduce that limb's HP pool
6. **Reload system** — per-weapon reload time, magazine + reserve ammo, tactical vs. full reload
7. **Perlin-noise sway** — affects camera AND bullet trajectory (bullets do NOT snap to crosshair)
8. **Last Stand state** — prone, crawl at 1.5 m/s, sidearm-only, 30s bleed-out, Medic revive
9. **Bloodlust state** — 5s full-HP, zero recoil, +20% speed, red tint, 1s stun at end
10. **Plasma burst VFX** (muzzle flash) — 0.08s, team-color, additive, scale 0.2→0.6→0
11. **Plasma tracer VFX** — 1m, team-color, additive, fade 0.3s
12. **Toy blaster SFX** — per-weapon, ±2% pitch jitter, 3D spatial

### Dependencies
- Phase 1 (player controller, HP system, input, NetworkManager)

### Files
- `config/balance/weapons.csv` (already from Phase 1 — used as source of truth)
- `docs/anti_cheat.md` (skeleton — fire-rate, speed, spell-cooldown rules)

### Godot Scenes
- `scenes/weapons/<weapon_name>.tscn` × 12 (11 + sidearm)
- `scenes/test/combat_test.tscn` (test range with dummy targets)

### Scripts
- `scripts/weapons/weapon.gd` (extended)
- `scripts/weapons/bumblebee_ar.gd`
- `scripts/weapons/plasma_carbine.gd`
- `scripts/weapons/laser_marksman.gd`
- `scripts/weapons/buzzbee_smg.gd`
- `scripts/weapons/hornet_smg.gd`
- `scripts/weapons/star_sniper.gd`
- `scripts/weapons/stinger_lmg.gd`
- `scripts/weapons/confetti_cannon.gd`
- `scripts/weapons/bubble_blaster.gd`
- `scripts/weapons/pop_pop_12.gd`
- `scripts/weapons/whisper_sniper.gd`
- `scripts/weapons/toy_blaster_pistol.gd` (sidearm)
- `scripts/weapons/bullet.gd` (projectile for Balloon Bomber)
- `scripts/weapons/recoil_pattern.gd` (per-weapon recoil data)
- `scripts/weapons/sway_system.gd` (Perlin-noise sway)
- `scripts/player/last_stand.gd`
- `scripts/player/bloodlust.gd`
- `scripts/autoload/weapons_registry.gd` (updated — corrected 11 weapon names)

### Assets
- Toy Blaster Pistol mesh (~500 tris, must be modeled — no source GLTF)
- 11 weapon viewmodels (1st-person, ~3k tris each — derived from imported GLTFs)
- 11 weapon body models (3rd-person, ~8k tris each — derived from imported GLTFs)
- Plasma burst mesh + material
- Plasma tracer mesh + material
- 12 toy blaster SFX (11 weapons + sidearm)

### Testing
- Each weapon fires at correct RPM (server-validated)
- Each weapon's damage matches weapons.csv
- Reload time matches weapons.csv
- Headshot ×4, torso ×1, limb ×0.7 (verified on dummy targets)
- Last Stand triggers at torso HP 0; sidearm-only; 30s bleed-out
- Bloodlust triggers on Medic revive; all 5 components fire in sequence
- Sway affects bullet trajectory (bullet deviates from crosshair under injury)
- TTK simulation: 1000 1v1 per weapon pair; TTK between 0.3s–0.8s at optimal range

### Validation
- GDScript validator: 0 errors
- All 11 weapons in weapons_registry.gd have corresponding .gd + .tscn files
- balance/weapons.csv matches in-game behavior (auto-generated test)
- Anti-cheat: fire-rate hack rejected (server enforces per-weapon RPM cap)

### Estimated Complexity
**High.** 12 weapons × (script + scene + VFX + SFX + animations) is a large surface area. The Perlin sway affecting bullet trajectory is unusual and must be exactly right. Last Stand + Bloodlust have many interacting components.

### Development Order
1. Weapon base class extension (recoil, spread, ADS, fire modes)
2. Sway system (Perlin noise, integrates with HealthSystem)
3. Bullet system (hitscan + projectile)
4. Damage application (limb detection, multiplier, HP reduction)
5. Reload system
6. Toy Blaster Pistol (sidearm — needed for Last Stand)
7. 11 weapon scripts + scenes (one at a time, validate each)
8. Last Stand state
9. Bloodlust state
10. Plasma burst + tracer VFX
11. Toy blaster SFX (12)
12. TTK simulation + balance pass

---

## Phase 3: Classes & Magic

**Goal:** Combat Medic + Tactical Mage fully playable. Spell system with quest gating, Tier-2/Tier-3 spells, Soul Contract penalties. Bounty rune + Ultimate spells.

**Modules:** B4 (Classes), B6 (Magic), B7 (Bounty).

### Systems
1. **Combat Medic class** — SMG/Shotgun access, medkit prop (left hand), Heal Pulse (Q, 8s CD, 25 HP self + allies in 4m), Revive (E on downed ally, 3s channel, consumes medkit charge, max 3 per life), Bloodlust Marker (passive — revived players enter Bloodlust)
2. **Tactical Mage class** — AR/DMR access, spellbook prop (floats beside left hand, opens/glows on cast), spell gating (per-life randomized quest)
3. **Spell quest system** — Quest A (3 headshots → Weapon Enchantment), Quest B (3 teammate revive-assists → Mass Cleanse); server-side progress, reconnect-preserving
4. **Tier-2 spells** — Weapon Enchantment (headshot ×4→×12, purple glow, 15s, 30s CD), Mass Cleanse (10s invulnerability aura 8m, cannot self-cast, 60s CD)
5. **Tier-3 Soul Contract spells** — Mass Teleport (team → friendly castle, penalty: reload ×0.5 for 5s), Meteor Storm (5 meteors, 80 dmg each, AoE 6m, 4s, penalty: tunnel vision FOV 40° + blurred edges for 5s)
6. **Bounty rune system** — 3-killstreak → red rune above head (visible through walls to enemies only) + minimap ping (cute phase only); killer of bounty target gets Ultimate (90s expiration)
7. **Ultimate spells** — Medic: Mass Resurrect (all downed allies in 20m radius); Mage: Meteor Storm (same as Tier-3, no penalty — bounty kill IS the cost)
8. **Class auto-balance** — max 3 of one class per 5-player team
9. **Spell VFX** — enchantment aura (purple), mass cleanse sphere (green), meteor (5 plasma orbs), teleport (white flash), mass resurrect (rising souls)
10. **Spell SFX** — enchantment shimmer, cleanse chime, meteor impact, teleport whoosh, mass resurrect chime

### Dependencies
- Phase 2 (weapons, HP, Last Stand, Bloodlust)

### Files
- `config/balance/spells.csv` (already from Phase 1 — used as source of truth)
- `scripts/autoload/spells_registry.gd`

### Godot Scenes
- `scenes/props/medkit.tscn`
- `scenes/props/spellbook.tscn`
- `scenes/vfx/spell_enchantment.tscn`
- `scenes/vfx/spell_mass_cleanse.tscn`
- `scenes/vfx/spell_meteor_storm.tscn`
- `scenes/vfx/spell_mass_teleport.tscn`
- `scenes/vfx/spell_mass_resurrect.tscn`
- `scenes/vfx/bounty_rune.tscn`

### Scripts
- `scripts/classes/class_base.gd`
- `scripts/classes/combat_medic.gd`
- `scripts/classes/tactical_mage.gd`
- `scripts/spells/spell_base.gd`
- `scripts/spells/weapon_enchantment.gd`
- `scripts/spells/mass_cleanse.gd`
- `scripts/spells/mass_teleport.gd`
- `scripts/spells/meteor_storm.gd`
- `scripts/spells/mass_resurrect.gd`
- `scripts/spells/spell_quest.gd`
- `scripts/systems/bounty_system.gd`

### Assets
- 1st-person Medic arm rig (red/blue sleeves + white cross armband)
- 1st-person Mage arm rig (red/blue sleeves + arcane rune armband)
- Spellbook glow material (team-color emissive runes)
- Bounty rune VFX (red, pulses 1.5 Hz, scales with killstreak)

### Testing
- Medic can Heal Pulse (25 HP to self + allies in 4m, 8s CD)
- Medic can Revive downed ally (3s channel, consumes medkit charge)
- Revived player enters Bloodlust (all 5 components)
- Mage quest A: 3 headshots → Weapon Enchantment unlocks
- Mage quest B: 3 revive-assists → Mass Cleanse unlocks
- Weapon Enchantment: headshot ×12, purple glow, 15s, 30s CD
- Mass Cleanse: 10s invulnerability, 8m, cannot self-cast, 60s CD
- Mass Teleport: team to castle, reload ×0.5 for 5s penalty
- Meteor Storm: 5 meteors, 80 dmg each, tunnel vision 5s penalty
- Mass Resurrect: all downed allies in 20m revived
- Bounty: 3-killstreak → red rune → killer gets Ultimate (90s expiration)
- Auto-balance: max 3 of one class per team enforced

### Validation
- All spell cooldowns server-authoritative (client cannot bypass)
- Spell quest progress server-side (reconnect preserves)
- Soul Contract penalties apply automatically on Tier-3 cast
- Bounty clears on death; 30s cooldown before re-trigger on same player

### Estimated Complexity
**High.** Spell system has many interacting parts (quests, tiers, penalties, ultimates). Bounty system creates a parallel path to spell power that must be carefully balanced.

### Development Order
1. Class base + Medic class (Heal Pulse, Revive, Bloodlust Marker)
2. Mage class (spellbook prop, spell gating skeleton)
3. Spell quest system (server-side progress)
4. Tier-2 spells (Weapon Enchantment, Mass Cleanse)
5. Tier-3 Soul Contract spells (Mass Teleport, Meteor Storm)
6. Ultimate spells (Mass Resurrect, Meteor Storm via bounty)
7. Bounty rune system
8. Class auto-balance
9. Spell VFX (5)
10. Spell SFX (5)

---

## Phase 4: Match Flow

**Goal:** Full 5v5 lobby → match → scoreboard flow on a dedicated server. Artifact Mode playable end-to-end. Complete HUD.

**Modules:** B8 (Artifact Mode), B11 (UI/HUD), B12 (Networking).

### Systems
1. **Lobby system** — team picker (auto-balance), class picker, weapon picker (filtered by class), spell quest preview, ready-up
2. **Round timer** — 4 minutes per round
3. **Artifact Mode** — Mystic Flask spawns at courtyard center 30s into round; pickup on walk-over; carrier disarmed + 15% slow + team-color glow; capture zone inside enemy castle gate; round win on capture; carrier death drops Flask (reset-pickup after 5s)
4. **Best-of-3 match structure** — round win gives +15% primary damage buff (non-stacking, caps at +15%); match win at 2 round wins
5. **Reconnect** — 90s window; rejoin at friendly spawn with last loadout
6. **HUD** — HP bar with 6 limb icons (bottom-left), weapon icon + ammo + reload (bottom-right), round timer + score (top-center), minimap (top-right, cute phase only), crosshair (team-color + dynamic spread), teammate chevrons + HP bars, bounty rune (above target, through walls), Mage spell bar (3 slots + cooldown overlays)
7. **Death screen** — 3s slow-mo killer cam, "Respawning in 8s" countdown
8. **Post-match scoreboard** — XP gained, mastery progress, "GG" chat
9. **Networked match flow** — lobby → ready-check → load-in → round start → round end → intermission → match end → scoreboard, all server-authoritative

### Dependencies
- Phase 3 (classes, spells, bounty)

### Files
- `docs/TDD.md` (network protocol section — RPC list, snapshot format, lag comp details)

### Godot Scenes
- `scenes/ui/lobby.tscn`
- `scenes/ui/hud.tscn`
- `scenes/ui/death_screen.tscn`
- `scenes/ui/scoreboard.tscn`
- `scenes/test/match_test.tscn` (2v2 test match with bots)

### Scripts
- `scripts/systems/lobby_manager.gd`
- `scripts/systems/round_manager.gd`
- `scripts/systems/artifact_mode.gd`
- `scripts/systems/reconnect_manager.gd`
- `scripts/ui/hud_controller.gd`
- `scripts/ui/lobby_controller.gd`
- `scripts/ui/death_screen.gd`
- `scripts/ui/scoreboard.gd`
- `scripts/ui/minimap.gd`
- `scripts/ui/crosshair.gd`
- `scripts/ui/limb_hp_display.gd`

### Assets
- HUD art (HP bar, limb icons, ammo icon, minimap frame, crosshair, chevrons, spell bar)
- Lobby art (team picker, class picker, weapon picker, ready-up button)
- Death screen art (slow-mo overlay, respawn countdown)
- Scoreboard art (XP bar, mastery icons)

### Testing
- 5v5 lobby → ready-check → load-in → round → round end → intermission → match end → scoreboard (12 clients on dedicated server)
- Artifact spawns at 30s; pickup works; carrier disarmed + slow; capture wins round
- +15% damage buff persists into next round (non-stacking)
- Reconnect within 90s restores state; past 90s releases slot
- HUD updates in real-time (HP, ammo, timer, minimap, bounty, spell bar)
- Death screen shows killer cam + respawn countdown
- Scoreboard shows XP, mastery progress

### Validation
- Gate 1: 5v5 lobby → match → scoreboard on dedicated server with 12 clients ✅
- Gate 6: Artifact Mode round win + +15% damage buff ✅
- Network: 20 Hz tick, 60 Hz client send, 200 ms lag comp, 90s reconnect
- All match-flow state transitions server-authoritative

### Estimated Complexity
**High.** Full multiplayer match flow is the largest single integration point. The HUD alone is a substantial UI surface. Reconnect logic is fragile.

### Development Order
1. Lobby system (server-authoritative ready-check)
2. Round manager (4-min timer, round win conditions)
3. Artifact Mode (spawn, pickup, carrier state, capture zone)
4. Best-of-3 + damage buff
5. Reconnect (90s window, state restore)
6. HUD (HP/limb, ammo, timer, minimap, crosshair, chevrons, bounty, spell bar)
7. Death screen
8. Post-match scoreboard
9. 5v5 integration test on dedicated server

---

## Phase 5: Horror Layer (FOSTAS Event)

**Goal:** FOSTAS 4-phase event replicates identically to all 12 clients. Jumpscare kills. Map returns to cute phase. Full audio + VFX + post-FX transitions.

**Modules:** B9 (FOSTAS Event), B10 (Audio, partial), B14 (VFX & Lighting, partial).

### Systems
1. **FOSTAS 4-phase state machine** — Blackout (0.4s) → Warning (1.0s) → Hunt (20s) → Recovery (2s); server-authoritative, match-time-clock scheduled
2. **Server trigger roll** — random 1:30–6:30 at match start, once per match, never same twice
3. **Skybox lerp** — playground blue → void black, 0.4s; sun rotates 90°
4. **Adaptive music** — 4 stems (cute base, cute combat, horror base, horror combat); 0.5s crossfade; cute base ducks to 30% during combat
5. **Sub-bass rumble** — 1.0s sustained note for Phase 2 warning
6. **Jumpscare scream** — 1.2s piercing female scream + sub-bass drop; full-volume on killed client, muffled-distant on others
7. **5 Shadow Monster spawns** — server-controlled AI, positions broadcast at Phase 3 start
8. **Player debuffs during Hunt** — −15% movement speed (panic slow), screen-shake ×3, minimap disabled, VOIP muted
9. **Post-FX profile lerp** — cute (subtle bloom) → horror (heavy bloom + chromatic aberration + vignette 0.7 + film grain + slight fisheye), 0.4s
10. **Cotton-candy blood (cute) → red liquid blood (horror)** — material swap on phase transition
11. **VOIP mute during FOSTAS** — all phases mute team VOIP

### Dependencies
- Phase 4 (match flow, networking)
- Phase 7 (Shadow Monster AI — must exist before Hunt phase can spawn them)

### Files
- `docs/TDD.md` (FOSTAS event replication section — match-time clock, phase broadcast protocol)

### Godot Scenes
- `scenes/vfx/fostas_blackout.tscn`
- `scenes/vfx/fostas_warning.tscn`
- `scenes/vfx/fostas_jumpscare.tscn`
- `scenes/vfx/fostas_recovery.tscn`
- `scenes/audio/adaptive_music.gd` (Autoload or scene)

### Scripts
- `scripts/systems/fostas_event.gd`
- `scripts/systems/match_time_clock.gd` (if not already in MatchState)
- `scripts/audio/adaptive_music_manager.gd`
- `scripts/audio/voip_manager.gd`
- `scripts/vfx/post_fx_profile.gd`
- `scripts/vfx/skybox_lerp.gd`

### Assets
- Cute skybox texture ("playground blue")
- Horror skybox texture ("void black")
- 4 music stems (cute base, cute combat, horror base, horror combat)
- Sub-bass rumble SFX (1.0s)
- Jumpscare scream SFX (1.2s)
- Blood material (cotton-candy team-color, cute phase)
- Blood material (red liquid, horror phase)
- Post-FX profile resources (cute, horror)

### Testing
- Server rolls trigger time at match start (random 1:30–6:30)
- All 12 clients observe identical phase transitions (frame-accurate under 200 ms lag comp)
- Phase 1: blackout simultaneous on all clients; music cuts to silence; VOIP mutes
- Phase 2: red warning text on all clients; sub-bass rumble
- Phase 3: 5 monsters spawn at server-rolled positions; players debuffed; minimap off
- Phase 4: fade back to cute; music resumes; match state preserved
- Jumpscare: monster reaches player → full-screen monster face + scream → player dies
- VOIP mutes during all 4 phases; unmutes at Recovery
- Skybox lerps 0.4s cute → horror → 2.0s horror → cute

### Validation
- Gate 7: FOSTAS event triggers at random time, replicates to all 12 clients, jumpscare kills, map returns to cute ✅
- Match-time clock drift-corrected every 5s (no wall-clock scheduling)
- Max 8 dynamic lights per frame during Hunt (5 monster + 3 reserved)

### Estimated Complexity
**Very High.** Frame-accurate phase replication across 12 clients under packet loss is the most fragile subsystem in the project. The 0.4s lerp between completely different visual/audio profiles is technically demanding.

### Development Order
1. Match-time clock (drift correction, server-synced)
2. FOSTAS event state machine (server-side)
3. Phase broadcast protocol (reliable events with match-time timestamps)
4. Skybox lerp + sun rotation
5. Adaptive music manager (4 stems, 0.5s crossfade)
6. Sub-bass rumble + jumpscare scream SFX
7. Shadow Monster spawn (depends on Phase 7)
8. Player debuffs during Hunt
9. Post-FX profile lerp
10. Blood material swap
11. VOIP mute integration
12. 12-client integration test under simulated pings

---

## Phase 6: Maps & Environment

**Goal:** Primary map (Castle Wars) playable with both castles, mid-field playground, 3-floor verticality, baked GI, collision, NavMesh. P0 license blocker resolved.

**Modules:** B2 (Map & Faction System), B1 (asset import + ToyReskinMaterial).

### Systems
1. **P0 license resolution** — replace castle_wars_pavlov_vr with custom-modeled castle of equivalent layout, OR obtain commercial license from author FlunkedPunk
2. **Asset import** — all 19 GLTFs imported with scale normalization (per Appendix A table)
3. **ToyReskinMaterial/ToyReskin.shader** — team-color basecolor, roughness 0.35, clearcoat 1.0, two emissive stripes (team-color, intensity 4.0, pulse 1.5 Hz)
4. **Toy reskin pass** — applied to all 11 weapons, both characters, both castle materials, medkit, spellbook
5. **Primary map** — two opposing castles (RED west, BLUE east), courtyard center, 3 lanes (north/middle/south), 3-floor castle structure (gate/ramparts/sniper tower)
6. **Mid-field playground** — lowpoly__map__asset__by_resoforge scattered as cover/ramps/crates; BLUE material recolored to yellow
7. **Spawn points** — RED castle (west), BLUE castle (east); both have line-of-sight to courtyard but NOT to each other; walk time Red→Blue = 25s
8. **Capture zones** — inside each castle's gate (for Artifact Mode)
9. **Artifact spawn point** — courtyard center
10. **NavMesh** — baked for bot navigation + Shadow Monster A* pathfinding
11. **Collision meshes** — trimesh for static geometry, convex for props
12. **LOD groups** — LOD0 (100%), LOD1 (30%), LOD2 (10%) on every mesh
13. **Baked GI (cute phase)** — LightmapGI, 4K castle interiors, 2K outdoor
14. **Real-time GI (horror phase)** — single cold point-light per shadow monster, max 5 active
15. **Skyboxes** — "playground blue" (cute) + "void black" (horror)
16. **Castle banners/flags/trim** — team-color overlays on castle_wars base mesh
17. **Seasonal event flyers** — HalloweenEventFlyer + HolidayEventFlyer toggleable

### Dependencies
- Phase 5 (FOSTAS event needs skybox lerp + lighting transition)
- P0 license resolution (BLOCKER — must be done before any map work)

### Files
- `config/asset_registry.json` (updated — all 19 assets with import-time scale multipliers)
- `materials/toy_reskin.material` (or `.shader` if Godot 4 custom shader)
- `docs/legal/castle_wars_license.md` (if licensing route taken)

### Godot Scenes
- `scenes/maps/castle_wars.tscn` (primary map)
- `scenes/maps/castle_red.tscn` (RED castle sub-scene)
- `scenes/maps/castle_blue.tscn` (BLUE castle sub-scene)
- `scenes/maps/midfield_playground.tscn` (lowpoly__map__asset__by_resoforge)
- `scenes/props/banner_red.tscn`, `scenes/props/banner_blue.tscn`

### Scripts
- `scripts/maps/map_base.gd`
- `scripts/maps/castle_wars.gd`
- `scripts/maps/spawn_point.gd`
- `scripts/maps/capture_zone.gd`

### Assets
- All 19 GLTFs (from iq-free.zip — must be uploaded to project)
- Custom castle model (if P0 resolved via replacement)
- Castle banners/flags/trim meshes (team-color overlays)
- "Playground blue" skybox texture
- "Void black" skybox texture
- ToyReskinMaterial shader

### Testing
- Walk from RED spawn to BLUE spawn takes 25 seconds at walk speed
- Both spawns have line-of-sight to courtyard but NOT to each other
- 3-floor castle structure accessible (gate, ramparts, sniper tower)
- Map is rotationally symmetric across courtyard center
- NavMesh bakes successfully; bots can navigate
- Collision meshes prevent falling through floor/walls
- LOD groups reduce draw distance tris correctly
- Baked GI looks correct in cute phase
- Max 8 dynamic lights enforced during horror phase
- Skybox lerps correctly during FOSTAS event

### Validation
- All 19 assets present in `config/asset_registry.json` and loadable
- All 19 assets have correct scale (per Appendix A table)
- P0 license blocker resolved (documented in `docs/legal/`)
- 60 FPS on GTX 1060 in cute phase (Gate 8 partial)
- Draw calls < 500 per frame on GTX 1060

### Estimated Complexity
**Very High.** The P0 license blocker is a hard gate. The 1684-mesh mid-field scene is a draw-call explosion risk. Baked GI requires final geometry lock (re-baking after each iteration is expensive).

### Development Order
1. **Resolve P0 license** (replace or license — DECISION REQUIRED)
2. ToyReskinMaterial shader
3. Import 19 GLTFs with scale normalization
4. Apply toy reskin pass to all weapons/characters/castles/props
5. Build castle_wars primary map (2 castles + courtyard)
6. Build midfield_playground sub-scene
7. Spawn points + capture zones + artifact spawn
8. Castle banners/flags/trim
9. Collision meshes
10. NavMesh bake
11. LOD groups
12. Baked GI (cute phase)
13. Real-time GI (horror phase)
14. Skyboxes
15. Seasonal event flyers

---

## Phase 7: AI & Bots

**Goal:** Bots fill empty lobby slots at 3 skill tiers. Shadow Monsters hunt players during FOSTAS Hunt phase.

**Modules:** B13 (AI/Bots & Shadow Monsters).

### Systems
1. **Bot NavMesh navigation** — cover points marked, flanking lanes
2. **3 bot skill tiers** — Easy (no abilities, 50% accuracy, random wander), Medium (cover + flank, 70% accuracy, abilities sometimes), Hard (cover + flank + spell combos, 85% accuracy, predictive aiming, "FOSTAS incoming" chat)
3. **Bot weapon access** — by class (Medic: SMG/shotgun; Mage: AR/DMR)
4. **Bot respawn** — same rules as players
5. **Shadow Monster AI** — A* pathfinding at 6 m/s, swarm nearest visible player, ignore LOS through walls but slow around corners, ignore each other, 200 HP, 1.5s dissolve on death, respawn after 5s during Hunt
6. **Shadow Monster jumpscare** — on reaching player: full-screen monster face + scream → player dies instantly (body remains for revive)

### Dependencies
- Phase 6 (maps — NavMesh required)
- Phase 5 (FOSTAS event — Hunt phase spawns monsters)

### Files
- `docs/TDD.md` (AI section — bot behavior tree, monster A* implementation)

### Godot Scenes
- `scenes/ai/bot_medic.tscn`
- `scenes/ai/bot_mage.tscn`
- `scenes/monsters/shadow_monster.tscn` (updated with VFX)

### Scripts
- `scripts/ai/bot_base.gd`
- `scripts/ai/bot_easy.gd`
- `scripts/ai/bot_medium.gd`
- `scripts/ai/bot_hard.gd`
- `scripts/ai/bot_navigation.gd` (NavMesh + cover points)
- `scripts/ai/bot_combat.gd` (aim, fire, ability use)
- `scripts/monsters/shadow_monster.gd` (updated — A* pathfinding, jumpscare trigger)
- `scripts/monsters/shadow_monster_spawner.gd`

### Assets
- Shadow Monster motion-blur trail VFX
- Shadow Monster dissolve-death VFX (1.5s)
- Shadow Monster jumpscare full-screen overlay
- Shadow Monster animations (idle, sprint, attack_lunge, jumpscare_trigger, dissolve_death)
- Bot animations (reuse player animations — same rigs)

### Testing
- Easy bot: random wander, fires at enemies, 50% accuracy, no abilities
- Medium bot: uses cover, flanks, 70% accuracy, uses abilities on CD
- Hard bot: cover + flank + spell combos, 85% accuracy, predictive aim, chat comms
- Bot weapon access enforced by class
- 5v5 match starts with bots filling empty slots
- Shadow Monster: A* pathfinding to nearest player at 6 m/s
- Shadow Monster: 200 HP, takes damage, dies in 1.5s dissolve, respawns after 5s
- Shadow Monster: jumpscare on reach → player dies, body remains for revive
- Shadow Monster: ignores LOS through walls, slows around corners

### Validation
- Bots fill lobby to 5v5 minimum
- NavMesh valid (no stuck bots)
- Shadow Monsters spawn only during FOSTAS Hunt phase
- Max 5 Shadow Monsters active simultaneously

### Estimated Complexity
**High.** Bot AI at 3 skill tiers is non-trivial. Hard bot with spell combos is especially complex. Shadow Monster A* must integrate with NavMesh.

### Development Order
1. Bot base + navigation (NavMesh)
2. Easy bot (wander + fire)
3. Medium bot (cover + flank + abilities)
4. Hard bot (spell combos + predictive aim + chat)
5. Bot weapon access by class
6. Bot respawn
7. Shadow Monster A* pathfinding
8. Shadow Monster jumpscare trigger
9. Shadow Monster dissolve + respawn
10. Shadow Monster motion-blur trail VFX

---

## Phase 8: Audio

**Goal:** Full adaptive audio system — 4-stem music, per-weapon SFX, footsteps, VOIP, jumpscare, spell SFX, UI SFX.

**Modules:** B10 (Audio Design).

### Systems
1. **Adaptive music** — 4 stems (cute base, cute combat, horror base, horror combat); 0.5s crossfade; cute base ducks to 30% during combat; ~120 BPM marimba/glockenspiel/bouncy bass (cute), industrial drone/low brass/detuned piano/sub-bass (horror)
2. **Per-weapon toy blaster SFX** — 12 weapons (11 + sidearm), ±2% pitch jitter per shot, 3D spatial
3. **Footsteps** — soft plastic clack on hard surfaces, muffled on grass
4. **VOIP** — positional 3D voice, team-color UI indicator, mutes during FOSTAS event
5. **Jumpscare scream** — 1.2s piercing female scream + sub-bass drop, full-volume on killed client, muffled-distant on others
6. **Spell SFX** — enchantment shimmer, cleanse chime, meteor impact, teleport whoosh, mass resurrect chime
7. **UI SFX** — click, hover, ready-up, round-start, round-end, match-win
8. **Heavy breathing SFX** — plays when limb HP < 25% (critical injury)
9. **Sub-bass rumble** — 1.0s sustained note for FOSTAS Phase 2 warning

### Dependencies
- Phase 5 (FOSTAS event needs audio integration)
- Phase 2 (weapons need SFX)
- Phase 3 (spells need SFX)

### Files
- `config/audio_banks.json` (audio file → bank mapping)

### Godot Scenes
- `scenes/audio/audio_manager.tscn` (autoload or scene)

### Scripts
- `scripts/audio/adaptive_music_manager.gd`
- `scripts/audio/sfx_manager.gd`
- `scripts/audio/voip_manager.gd`
- `scripts/audio/footstep_system.gd`
- `scripts/audio/audio_bus_layout.tscn` (Godot audio bus config)

### Assets
- 4 music stems (cute base, cute combat, horror base, horror combat) — ~2 min each, seamless loop
- 12 toy blaster SFX (11 weapons + sidearm)
- Footstep SFX (plastic clack × 4 variations, muffled × 4)
- Jumpscare scream SFX (1.2s)
- Sub-bass rumble SFX (1.0s)
- Spell SFX (5: enchantment, cleanse, meteor, teleport, mass resurrect)
- UI SFX (7: click, hover, ready-up, round-start, round-end, match-win)
- Heavy breathing SFX (looping, 3 intensity levels)
- VOIP codec integration (Opus)

### Testing
- Music stems crossfade correctly (0.5s)
- Cute base ducks to 30% during combat
- Each weapon SFX plays with ±2% pitch jitter
- Footsteps switch material based on surface
- VOIP positional 3D + team-color indicator
- VOIP mutes during FOSTAS event
- Jumpscare scream full-volume on killed, muffled on others
- Spell SFX trigger on cast
- UI SFX on each interaction
- Heavy breathing at limb HP < 25%

### Validation
- Audio memory < 500 MB (streaming stems, preload SFX)
- 3D spatialization correct (sound direction matches source)
- No audio glitches during phase transitions

### Estimated Complexity
**Medium.** Audio system is conceptually simple but asset-intensive (~40+ audio files). VOIP integration is the hardest part.

### Development Order
1. Audio bus layout + manager
2. Adaptive music manager (4 stems, crossfade)
3. SFX manager (3D spatial, pitch jitter)
4. Per-weapon SFX (12)
5. Footstep system
6. VOIP integration
7. Jumpscare scream
8. Spell SFX (5)
9. UI SFX (7)
10. Heavy breathing

---

## Phase 9: VFX & Lighting

**Goal:** Full VFX system — ToyReskinMaterial, plasma bursts/tracers, spell VFX, blood materials, FOSTAS sky beam, monster trail, dissolve-death, post-FX profiles.

**Modules:** B14 (VFX & Lighting).

### Systems
1. **ToyReskinMaterial/ToyReskin.shader** — team-color basecolor, roughness 0.35, clearcoat 1.0, two emissive stripes (team-color, intensity 4.0, pulse 1.5 Hz)
2. **Plasma burst VFX** (muzzle flash) — 0.08s, team-color, additive, sphere mesh, scale 0.2→0.6→0
3. **Plasma tracer trail VFX** — 1m, team-color, additive, fade 0.3s
4. **Spell VFX** — enchantment aura (purple), mass cleanse sphere (green expanding), meteor storm (5 plasma orbs falling), mass teleport (white flash + column), mass resurrect (rising souls)
5. **Bounty rune VFX** — red, pulses 1.5 Hz, scales with killstreak (3 kills small, 5+ large + spinning)
6. **FOSTAS sky beam VFX** — skyward beam from artifact spawn point
7. **Pickup ring VFX** — ground ring at artifact spawn
8. **Shadow Monster motion-blur trail** — heavy trail attached to each of 5 monsters during Hunt
9. **Dissolve-death VFX** — 1.5s dissolve on monster death
10. **Cotton-candy blood (cute)** — team-color particles, no gore
11. **Red liquid blood (horror)** — realistic red liquid
12. **Post-FX profiles** — cute (subtle bloom, no CA, no vignette, no grain), horror (heavy bloom, strong CA, vignette 0.7, animated grain, slight fisheye), 0.4s lerp
13. **Baked GI (cute phase)** — LightmapGI, 4K castle interiors, 2K outdoor
14. **Real-time GI (horror phase)** — single cold point-light per shadow monster, max 5 active

### Dependencies
- Phase 6 (maps — needs GI bake)
- Phase 5 (FOSTAS event — needs post-FX lerp)
- Phase 2 (weapons — need plasma VFX)
- Phase 3 (spells — need spell VFX)

### Files
- `materials/toy_reskin.shader` (Godot 4 custom shader)
- `materials/blood_cotton_candy.tres`
- `materials/blood_red_liquid.tres`
- `resources/post_fx_cute.tres`
- `resources/post_fx_horror.tres`

### Godot Scenes
- `scenes/vfx/plasma_burst.tscn`
- `scenes/vfx/plasma_tracer.tscn`
- `scenes/vfx/spell_enchantment_aura.tscn`
- `scenes/vfx/spell_mass_cleanse_sphere.tscn`
- `scenes/vfx/spell_meteor_storm.tscn`
- `scenes/vfx/spell_mass_teleport.tscn`
- `scenes/vfx/spell_mass_resurrect.tscn`
- `scenes/vfx/bounty_rune.tscn`
- `scenes/vfx/fostas_sky_beam.tscn`
- `scenes/vfx/pickup_ring.tscn`
- `scenes/vfx/shadow_monster_trail.tscn`
- `scenes/vfx/dissolve_death.tscn`

### Scripts
- `scripts/vfx/vfx_spawner.gd` (object-pooled VFX manager)
- `scripts/vfx/post_fx_profile.gd`
- `scripts/vfx/skybox_lerp.gd`
- `scripts/vfx/blood_material_swap.gd`

### Assets
- ToyReskinMaterial shader
- Plasma burst mesh + material
- Plasma tracer mesh + material
- Spell VFX meshes + materials (5)
- Bounty rune mesh + material
- FOSTAS sky beam mesh + material
- Pickup ring mesh + material
- Shadow Monster trail material
- Dissolve-death material
- Cotton-candy blood particles
- Red liquid blood particles
- Post-FX profile resources (2)

### Testing
- Plasma burst plays on every weapon fire (0.08s)
- Plasma tracer spawns on every projectile/hitscan
- Spell VFX trigger on cast (5 spells)
- Bounty rune pulses 1.5 Hz, scales with killstreak
- FOSTAS sky beam at artifact spawn
- Shadow Monster trail during Hunt (5 instances)
- Dissolve-death on monster kill (1.5s)
- Blood material swaps on phase transition (cotton-candy ↔ red)
- Post-FX lerps 0.4s cute ↔ horror
- Max 8 dynamic lights enforced

### Validation
- VFX object pooling prevents per-frame instantiation
- Post-FX lerp smooth (no popping)
- GI bake correct in cute phase
- Real-time GI performant in horror phase

### Estimated Complexity
**High.** Many VFX assets + shader work. Post-FX profile lerp is technically demanding. Object pooling required for performance.

### Development Order
1. ToyReskinMaterial shader
2. VFX spawner (object-pooled)
3. Plasma burst + tracer
4. Spell VFX (5)
5. Bounty rune
6. FOSTAS sky beam + pickup ring
7. Shadow Monster trail
8. Dissolve-death
9. Blood materials (2)
10. Post-FX profiles (2) + lerp
11. Baked GI (cute)
12. Real-time GI (horror)

---

## Phase 10: Anti-Cheat & Optimization

**Goal:** Server-side anti-cheat rejects fire-rate, speed, and spell-cooldown hacks. 60 FPS on GTX 1060. LOD groups, occlusion culling, mesh merging, asset streaming.

**Modules:** B15 (Optimization & Anti-Cheat).

### Systems
1. **Server-side fire-rate validation** — per-weapon RPM cap with 5ms tolerance
2. **Server-side speed validation** — max move speed × delta × 1.1 tolerance
3. **Server-side spell-cooldown validation** — last-cast-time per Mage, 50ms tolerance
4. **Headshot ratio anomaly detection** — 30s sliding window, flag > 90% for review
5. **Wallhack mitigation** — occlusion-aware snapshot filtering (expensive, optional for v1)
6. **LOD groups** — every mesh (LOD0 100%, LOD1 30%, LOD2 10%)
7. **Occlusion culling** — bake occlusion meshes for castle_wars + mid-field
8. **Mesh merging** — mid-field 1684 meshes → < 500 draw calls via merge_meshes
9. **Asset streaming** — mid-field 32.6 MB streamed in chunks by player position
10. **Texture streaming** — mipmaps streamed from disk
11. **Max 8 dynamic lights enforcement** — engine-level cap
12. **1st-person (~3k tris) + 3rd-person (~8k tris) weapon viewmodels** — separate meshes
13. **Delta-compressed snapshots** — per-client, prioritized by proximity
14. **Bandwidth budget** — 64 Kbps server→client, 16 Kbps client→server

### Dependencies
- All previous phases (anti-cheat validates all gameplay; optimization applies to all assets)

### Files
- `docs/anti_cheat.md` (every server validation rule, fully documented)
- `docs/TDD.md` (optimization section — frame-time budget breakdown)

### Scripts
- `scripts/systems/anti_cheat.gd` (server-side validation rules)
- `scripts/systems/snapshot_compression.gd`
- `scripts/systems/occlusion_culling.gd`

### Assets
- LOD meshes for all 11 weapons + 2 characters + 2 castles + mid-field
- Occlusion meshes for castle_wars + mid-field

### Testing
- Fire-rate hack rejected (server enforces per-weapon RPM)
- Speed hack rejected (server enforces max move speed)
- Spell-cooldown hack rejected (server enforces cooldown)
- Headshot ratio > 90% flagged for review
- 60 FPS sustained on GTX 1060 / 1080p medium during 5v5 + FOSTAS event
- Draw calls < 500 per frame
- Bandwidth < 64 Kbps per client
- Memory < 4 GB on GTX 1060

### Validation
- Gate 8: 60 FPS GTX 1060 / 1080p medium during 5v5 + FOSTAS ✅
- Gate 9: Anti-cheat rejects fire-rate, speed, spell-cooldown hacks ✅
- Frame-time budget: rendering 8ms, physics 3ms, networking 1ms, game logic 3ms, audio 0.5ms, OS 1.1ms

### Estimated Complexity
**Medium-High.** Anti-cheat is conceptually simple but must cover every gameplay action. Optimization requires iterative profiling.

### Development Order
1. Anti-cheat rules (fire-rate, speed, spell-cooldown)
2. Headshot ratio anomaly detection
3. Wallhack mitigation (optional)
4. LOD groups (all meshes)
5. Occlusion culling bake
6. Mesh merging (mid-field)
7. Asset streaming (mid-field)
8. Texture streaming
9. Max 8 dynamic lights enforcement
10. 1st/3rd-person viewmodel separation
11. Delta-compressed snapshots
12. 60 FPS profiling + optimization pass

---

## Phase 11: Progression & Documentation

**Goal:** Account level 1-100, weapon mastery 1-5, class mastery 1-10, 90-day seasons. All docs shipped.

**Modules:** B16 (Progression & Documentation).

### Systems
1. **Account level 1-100** — XP per match (100 base + 25/kill + 50/round win + 100/match win + 30/revive/assist)
2. **Weapon mastery 1-5** — per weapon, XP from kills/objectives with that weapon, unlocks toy cosmetics (paintjobs, sticker slots, trail colors), permanent across seasons
3. **Class mastery 1-10** — per class (Medic, Mage), XP from class-specific actions, unlocks cosmetic class items (medkit skins, spellbook covers), permanent across seasons
4. **Seasons** — 90-day cycle, 40-tier free + 40-tier premium track (cosmetic only), seasonal questline
5. **Cosmetic unlocks** — weapon skins, character skins, spellbook covers (all cosmetic-only, no pay-to-win)
6. **In-game currency** — earned through play, used to unlock seasonal cosmetics
7. **Documentation** — GDD, TDD, asset_registry.json, weapons.csv, spells.csv, anti_cheat.md, README

### Dependencies
- All previous phases (progression tracks all gameplay actions)

### Files
- `docs/GDD.md` (full Game Design Document)
- `docs/TDD.md` (full Technical Design Document)
- `docs/anti_cheat.md` (full anti-cheat rules)
- `README.md` (how to run dedicated server, host 5v5 lobby, swap assets)
- `config/asset_registry.json` (final, all 19 assets)
- `config/balance/weapons.csv` (final, all 11 + sidearm)
- `config/balance/spells.csv` (final, all spells)

### Godot Scenes
- `scenes/ui/progression_dashboard.tscn`
- `scenes/ui/season_track.tscn`
- `scenes/ui/mastery_track.tscn`

### Scripts
- `scripts/systems/progression_manager.gd`
- `scripts/systems/season_manager.gd`
- `scripts/systems/cosmetic_manager.gd`
- `scripts/ui/progression_dashboard.gd`

### Assets
- Cosmetic weapon skins (multiple per weapon)
- Cosmetic character skins (multiple per class)
- Cosmetic spellbook covers (multiple)
- Season track UI art (40 free + 40 premium tiers)
- Mastery track UI art

### Testing
- Account level XP calculation correct (100 + 25/kill + 50/round + 100/match + 30/revive)
- Weapon mastery 1-5 progression per weapon
- Class mastery 1-10 progression per class
- Season reset: mastery permanent, seasonal track resets
- Cosmetic unlocks applied visually
- In-game currency earn/spend correct

### Validation
- All 7 documentation deliverables shipped
- All 19 assets in asset_registry.json
- All 11 + sidearm weapons in weapons.csv
- All spells in spells.csv
- README accurate (dedicated server, 5v5 lobby, asset swap)

### Estimated Complexity
**Medium.** Progression is conceptually simple but data-heavy. Documentation is a writing effort.

### Development Order
1. Progression manager (XP, levels, mastery)
2. Season manager (90-day cycle, 40+40 tiers)
3. Cosmetic manager
4. In-game currency
5. Progression dashboard UI
6. Season track UI
7. Mastery track UI
8. Documentation (GDD, TDD, anti_cheat.md, README)
9. Final asset_registry.json + balance CSVs

---

## Phase 12: Acceptance Gates & Ship

**Goal:** All 10 acceptance gates pass. Build is Steam-release-ready.

### Gates (verbatim from master prompt)
1. ✅ 5v5 lobby → match → scoreboard flow works end-to-end on a dedicated server with 12 clients connected
2. ✅ Every one of the 11 weapons fires, reloads, and respects its stat block
3. ✅ Medic can revive a Last-Stand player; Bloodlust triggers correctly
4. ✅ Mage can complete both spell quests and cast both Tier-2 spells; Soul Contract penalty applies on Tier-3
5. ✅ Bounty rune appears on 3-killstreak players; killer gets Ultimate spell
6. ✅ Artifact Mode round can be won by either team; +15% damage buff persists into next round
7. ✅ FOSTAS event triggers at a random time, replicates identically to all 12 clients, jumpscare kills, and the map returns to cute phase
8. ✅ 60 FPS sustained on GTX 1060 / 1080p medium during a 5v5 match with a FOSTAS event triggered
9. ✅ Anti-cheat rejects a fire-rate hack, a speed hack, and a spell-cooldown hack in unit tests
10. ✅ No placeholders anywhere in the build. Every mesh, texture, SFX, animation, and UI element is final-quality

### Final Tasks
- Full QA pass (all 10 gates verified)
- Balance pass (TTK 0.3-0.8s at optimal range for all weapons)
- Steam store-page assets (capsule images, trailers, screenshots) — separate marketing workflow
- Steam build upload
- Day-1 patch plan

### Estimated Complexity
**Medium.** Mostly verification + polish.

---

## Phase Dependency Graph

```
Phase 1 (Foundation)
  ↓
Phase 2 (Combat Core)
  ↓
Phase 3 (Classes & Magic)
  ↓
Phase 4 (Match Flow)
  ↓ ↘
Phase 5  Phase 6 (Maps)
(Horror)  ↓
  ↓ ↙   Phase 7 (AI & Bots)
Phase 8 (Audio) ← Phase 9 (VFX & Lighting)
  ↓
Phase 10 (Anti-Cheat & Optimization)
  ↓
Phase 11 (Progression & Docs)
  ↓
Phase 12 (Acceptance Gates & Ship)
```

**Critical path:** Phase 1 → 2 → 3 → 4 → 5 → 10 → 12
**Parallel tracks:** Phase 6 (maps) can run parallel to Phase 5 (horror) once Phase 4 is done. Phase 7 (AI) depends on Phase 6. Phase 8 (audio) and Phase 9 (VFX) can run parallel to Phase 5-7.

---

## Current Status

| Phase | Status | Notes |
|---|---|---|
| 0. Foundation Infrastructure | ✅ Complete | FOSTAS OS v1.1.0 |
| 1. Core Game Foundation | 🔄 In Progress | Starting now |
| 2. Combat Core | ⏳ Pending | |
| 3. Classes & Magic | ⏳ Pending | |
| 4. Match Flow | ⏳ Pending | |
| 5. Horror Layer | ⏳ Pending | |
| 6. Maps & Environment | ⏳ Pending | P0 license blocker must be resolved first |
| 7. AI & Bots | ⏳ Pending | |
| 8. Audio | ⏳ Pending | |
| 9. VFX & Lighting | ⏳ Pending | |
| 10. Anti-Cheat & Optimization | ⏳ Pending | |
| 11. Progression & Docs | ⏳ Pending | |
| 12. Acceptance Gates & Ship | ⏳ Pending | |

---

## P0 Blocker (Must Resolve Before Phase 6)

`castle_wars_pavlov_vr` is licensed CC-BY-NC-SA-4.0 (non-commercial share-alike). Steam release (free or paid) is blocked until one of:

1. **Replace** — model a custom castle of equivalent layout (2 opposing 3-floor castles, ~19 meshes, 137m × 40m × 18.7m bounding box). Estimated 2-4 weeks senior environment artist time.
2. **License** — contact author `FlunkedPunk` via Sketchfab to negotiate a separate commercial license. Document terms in `docs/legal/castle_wars_license.md`.
3. **Switch primary map** — designate a different map as primary; demote Castle Wars to non-shipping internal prototype.

**Decision required by Phase 6 start.** Phases 1-5 do not depend on this decision (they use test scenes, not the production map).
