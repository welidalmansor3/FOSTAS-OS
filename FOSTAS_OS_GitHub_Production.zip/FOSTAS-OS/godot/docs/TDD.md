# FOSTAS: Toybox Terror — Technical Design Document (TDD)

**Version:** 1.0 (Phase 1 skeleton — grows per phase)
**Engine:** Godot 4.3 (GL Compatibility renderer)
**Target:** PC (Steam) — 5v5 multiplayer FPS

---

## 1. Architecture Overview

### 1.1 Engine Choice
Godot 4.3 with GL Compatibility renderer. Locked — no engine mixing.

### 1.2 Project Structure
```
godot/
├── project.godot              # Engine config + autoloads + input map
├── icon.svg
├── assets/                    # Imported GLTFs (19 assets — Phase 6)
├── config/
│   ├── asset_registry.json    # 19-asset schema (source of truth)
│   └── balance/
│       ├── weapons.csv        # 11 weapons + sidearm stats
│       └── spells.csv         # All spells with cooldowns/durations/penalties
├── docs/
│   ├── GDD.md                 # Game Design Document
│   ├── TDD.md                 # This document
│   └── Production_Roadmap.md  # 12-phase roadmap
├── materials/                 # ToyReskinMaterial, blood, post-FX (Phase 9)
├── resources/                 # Post-FX profile resources (Phase 9)
├── scenes/
│   ├── main.tscn              # Boot scene
│   ├── test/
│   │   └── player_test.tscn   # Player prefab (Phase 1)
│   ├── weapons/               # 12 weapon scenes (Phase 2)
│   ├── maps/                  # castle_wars + sub-scenes (Phase 6)
│   ├── ui/                    # HUD, lobby, scoreboard (Phase 4)
│   ├── vfx/                   # VFX scenes (Phase 9)
│   ├── audio/                 # Audio manager (Phase 8)
│   ├── props/                 # medkit, spellbook (Phase 3)
│   ├── monsters/              # shadow_monster (Phase 7)
│   └── ai/                    # bot scenes (Phase 7)
└── scripts/
    ├── main.gd                # Boot sequence
    ├── autoload/              # Singletons (NetworkManager, MatchState, etc.)
    ├── player/                # Player, HealthSystem, InjuryEffects, Input, Camera
    ├── weapons/               # Weapon classes (Phase 2)
    ├── classes/               # Medic, Mage (Phase 3)
    ├── spells/                # Spell classes (Phase 3)
    ├── systems/               # Lobby, Round, Artifact, FOSTAS, Bounty, AntiCheat
    ├── ai/                    # Bot AI (Phase 7)
    ├── monsters/              # Shadow Monster AI (Phase 7)
    ├── ui/                    # HUD, lobby, scoreboard (Phase 4)
    ├── vfx/                   # VFX spawner, post-FX (Phase 9)
    ├── audio/                 # Adaptive music, SFX, VOIP (Phase 8)
    ├── maps/                  # Map scripts (Phase 6)
    └── network/               # player_network.gd (Phase 4 integration)
```

### 1.3 Autoloads (load order matters)

| Singleton | Path | Purpose |
|---|---|---|
| NetworkManager | scripts/autoload/network_manager.gd | Server-authoritative RPC framework, snapshot/reconciliation, match-time clock |
| MatchState | scripts/autoload/match_state.gd | Match phase machine (LOBBY→LOAD_IN→ROUND→INTERMISSION→MATCH_END), FOSTAS event scheduling |
| TeamManager | scripts/autoload/team_manager.gd | RED/BLUE assignment, class caps, auto-balance |
| AssetRegistry | scripts/autoload/asset_registry.gd | Loads config/asset_registry.json, validates all assets exist |
| GameState | scripts/autoload/game_state.gd | Local player reference, debug helpers |
| WeaponsRegistry | scripts/autoload/weapons_registry.gd | 11 weapons + sidearm script registry + stats fallback |
| MonstersRegistry | scripts/autoload/monsters_registry.gd | Monster script registry |

---

## 2. Networking Protocol

### 2.1 Architecture
Dedicated server authoritative. Server = peer 1. Clients = peers 2..N (max 12).

### 2.2 Tick Rates
- Server tick: 20 Hz (50ms per tick)
- Client input send: 60 Hz
- Snapshot interpolation buffer: 100ms (3 server ticks)
- Lag compensation rewind window: 200ms
- Reconnect window: 90s

### 2.3 RPC Conventions (Godot 4)
- **Reliable state changes** (phase transitions, spell casts, item pickups): `@rpc("authority", "call_remote", "reliable")`
- **Unreliable high-frequency** (movement, look): `@rpc("any_peer", "unreliable")` with delta compression
- **Server-validated client requests** (fire, cast spell): client sends request via `@rpc("any_peer", "call_local", "reliable")` → server validates → server broadcasts result via `@rpc("authority", "call_remote", "reliable")`

### 2.4 Snapshot Format
```gdscript
{
    "tick": int,           # server tick number
    "timestamp": int,      # msec since server start
    "players": {
        peer_id: {
            "position": Vector3,
            "rotation": Vector3,
            "velocity": Vector3,
            "health_summary": {...},  # 6-limb HP
            "state_flags": int,       # last_stand | bloodlust | dead | ...
        },
        ...
    },
    "monsters": [...],     # FOSTAS event monster positions
    "artifact": {...},     # artifact carry state
}
```

### 2.5 Snapshot Compression
- Delta compression (only changes from last acknowledged snapshot per client)
- Position quantization: 16-bit per axis (±327m, 1mm precision)
- Rotation quantization: quaternion packed in 32 bits (smallest-three encoding)
- Bandwidth budget: 64 Kbps server→client, 16 Kbps client→server

### 2.6 Lag Compensation
- Server maintains a 16-tick (800ms) snapshot history
- On hit validation: server rewinds to `now - min(client_ping, 200ms)` and validates shot from client's perspective at fire time
- If hit confirmed: damage applied
- If miss: no rollback (client prediction was wrong)
- Clamp: reject shots from clients with ping > 300ms

### 2.7 Match-Time Clock
- Server owns the authoritative match-time clock
- Clients drift-correct via `_sync_match_time` RPC (server broadcasts every 5s)
- Drift > 50ms: hard-correct (client snaps to server time)
- Drift ≤ 50ms: ignore (within tolerance)
- FOSTAS event phases are scheduled on match-time clock, not wall-clock — prevents drift under packet loss

---

## 3. Data Schemas

### 3.1 Player State
```gdscript
{
    "peer_id": int,
    "team": int,           # TeamManager.Team enum
    "class": int,          # TeamManager.ClassID enum
    "ready": bool,
    "health": {
        "head": int, "torso": int,
        "left_arm": int, "right_arm": int,
        "left_leg": int, "right_leg": int,
    },
    "in_last_stand": bool,
    "in_bloodlust": bool,
    "is_dead": bool,
    "loadout": {
        "primary": String,  # weapon class name
        "sidearm": String,  # always "ToyBlasterPistol"
    },
}
```

### 3.2 Weapon Data
Loaded from `config/balance/weapons.csv`. Each weapon is a Resource with: dmg, rpm, mag, range, slot, recoil pattern, pellets (for shotguns), special flags (bipod, suppressed, headshot_one_shot).

### 3.3 Spell Data
Loaded from `config/balance/spells.csv`. Each spell is a Resource with: tier (2/3/Ultimate/ability/passive), class_source, acquisition, duration, cooldown, effect, penalty.

---

## 4. Frame-Time Budget (60 FPS = 16.6ms)

| Subsystem | Budget | % |
|---|---|---|
| Rendering | 8.0ms | 48% |
| Physics | 3.0ms | 18% |
| Game logic | 3.0ms | 18% |
| Networking | 1.0ms | 6% |
| Audio | 0.5ms | 3% |
| OS / overhead | 1.1ms | 7% |

---

## 5. Rendering Pipeline

### 5.1 Cute Phase (default)
- Baked GI (LightmapGI) — 4K castle interiors, 2K outdoor
- Subtle bloom, no chromatic aberration, no vignette, no film grain
- Max 8 dynamic lights per frame (5 monster + 3 reserved for spell VFX during horror phase)

### 5.2 Horror Phase (FOSTAS event)
- Real-time GI (single cold point-light per shadow monster, max 5 active)
- Heavy bloom, strong chromatic aberration, vignette 0.7, animated film grain, slight fisheye
- Skybox lerps "playground blue" → "void black" over 0.4s
- Sun direction rotates 90°

### 5.3 Post-FX Profile Lerp
0.4s lerp between cute and horror post-FX profiles. Implemented as a custom post-process shader (Phase 9).

---

## 6. LOD Strategy

Every mesh has 3 LOD levels:
- LOD0: 100% tris (0-15m for weapons, 0-30m for characters/environment)
- LOD1: 30% tris (15-40m / 30-60m)
- LOD2: 10% tris (40m+ / 60m+)

1st-person weapon viewmodels: ~3k tris (separate mesh from 3rd-person).
3rd-person weapon body: ~8k tris.

---

## 7. Anti-Cheat Rules

Server-side rule-based. Documented in `docs/anti_cheat.md` (Phase 10).

- **Fire-rate validation:** server tracks last-fire-time per weapon; rejects fire events faster than RPM allows (5ms tolerance)
- **Speed validation:** server tracks position delta per tick; rejects movement > max_speed × delta × 1.1 (10% tolerance)
- **Spell-cooldown validation:** server tracks spell last-cast-time per Mage; rejects casts during cooldown (50ms tolerance)
- **Headshot ratio anomaly detection:** 30s sliding window; flag players with headshot ratio > 90% for review
- **Wallhack mitigation:** occlusion-aware snapshot filtering (expensive, optional for v1)

---

## 8. Reconciled Design Decisions

| Issue | Resolution |
|---|---|
| Limb damage multiplier | ×0.7 (master prompt PART 2 + Module B3 agree) |
| Class mastery range | 1-10 (PART 2 + Module B16 agree) |
| Respawn timer | 8 seconds (PART 2 PROGRESSION authoritative) |
| Meteor Storm dual-role | One spell, two acquisition paths (Tier-3 with penalty; Ultimate via bounty, no penalty) |
| Per-limb HP vs. overall death | Per-limb pools only; death = torso HP 0 + 30s bleed-out expiry |
| Sidearm stats | DMG 12, RPM 300, Mag 10, Range 20m, infinite reserve |
| Vehicles | Out of scope (not in master prompt) |

---

## Document History

| Version | Phase | Changes |
|---|---|---|
| 1.0 | Phase 1 | Skeleton: architecture, project structure, autoloads, networking protocol, data schemas, frame-time budget, rendering pipeline, LOD strategy, anti-cheat rules, reconciled decisions. Subsequent phases expand each section. |
