# FOSTAS: Toybox Terror — Game Design Document (GDD)

**Version:** 1.0 (Phase 1 skeleton — grows per phase)
**Engine:** Godot 4.3 (GL Compatibility renderer)
**Target:** PC (Steam) — 5v5 multiplayer FPS
**Status:** In development (Phase 1: Core Game Foundation)

---

## 1. Vision

FOSTAS: Toybox Terror is an online 5v5 multiplayer first-person shooter for PC (Steam) that pairs a brightly-colored stylized toy-world aesthetic with a mid-match psychological-horror event. From the outside it looks like a cute, child-friendly toy world — soft plastic weapons, candy colors, smiley clouds — but mid-match, hardcore tactical mechanics and a sudden horror event subvert that surface.

The signature mechanic is the FOSTAS Monster event: a server-rolled random window between 1:30 and 6:30 triggers a 0.4-second blackout, a 1.0-second warning, a 20-second hunt in which five Shadow Monsters spawn and instantly kill any player they catch, and a 2-second recovery back to the cute palette.

## 2. Core Loop

**Macro loop:** lobby (team color, class pick, weapon pick, ready-up) → ready-check → load-in (cute phase) → round start with 30s artifact-spawn delay → match (with possible FOSTAS event) → round end → intermission → next round or match end → scoreboard.

**Micro loop (inside a round):** spawn at friendly castle → navigate toward courtyard → engage enemies at weapon's optimal range → take per-limb damage that drives escalating debuffs → optionally enter Last Stand → Medic revive (or bleed out + 8s respawn) → re-engage.

## 3. Factions

Two factions only: **RED TEAM** vs **BLUE TEAM**. No other color is permitted anywhere in the project. Enforced at the shader level — `PlasticToy` material takes a `team_color_override` uniform.

- RED castle: west
- BLUE castle: east
- Courtyard: center (artifact spawn point)
- Walk time RED→BLUE: 25 seconds

## 4. Classes

### Combat Medic
- **Role:** support / close-range
- **Weapon access:** SMGs, Shotguns, sidearm. Cannot equip ARs/DMRs/Snipers/LMGs.
- **Prop:** `medkit` (left hand) — consumed to revive
- **Abilities:**
  - **Heal Pulse (Q):** 8s CD, restores 25 HP to self + allies within 4m
  - **Revive (E):** 3s channel, consumes medkit charge (max 3 per life), triggers Bloodlust on revived player
  - **Bloodlust Marker (passive):** revived players enter Bloodlust (5s full HP, zero recoil, +20% speed, red tint, 1s stun end)
- **Ultimate (via bounty kill):** Mass Resurrect (all downed allies in 20m radius)

### Tactical Mage
- **Role:** mid-range caster
- **Weapon access:** ARs, DMRs, sidearm. No Snipers/LMGs/Shotguns.
- **Prop:** `old_fantasy_book` (floats beside left hand, opens/glows on cast)
- **Spell gating:** per-life randomized quest (Quest A: 3 headshots → Weapon Enchantment; Quest B: 3 teammate revive-assists → Mass Cleanse)
- **Tier-3 Soul Contract spells:** Mass Teleport (penalty: reload ×0.5 for 5s), Meteor Storm (penalty: tunnel vision 5s)
- **Ultimate (via bounty kill):** Meteor Storm (no penalty — bounty kill IS the cost)

## 5. Hardcore Injury System

6 limb HP pools per player: head, torso, left arm, right arm, left leg, right leg.

| HP Range | State | Effects |
|---|---|---|
| 75-100 | CLEAN | full capability |
| 50-74 | MINOR | ×1.3 sway, -10% sprint |
| 25-49 | HEAVY | ×1.8 sway, -25% sprint, +30% reload, red pulse |
| 1-24 | CRITICAL | ×2.5 sway, walk-only, desaturated, heavy breathing |
| 0 | CRIPPLED | limb destroyed; torso 0 = Last Stand |

**Last Stand:** torso HP reaches 0 → player drops prone, can crawl at 1.5 m/s, can fire sidearm only, 30s bleed-out. Medic revive restores 50% torso / 25% limbs + triggers Bloodlust.

**Sway:** Perlin-noise 2D vector modulated by injury level + ADS state. **Bullet trajectory deviates from crosshair by the current sway vector** — bullets do NOT snap to crosshair.

## 6. Damage Model

- Base HP: 100 per limb
- Headshot: ×4 multiplier (×12 with Weapon Enchantment)
- Torso: ×1
- Limb: ×0.7
- TTK target: 0.3-0.8s at optimal range (0.25 floor, 1.2 ceiling)

## 7. Weapons (11 + sidearm)

See `config/balance/weapons.csv` for the authoritative stat table. All 11 weapons are toy-reskinned versions of real firearms (Steyr AUG A1 → BumbleBee AR, etc.). The Toy Blaster Pistol is the universal sidearm, modeled from scratch (no source GLTF), used during Last Stand.

## 8. Bounty Rune System

- 3-killstreak → glowing red rune above target's head (visible through walls to enemies only) + minimap ping (cute phase only)
- Killing the bounty target grants the killer their class's Ultimate spell (no quest, 90s expiration)
- Bounty clears on death; 30s cooldown before re-trigger on same player

## 9. Artifact Mode (primary ranked)

- Best-of-3 rounds, 4-minute round timer
- Mystic Flask spawns at courtyard center 30s into round
- Carrier: disarmed, -15% speed, team-color glow
- Win: carry Flask into enemy castle's capture zone
- Round reward: +15% primary damage buff (non-stacking, caps at +15%)

## 10. FOSTAS Event (signature mechanic)

Server rolls trigger time at match start (random 1:30-6:30, once per match). Server broadcasts phase transitions to all 12 clients simultaneously via match-time-clock scheduling.

| Phase | Duration | Effect |
|---|---|---|
| 1. Blackout | 0.4s | screen snaps to black, music cuts, VOIP mutes |
| 2. Warning | 1.0s | red "FOSTAS MONSTER IS COMING! HIDE!" text, sub-bass rumble |
| 3. Hunt | 20s | 5 Shadow Monsters spawn, players debuffed (-15% speed, ×3 screen-shake, minimap off, VOIP mute), jumpscare = instant death |
| 4. Recovery | 2s | fade back to cute, music resumes |

## 11. Multiplayer Architecture

- Dedicated server authoritative
- 20 Hz tick (50ms per tick)
- 60 Hz client input send
- 100 ms snapshot interpolation buffer
- 200 ms lag compensation rewind window
- 90 s reconnect window
- Delta-compressed snapshots prioritized by proximity
- Anti-cheat: server-side rule-based (fire-rate, speed, spell-cooldown validation)

## 12. Performance Targets

- 60 FPS sustained on GTX 1060 @ 1080p medium (5v5 + FOSTAS event)
- 120-144 FPS on RTX 4070
- Frame-time budget: 16.6ms (rendering 8ms, physics 3ms, networking 1ms, game logic 3ms, audio 0.5ms, OS 1.1ms)
- Max 8 dynamic lights per frame
- < 500 draw calls per frame on GTX 1060

## 13. Progression

- Account level 1-100 (XP: 100 base + 25/kill + 50/round + 100/match + 30/revive)
- Weapon mastery 1-5 per weapon (unlocks cosmetic paintjobs/stickers/trails; permanent across seasons)
- Class mastery 1-10 per class (unlocks cosmetic class items; permanent across seasons)
- Seasons: 90-day cycle, 40-tier free + 40-tier premium track (cosmetic only)

## 14. Economy

Cosmetic-only monetization. No pay-to-win, no gameplay-affecting purchases. In-game currency earned through play, used to unlock seasonal cosmetics. Season Pass optional purchase accelerates earn rate.

## 15. Acceptance Gates (10)

1. 5v5 lobby → match → scoreboard on dedicated server with 12 clients
2. All 11 weapons fire, reload, respect stat block
3. Medic revive + Bloodlust triggers correctly
4. Mage spell quests + Soul Contract penalty
5. Bounty rune + Ultimate spell
6. Artifact Mode round win + +15% damage buff
7. FOSTAS event replicates to all 12 clients, jumpscare kills, returns to cute
8. 60 FPS on GTX 1060 / 1080p medium during 5v5 + FOSTAS
9. Anti-cheat rejects fire-rate, speed, spell-cooldown hacks
10. No placeholders anywhere in the build

---

## Document History

| Version | Phase | Changes |
|---|---|---|
| 1.0 | Phase 1 | Skeleton created with vision, loop, classes, injury system, damage model, weapons, bounty, artifact mode, FOSTAS event, multiplayer, performance, progression, economy, acceptance gates. Subsequent phases will expand each section with implementation details. |
