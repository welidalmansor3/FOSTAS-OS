# 🎮 FOSTAS OS

### AI Operating System for Game Development

> Build, maintain, and expand the commercial multiplayer FPS **FOSTAS: Toybox Terror** entirely through natural-language prompts.

FOSTAS OS is a production-grade AI orchestration platform that coordinates three specialized AI providers — **Z.AI** (Godot codegen), **Google Gemini** (planning & analysis), and **Tripo AI** (3D asset generation) — to build a complete Godot 4.3 multiplayer first-person shooter. The user describes what they want in plain English; the system understands the request, plans the work, generates code, edits the Godot project, validates the result, and reports back.

---

## ✨ Features

### AI Orchestration
- **3-provider pipeline** — Z.AI writes GDScript, Gemini analyzes & plans, Tripo generates 3D models
- **8-step orchestrator** — analyze → knowledge → scan → plan → execute (parallel) → apply → validate → report
- **Wave-based parallel task execution** — independent AI calls run concurrently via `asyncio.gather`
- **Smart error recovery** — Z.AI retry → Gemini fallback → never crash
- **Real-time WebSocket streaming** — watch AI activity live at `/ws/prompt`

### Production-Ready Backend
- **FastAPI** async backend with modular routers (11 route files)
- **Pydantic v2** validation on every endpoint
- **Optional API-key auth** + per-IP rate limiting + audit logging middleware
- **Two-tier cache** — L1 LRU (512 entries, <1µs hits) + L2 file with TTL
- **Async download manager** — chunked, resumable, SHA-256 verified, 100 MB cap
- **Upload manager** — ZIP extraction + auto-classify by category

### Safety & Validation
- **GDScript validator** — pre-write gate rejects tabs, missing `extends`, TODO markers, placeholder phrases
- **Secret scanner** — refuses to write files containing leaked API keys (7 patterns: AWS, OpenAI, Google, Slack, JWT, env vars, generic)
- **Path-traversal protection** — all file ops sandboxed to project directory
- **Automatic backups** — every Godot file edit creates a timestamped backup before writing

### Godot Project Management
- **Project scanner** — reads scenes, scripts, assets, textures, materials, settings
- **Godot CLI integration** — headless validation, export, script execution
- **Multi-project switcher** — manage multiple Godot projects under `workspace/projects/`
- **9-doc knowledge base** — GameBible, Weapons, Magic, Maps, Monster, Networking, Optimization, Potions, Vehicles (~60 KB merged with dev report)

### Plugin System
- Register custom AI providers via `FOSTAS_PLUGINS=module1,module2` env var
- Each plugin module exposes `register(registry)` to add providers to the factory

---

## 🏗️ Architecture

```
FOSTAS-OS/
├── backend/              # FastAPI backend
│   ├── api/              # Modular route handlers (11 files)
│   ├── core/             # Orchestrator, cache, download/upload, events, godot_manager
│   ├── knowledge/        # Knowledge base manager (keyword-overlap retrieval)
│   ├── middleware/        # Auth, rate limit, audit
│   ├── models/           # Pydantic schemas
│   ├── plugins/          # Plugin registry
│   ├── providers/        # Z.AI, Gemini, Tripo adapters
│   └── validation/       # GDScript validator + secret scanner
├── frontend/             # Streamlit dark-theme SPA
│   └── app.py            # 8-panel UI (Project Explorer, Prompt, AI Activity, etc.)
├── config/               # Pydantic settings (env-driven)
├── godot/                # FOSTAS: Toybox Terror Godot 4.3 project
│   ├── config/           # asset_registry.json + balance CSVs
│   ├── docs/             # GDD, TDD, Production Roadmap
│   ├── scenes/           # main.tscn + test scenes
│   └── scripts/          # GDScript (autoloads, player, weapons, monsters)
├── knowledge/            # 9 markdown docs (~60 KB)
├── scripts/              # seed.py + test_pipeline.py
├── tests/                # pytest unit tests (42 tests, all passing)
├── docs/                 # Project-level documentation
├── plugins/              # Plugin development guide
├── .github/workflows/    # CI (Python 3.10/3.11/3.12 matrix)
├── run.py                # Single-command launcher
├── requirements.txt      # Python dependencies
├── Dockerfile            # Production image (Python 3.11 + Godot 4.3)
├── docker-compose.yml    # One-command local dev stack
├── pytest.ini            # Test configuration
├── .env.example          # Environment variable template
└── .gitignore            # Comprehensive (Python + Godot + IDE + OS)
```

---

## 🚀 Quick Start

### Prerequisites

- **Python 3.10+** (3.11 or 3.12 recommended)
- **Godot 4.3** (optional — only needed for Godot CLI validation)
- **Z.AI CLI** (`npm install -g z-ai`) — for real Z.AI provider (mock works without it)
- **Google Gemini API key** — for real Gemini provider (mock works without it)

### Installation

```bash
# 1. Clone or download this repository
git clone https://github.com/YOUR_USERNAME/FOSTAS-OS.git
cd FOSTAS-OS

# 2. Create a virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env and fill in your API keys (or leave blank for mock mode)

# 5. Run FOSTAS OS
python run.py
```

This boots:
- **FastAPI backend** on `http://localhost:8000`
- **Streamlit frontend** on `http://localhost:8501`
- Auto-seeds the knowledge base on first run

### Docker Quick Start

```bash
docker-compose up
```

Boots backend + frontend + Godot CLI in a single container with all volumes mounted.

---

## 🎯 Usage

### Via Streamlit UI

Open `http://localhost:8501` and use the prompt panel:

- **"Add a new weapon called the Plasma Rifle"**
- **"Create a new monster called the Shadow Beast"**
- **"Fix multiplayer lag in player movement"**
- **"Scan my project and report all weapons and monsters"**

### Via API

```bash
# Health check
curl http://localhost:8000/health

# Submit a prompt
curl -X POST http://localhost:8000/api/prompt \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Add a healing potion"}'

# List knowledge docs
curl http://localhost:8000/api/knowledge

# Scan the Godot project
curl http://localhost:8000/api/workspace/scan
```

### Via WebSocket (real-time streaming)

```javascript
const ws = new WebSocket("ws://localhost:8000/ws/prompt");
ws.onopen = () => ws.send(JSON.stringify({prompt: "Add a new weapon"}));
ws.onmessage = (e) => {
  const event = JSON.parse(e.data);
  console.log(event.type, event.data);  // analysis, knowledge, plan, task_started, ...
};
```

---

## 🔧 Configuration

All configuration is via environment variables (`.env` file). See [`.env.example`](.env.example) for the complete list.

### Provider Modes

| Variable | Default | Description |
|----------|---------|-------------|
| `ZAI_REAL` | `true` | Use real Z.AI CLI (false = mock) |
| `GEMINI_REAL` | `true` | Use real Gemini SDK (false = mock) |
| `TRIPO_REAL` | `false` | Use real Tripo API (false = mock; v2) |

### Security

| Variable | Default | Description |
|----------|---------|-------------|
| `AUTH_ENABLED` | `false` | Require `X-API-Key` header on all `/api/*` endpoints |
| `FOSTAS_API_KEY` | (empty) | The API key clients must send when `AUTH_ENABLED=true` |
| `RATE_LIMIT_ENABLED` | `true` | Per-IP token-bucket rate limiting |
| `RATE_LIMIT_PER_MINUTE` | `120` | Max requests per IP per 60-second window |

### Plugins

| Variable | Default | Description |
|----------|---------|-------------|
| `FOSTAS_PLUGINS` | (empty) | Comma-separated Python module paths to load as plugins |

Example plugin module:

```python
# my_plugin.py
from backend.providers.base import BaseProvider, AIResponse

class MyProvider(BaseProvider):
    async def chat(self, prompt: str, system: str = "", **kw) -> AIResponse:
        ...

def register(registry):
    registry("my_provider", MyProvider)
```

Launch with `FOSTAS_PLUGINS=my_plugin python run.py`.

---

## 🧪 Testing

```bash
# Run the 42-test pytest suite
pytest tests/ -v

# Run the 4-demo-prompt end-to-end smoke test
python scripts/test_pipeline.py

# Run via the launcher (boots backend first if needed)
python run.py --test
```

All tests run in mock mode (no API keys required).

---

## 📚 Documentation

- [`godot/docs/Production_Roadmap.md`](godot/docs/Production_Roadmap.md) — 12-phase roadmap to commercial release
- [`godot/docs/GDD.md`](godot/docs/GDD.md) — Game Design Document
- [`godot/docs/TDD.md`](godot/docs/TDD.md) — Technical Design Document
- [`knowledge/`](knowledge/) — 9-doc knowledge base (GameBible, Weapons, Magic, Maps, Monster, Networking, Optimization, Potions, Vehicles)
- [`.env.example`](.env.example) — Complete environment variable reference

---

## 🎮 FOSTAS: Toybox Terror (the game)

FOSTAS OS builds and maintains **FOSTAS: Toybox Terror** — an online 5v5 multiplayer FPS for PC (Steam) built in Godot 4.3. The game pairs a brightly-colored stylized toy-world aesthetic with a mid-match psychological-horror event.

**Current status:** Phase 1 (Core Game Foundation) complete. See the [Production Roadmap](godot/docs/Production_Roadmap.md) for the full 12-phase plan.

### Game Highlights
- **5v5 lobby-based** multiplayer with dedicated server (20 Hz tick, 200 ms lag compensation)
- **2 classes:** Combat Medic (support) and Tactical Mage (caster with spell quests)
- **11 toy-reskinned weapons** + universal sidearm
- **Hardcore 6-limb injury system** with Last Stand and Bloodlust mechanics
- **FOSTAS Monster event** — 4-phase horror sequence (Blackout → Warning → Hunt → Recovery)
- **60 FPS target** on GTX 1060 / 1080p medium

---

## 🤝 AI Providers

| Provider | Role | Mode | Notes |
|----------|------|------|-------|
| **Z.AI 5.2** | Primary Programming AI | Real (via `z-ai` CLI) | GDScript codegen, gameplay, multiplayer, scenes |
| **Google Gemini** | Architecture & Analysis | Real (via `google-genai` SDK) | Prompt analysis, planning, code review, optimization |
| **Tripo AI** | 3D Asset Generation | Mock (v1) / Real (v2) | Props, buildings, environment, FBX/GLB models |

Never hardcode API keys — all secrets read from `.env`.

---

## 🛡️ Security

- **No hardcoded secrets** — all API keys read from environment variables
- **Secret scanner** — pre-write gate refuses to write files containing leaked keys
- **Path-traversal protection** — all Godot file operations sandboxed
- **Automatic backups** — timestamped backups before every Godot file edit
- **Optional API-key auth** + rate limiting + audit logging
- **GDScript validator** — pre-write gate rejects malformed AI output

---

## 📦 Deployment

### Docker

```bash
docker-compose up -d
```

The Dockerfile installs Python 3.11 + Godot 4.3 headless binary. Healthcheck hits `/health` every 30s.

### Manual

```bash
pip install -r requirements.txt
python run.py
```

---

## 🔄 CI/CD

GitHub Actions workflow (`.github/workflows/ci.yml`) runs on every push/PR:
- **Test matrix:** Python 3.10, 3.11, 3.12
- **pytest** unit tests (42 tests)
- **Pipeline smoke test** (4 demo prompts)
- **Ruff lint** (E + F rules)

---

## 📄 License

MIT License — see [LICENSE](LICENSE).

---

## 🙏 Acknowledgments

- **Z.AI** — primary programming AI provider
- **Google Gemini** — architecture and analysis provider
- **Tripo AI** — 3D asset generation provider
- **Godot Engine** — game engine (Godot 4.3)
- **FastAPI** — backend web framework
- **Streamlit** — frontend UI framework

---

## 📊 Project Status

| Component | Status |
|-----------|--------|
| FOSTAS OS backend | ✅ v1.1.0 — feature complete |
| FOSTAS OS frontend | ✅ v1.1.0 — 8-panel Streamlit SPA |
| Knowledge base | ✅ 9 docs, ~60 KB (merged with dev report) |
| Test suite | ✅ 42 pytest tests, all passing |
| Docker + CI | ✅ Dockerfile + docker-compose + GitHub Actions |
| FOSTAS game (Phase 1) | ✅ Core foundation: player, HP, networking framework |
| FOSTAS game (Phase 2+) | 🔄 See [Production Roadmap](godot/docs/Production_Roadmap.md) |

---

**Built with FOSTAS OS — the AI Operating System for Game Development.**
