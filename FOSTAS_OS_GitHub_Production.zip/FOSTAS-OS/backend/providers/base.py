"""
FOSTAS OS — AI Provider Base Interface

Every provider (Z.AI, Gemini, Tripo) implements this interface.
This makes the orchestrator provider-agnostic and lets us add
new providers without touching orchestrator code.
"""
from __future__ import annotations

import abc
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from backend.core import logger


@dataclass
class AIResponse:
    """Standardized response from any AI provider."""

    provider: str
    model: str
    content: str
    raw: Optional[Dict[str, Any]] = None
    duration_ms: int = 0
    success: bool = True
    error: Optional[str] = None
    usage: Dict[str, int] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AssetResponse:
    """Response from an asset-generation provider (Tripo, etc.)."""

    provider: str
    asset_url: str
    asset_format: str  # "glb", "fbx", "png", etc.
    thumbnail_url: Optional[str] = None
    duration_ms: int = 0
    success: bool = True
    error: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


class BaseProvider(abc.ABC):
    """Abstract base class for all AI providers.

    SECURITY: The `api_key` attribute is stored internally but NEVER exposed
    via `__repr__`, `__str__`, serialization, or logs. The default Python
    `repr()` would include it, so we override `__repr__` to mask the key.
    """

    name: str = "base"
    default_model: str = "unknown"
    real_mode: bool = False

    def __init__(self, api_key: str = "", real_mode: bool = False, **kwargs):
        self.api_key = api_key
        self.real_mode = real_mode
        self.kwargs = kwargs

    def __repr__(self) -> str:
        """Mask the API key in repr to prevent leakage in error messages / logs."""
        key_status = "set" if self.api_key else "empty"
        return (
            f"<{self.__class__.__name__} name={self.name!r} "
            f"model={self.default_model!r} real_mode={self.real_mode} "
            f"api_key={key_status}>"
        )

    def __str__(self) -> str:
        """Mask the API key in str (same as repr)."""
        return self.__repr__()

    def get_api_key_masked(self) -> str:
        """Return a masked version of the API key for safe display.
        Returns '***...***<last4>' if key is set, 'empty' otherwise."""
        if not self.api_key:
            return "empty"
        if len(self.api_key) <= 8:
            return "***"
        return f"***...{self.api_key[-4:]}"

    @abc.abstractmethod
    async def chat(
        self,
        prompt: str,
        system: Optional[str] = None,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> AIResponse:
        """Send a chat completion request."""
        ...

    async def safe_chat(self, *args, **kwargs) -> AIResponse:
        """Wrap chat() with logging + error handling."""
        prompt = args[0] if args else kwargs.get("prompt", "")
        system = kwargs.get("system") or (args[1] if len(args) > 1 else None)
        logger.ai_request(
            provider=self.name,
            model=kwargs.get("model") or self.default_model,
            prompt_summary=prompt[:500],
            real_mode=self.real_mode,
            system_summary=(system or "")[:200],
        )
        start = time.time()
        try:
            resp = await self.chat(*args, **kwargs)
            resp.duration_ms = int((time.time() - start) * 1000)
            logger.ai_response(
                provider=self.name,
                model=resp.model,
                response_summary=resp.content[:500],
                duration_ms=resp.duration_ms,
                success=resp.success,
                error=resp.error,
            )
            return resp
        except Exception as e:
            duration_ms = int((time.time() - start) * 1000)
            logger.ai_response(
                provider=self.name,
                model=kwargs.get("model") or self.default_model,
                response_summary="",
                duration_ms=duration_ms,
                success=False,
                error=str(e),
            )
            return AIResponse(
                provider=self.name,
                model=kwargs.get("model") or self.default_model,
                content="",
                duration_ms=duration_ms,
                success=False,
                error=str(e),
            )


class AssetProvider(BaseProvider):
    """Base class for asset-generating providers (Tripo, etc.)."""

    @abc.abstractmethod
    async def generate_asset(
        self,
        prompt: str,
        asset_format: str = "glb",
        **kwargs,
    ) -> AssetResponse:
        """Generate a 3D asset from a text prompt."""
        ...

    async def safe_generate_asset(self, prompt: str, **kwargs) -> AssetResponse:
        """Wrap generate_asset() with logging + error handling."""
        logger.ai_request(
            provider=self.name,
            model=self.default_model,
            prompt_summary=f"[ASSET GEN] {prompt[:400]}",
            real_mode=self.real_mode,
        )
        start = time.time()
        try:
            resp = await self.generate_asset(prompt, **kwargs)
            resp.duration_ms = int((time.time() - start) * 1000)
            logger.ai_response(
                provider=self.name,
                model=self.default_model,
                response_summary=f"asset_url={resp.asset_url}",
                duration_ms=resp.duration_ms,
                success=resp.success,
                error=resp.error,
            )
            return resp
        except Exception as e:
            return AssetResponse(
                provider=self.name,
                asset_url="",
                asset_format=kwargs.get("asset_format", "glb"),
                duration_ms=int((time.time() - start) * 1000),
                success=False,
                error=str(e),
            )
