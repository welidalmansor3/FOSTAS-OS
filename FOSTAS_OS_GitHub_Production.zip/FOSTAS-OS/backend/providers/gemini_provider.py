"""
FOSTAS OS — Google Gemini Provider (REAL)

Gemini is the ARCHITECTURE / PLANNING AI in FOSTAS OS:
  - Prompt analysis (intent, complexity, risk, required files)
  - Architecture & design review
  - Documentation generation
  - Code review & optimization
  - Task decomposition (split complex requests)

Falls back to a deterministic rule-based mock if GEMINI_REAL=false
or no API key.

Model: gemini-2.5-flash (default; fast + capable for planning tasks).
"""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

from backend.core import logger
from backend.providers.base import AIResponse, BaseProvider


class GeminiProvider(BaseProvider):
    """Google Gemini provider — real (google-genai SDK) or mock."""

    name = "gemini"
    default_model = "gemini-2.5-flash"
    real_mode = True

    def __init__(self, api_key: str = "", real_mode: bool = True, **kwargs):
        super().__init__(api_key=api_key, real_mode=real_mode, **kwargs)
        self._client = None
        if real_mode and not api_key:
            logger.warning(
                "GEMINI_API_KEY not set in .env; Gemini will run in MOCK mode"
            )
            self.real_mode = False

        if self.real_mode:
            try:
                from google import genai
                from google.genai import types

                self._genai = genai
                self._types = types
                self._client = genai.Client(api_key=api_key)
            except Exception as e:
                logger.warning(
                    f"google-genai SDK init failed: {e}; falling back to mock"
                )
                self.real_mode = False

    async def chat(
        self,
        prompt: str,
        system: Optional[str] = None,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> AIResponse:
        if not self.real_mode or self._client is None:
            return self._mock_chat(prompt, system, model, temperature)

        return await self._real_chat(
            prompt, system, model, temperature, max_tokens, **kwargs
        )

    async def _real_chat(
        self,
        prompt: str,
        system: Optional[str],
        model: Optional[str],
        temperature: float,
        max_tokens: Optional[int],
        **kwargs,
    ) -> AIResponse:
        """Call the Gemini API via google-genai SDK."""
        import asyncio

        model_name = model or self.default_model

        # Build config
        config_kwargs: Dict[str, Any] = {"temperature": temperature}
        if system:
            config_kwargs["system_instruction"] = system
        if max_tokens:
            config_kwargs["max_output_tokens"] = max_tokens

        config = self._types.GenerateContentConfig(**config_kwargs)

        def _call():
            return self._client.models.generate_content(
                model=model_name,
                contents=prompt,
                config=config,
            )

        try:
            response = await asyncio.to_thread(_call)
            content = response.text or ""

            usage_meta = getattr(response, "usage_metadata", None)
            usage = {}
            if usage_meta:
                usage = {
                    "prompt_tokens": getattr(usage_meta, "prompt_token_count", 0) or 0,
                    "completion_tokens": getattr(
                        usage_meta, "candidates_token_count", 0
                    ) or 0,
                    "total_tokens": getattr(usage_meta, "total_token_count", 0) or 0,
                }

            return AIResponse(
                provider=self.name,
                model=model_name,
                content=content,
                raw={"model": model_name},
                success=True,
                usage=usage,
            )
        except Exception as e:
            return AIResponse(
                provider=self.name,
                model=model_name,
                content="",
                success=False,
                error=f"Gemini API error: {e}",
            )

    # ----------------------------------------------------------------
    # MOCK MODE — deterministic, rule-based, no external calls
    # ----------------------------------------------------------------

    def _mock_chat(
        self,
        prompt: str,
        system: Optional[str],
        model: Optional[str],
        temperature: float,
    ) -> AIResponse:
        """Rule-based mock that produces realistic-shaped planning output."""
        # Detect if this is a prompt-analysis request by looking at system prompt
        sys_lower = (system or "").lower()
        prompt_lower = prompt.lower()

        if "prompt_analyzer" in sys_lower or "analyze the following user prompt" in sys_lower:
            content = self._mock_analyze_prompt(prompt)
        elif "task_plan" in sys_lower or "decompose" in sys_lower:
            content = self._mock_task_plan(prompt)
        elif "code_review" in sys_lower or "review" in sys_lower:
            content = self._mock_code_review(prompt)
        else:
            content = f"[MOCK GEMINI] {prompt[:300]}"

        return AIResponse(
            provider=self.name,
            model=model or self.default_model,
            content=content,
            raw={"mock": True},
            success=True,
            usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            metadata={"mock": True},
        )

    @staticmethod
    def _mock_analyze_prompt(prompt: str) -> str:
        """Produce a JSON analysis matching PromptAnalysis schema."""
        p = prompt.lower()
        intent = "unknown"
        complexity = "medium"
        risk = "low"
        required_providers = ["zai"]
        required_files: list[str] = []
        knowledge_docs: list[str] = []

        if "add" in p and "weapon" in p:
            intent = "add_weapon"
            complexity = "medium"
            required_files = [
                "godot/scripts/weapons/new_weapon.gd",
                "godot/scenes/new_weapon.tscn",
            ]
            knowledge_docs = ["Weapons.md", "GameBible.md"]
        elif "create" in p and ("monster" in p or "enemy" in p):
            intent = "create_monster"
            complexity = "medium"
            required_providers = ["zai", "tripo"]
            required_files = [
                "godot/scripts/monsters/new_monster.gd",
                "godot/scenes/new_monster.tscn",
            ]
            knowledge_docs = ["Monster.md", "GameBible.md"]
        elif "fix" in p and ("lag" in p or "network" in p or "multiplayer" in p):
            intent = "fix_bug"
            complexity = "high"
            risk = "medium"
            required_files = ["godot/scripts/network/player_network.gd"]
            knowledge_docs = ["Networking.md", "Optimization.md"]
        elif "scan" in p:
            intent = "scan_project"
            complexity = "low"
            required_providers = []
            knowledge_docs = []
        elif "magic" in p or "spell" in p:
            intent = "add_magic"
            complexity = "high"
            required_files = ["godot/scripts/magic/spell.gd"]
            knowledge_docs = ["Magic.md", "GameBible.md"]

        import json as _json
        analysis = {
            "intent": intent,
            "complexity": complexity,
            "risk": risk,
            "required_providers": required_providers,
            "required_files": required_files,
            "required_assets": [],
            "knowledge_docs": knowledge_docs,
            "subtasks": [],
            "summary": f"Mock analysis for: {prompt[:150]}",
        }
        return _json.dumps(analysis, indent=2)

    @staticmethod
    def _mock_task_plan(prompt: str) -> str:
        """Produce a JSON task plan."""
        import json as _json
        plan = {
            "tasks": [
                {
                    "id": 1,
                    "description": "Load relevant knowledge docs",
                    "provider": "internal",
                    "depends_on": [],
                },
                {
                    "id": 2,
                    "description": "Generate GDScript code",
                    "provider": "zai",
                    "depends_on": [1],
                },
                {
                    "id": 3,
                    "description": "Apply changes to Godot project",
                    "provider": "godot_manager",
                    "depends_on": [2],
                },
                {
                    "id": 4,
                    "description": "Validate via Godot CLI",
                    "provider": "godot_manager",
                    "depends_on": [3],
                },
            ]
        }
        return _json.dumps(plan, indent=2)

    @staticmethod
    def _mock_code_review(prompt: str) -> str:
        return """Code review (MOCK):
- No syntax errors detected
- Suggest adding type hints
- Consider extracting magic numbers to constants
- Overall: APPROVED for production"""
