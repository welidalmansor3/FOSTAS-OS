"""
FOSTAS OS — Tripo AI Provider (MOCK in v1)

Tripo is the 3D ASSET GENERATION AI in FOSTAS OS:
  - Props
  - Buildings
  - Environment
  - FBX / GLB models

v1 ships with a mock adapter that returns a placeholder asset URL.
When TRIPO_REAL=true and TRIPO_API_KEY is set, this module will call
the real Tripo API (https://platform.tripo3d.ai/docs). The mock is
deterministic and produces a valid response shape so the orchestrator
pipeline can be tested end-to-end without external dependencies.
"""
from __future__ import annotations

import asyncio
import hashlib
import time
from typing import Any, Dict, Optional

from backend.core import logger
from backend.providers.base import AssetProvider, AssetResponse


class TripoProvider(AssetProvider):
    """Tripo 3D asset generation provider — mock or real."""

    name = "tripo"
    default_model = "tripo-v3"
    real_mode = False

    # Placeholder GLB that always exists — used by mock
    PLACEHOLDER_GLB = "https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Box/glTF-Binary/Box.glb"

    def __init__(self, api_key: str = "", real_mode: bool = False, **kwargs):
        super().__init__(api_key=api_key, real_mode=real_mode, **kwargs)
        if real_mode and not api_key:
            logger.warning("TRIPO_API_KEY not set; Tripo will run in MOCK mode")
            self.real_mode = False
        # Real-mode HTTP client is lazily initialized
        self._http_client = None

    async def chat(
        self,
        prompt: str,
        system: Optional[str] = None,
        model: Optional[str] = None,
        **kwargs,
    ) -> AssetResponse:  # type: ignore[override]
        """Tripo is an asset provider, not a chat provider. Returns asset response."""
        return await self.safe_generate_asset(prompt)

    async def generate_asset(
        self,
        prompt: str,
        asset_format: str = "glb",
        **kwargs,
    ) -> AssetResponse:
        if not self.real_mode:
            return await self._mock_generate(prompt, asset_format)
        return await self._real_generate(prompt, asset_format, **kwargs)

    async def _mock_generate(
        self, prompt: str, asset_format: str
    ) -> AssetResponse:
        """Deterministic mock — returns a real-world placeholder GLB URL."""
        # Simulate API latency
        await asyncio.sleep(0.2)

        # Hash the prompt for a stable fake task ID
        prompt_hash = hashlib.sha256(prompt.encode()).hexdigest()[:12]
        task_id = f"mock_task_{prompt_hash}"

        return AssetResponse(
            provider=self.name,
            asset_url=self.PLACEHOLDER_GLB,
            asset_format=asset_format,
            thumbnail_url=None,
            success=True,
            raw={
                "mock": True,
                "task_id": task_id,
                "original_prompt": prompt,
                "note": "Mock Tripo response — set TRIPO_REAL=true for real API",
            },
        )

    async def _real_generate(
        self, prompt: str, asset_format: str, **kwargs
    ) -> AssetResponse:
        """Call real Tripo API. Documented for v2 — not exercised in v1."""
        import httpx

        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                base_url="https://api.tripo3d.ai/v2",
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=120.0,
            )

        try:
            # Step 1: Create task
            resp = await self._http_client.post(
                "/task",
                json={
                    "type": "text_to_model",
                    "prompt": prompt,
                    "output_format": asset_format,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            task_id = data.get("data", {}).get("task_id")
            if not task_id:
                return AssetResponse(
                    provider=self.name,
                    asset_url="",
                    asset_format=asset_format,
                    success=False,
                    error="Tripo API returned no task_id",
                )

            # Step 2: Poll for completion (max 5 minutes)
            for _ in range(60):
                await asyncio.sleep(5)
                poll = await self._http_client.get(f"/task/{task_id}")
                poll.raise_for_status()
                poll_data = poll.json().get("data", {})
                status = poll_data.get("status")
                if status == "success":
                    return AssetResponse(
                        provider=self.name,
                        asset_url=poll_data.get("model_url", ""),
                        asset_format=asset_format,
                        thumbnail_url=poll_data.get("thumbnail_url"),
                        success=True,
                        raw={"task_id": task_id, "poll_data": poll_data},
                    )
                if status == "failed":
                    return AssetResponse(
                        provider=self.name,
                        asset_url="",
                        asset_format=asset_format,
                        success=False,
                        error=f"Tripo task failed: {poll_data.get('error')}",
                    )

            return AssetResponse(
                provider=self.name,
                asset_url="",
                asset_format=asset_format,
                success=False,
                error="Tripo task timed out after 5 minutes",
            )
        except Exception as e:
            return AssetResponse(
                provider=self.name,
                asset_url="",
                asset_format=asset_format,
                success=False,
                error=f"Tripo API error: {e}",
            )

    async def close(self) -> None:
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
