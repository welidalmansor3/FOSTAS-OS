"""FOSTAS OS — AI Provider registry & factory."""
from __future__ import annotations

from typing import Dict, Optional

from backend.providers.base import AIResponse, AssetProvider, AssetResponse, BaseProvider
from backend.providers.gemini_provider import GeminiProvider
from backend.providers.tripo_provider import TripoProvider
from backend.providers.zai_provider import ZAIProvider
from config.settings import get_settings


# Singleton instances (created lazily on first access)
_providers: Dict[str, BaseProvider] = {}


def get_zai() -> ZAIProvider:
    if "zai" not in _providers:
        s = get_settings()
        _providers["zai"] = ZAIProvider(
            api_key=s.zai_api_key,
            real_mode=s.zai_real,
        )
    return _providers["zai"]  # type: ignore


def get_gemini() -> GeminiProvider:
    if "gemini" not in _providers:
        s = get_settings()
        _providers["gemini"] = GeminiProvider(
            api_key=s.gemini_api_key,
            real_mode=s.gemini_real,
        )
    return _providers["gemini"]  # type: ignore


def get_tripo() -> TripoProvider:
    if "tripo" not in _providers:
        s = get_settings()
        _providers["tripo"] = TripoProvider(
            api_key=s.tripo_api_key,
            real_mode=s.tripo_real,
        )
    return _providers["tripo"]  # type: ignore


def get_provider(name: str) -> BaseProvider:
    """Get a provider by name."""
    name = name.lower()
    if name == "zai":
        return get_zai()
    if name == "gemini":
        return get_gemini()
    if name == "tripo":
        return get_tripo()
    raise ValueError(f"Unknown provider: {name}")


def list_providers() -> Dict[str, Dict]:
    """Return status of all providers."""
    s = get_settings()
    return {
        "zai": {
            "role": "Primary Programming AI (Godot scripts, gameplay, multiplayer)",
            "real_mode": s.zai_real,
            "model": "glm-4-plus",
            "available": True,
        },
        "gemini": {
            "role": "Architecture, Planning, Code Review",
            "real_mode": s.gemini_real,
            "model": "gemini-2.5-flash",
            "available": bool(s.gemini_api_key) or not s.gemini_real,
        },
        "tripo": {
            "role": "3D Asset Generation (props, buildings, environment)",
            "real_mode": s.tripo_real,
            "model": "tripo-v3",
            "available": True,  # mock always available
        },
    }


__all__ = [
    "AIResponse",
    "AssetResponse",
    "AssetProvider",
    "BaseProvider",
    "GeminiProvider",
    "TripoProvider",
    "ZAIProvider",
    "get_provider",
    "get_zai",
    "get_gemini",
    "get_tripo",
    "list_providers",
]
