"""
FOSTAS OS — Z.AI Provider (REAL)

Z.AI is the PRIMARY PROGRAMMING AI in FOSTAS OS:
  - Godot scripts (.gd)
  - Gameplay systems
  - Multiplayer / networking logic
  - AI logic
  - Scene generation (.tscn)
  - Project editing

This provider uses the `z-ai-web-dev-sdk` via the installed `z-ai` CLI
(Node SDK is the canonical interface; we shell out to avoid Node deps).
Falls back to a deterministic mock if ZAI_REAL=false or no API key.

Model: glm-4-plus (default for code generation).
"""
from __future__ import annotations

import asyncio
import json
import os
import shlex
import shutil
import tempfile
from typing import Any, Dict, Optional

from backend.core import logger
from backend.providers.base import AIResponse, BaseProvider


class ZAIProvider(BaseProvider):
    """Z.AI provider — real (via z-ai CLI) or mock."""

    name = "zai"
    default_model = "glm-4-plus"
    real_mode = True

    def __init__(self, api_key: str = "", real_mode: bool = True, **kwargs):
        super().__init__(api_key=api_key, real_mode=real_mode, **kwargs)
        self.cli_path = shutil.which("z-ai")
        if real_mode and not self.cli_path:
            logger.warning(
                "z-ai CLI not found on PATH; falling back to mock mode for Z.AI"
            )
            self.real_mode = False
        if real_mode and not api_key:
            # The CLI may pick up the key from a global env; warn but don't fail
            logger.warning(
                "ZAI_API_KEY not set in .env; relying on z-ai CLI's own auth"
            )

    async def chat(
        self,
        prompt: str,
        system: Optional[str] = None,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> AIResponse:
        if not self.real_mode:
            return self._mock_chat(prompt, system, model)

        return await self._real_chat(prompt, system, model, temperature, **kwargs)

    async def _real_chat(
        self,
        prompt: str,
        system: Optional[str],
        model: Optional[str],
        temperature: float,
        **kwargs,
    ) -> AIResponse:
        """Invoke `z-ai chat` CLI and parse JSON response."""
        # Write prompt to a temp file to avoid shell-escaping issues
        # with multi-line code/quotes
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, encoding="utf-8"
        ) as pf:
            pf.write(prompt)
            prompt_file = pf.name

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False, encoding="utf-8"
        ) as of:
            output_file = of.name

        try:
            cmd = [
                self.cli_path, "chat",
                "--prompt", f"@{prompt_file}",  # z-ai accepts @file for stdin
                "--output", output_file,
            ]
            # z-ai CLI doesn't accept @file; pass prompt directly via stdin
            cmd = [
                self.cli_path, "chat",
                "--prompt", prompt,
                "--output", output_file,
            ]
            if system:
                cmd.extend(["--system", system])

            # Run in a thread pool to avoid blocking the event loop
            proc = await asyncio.to_thread(
                _run_subprocess, cmd, timeout=kwargs.get("timeout", 180)
            )

            if proc.returncode != 0:
                return AIResponse(
                    provider=self.name,
                    model=model or self.default_model,
                    content="",
                    success=False,
                    error=f"z-ai CLI exit {proc.returncode}: {proc.stderr[:500]}",
                )

            # Parse JSON output
            with open(output_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            content = (
                data.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            usage = data.get("usage", {})

            return AIResponse(
                provider=self.name,
                model=data.get("model", model or self.default_model),
                content=content,
                raw=data,
                success=True,
                usage={
                    "prompt_tokens": usage.get("prompt_tokens", 0),
                    "completion_tokens": usage.get("completion_tokens", 0),
                    "total_tokens": usage.get("total_tokens", 0),
                },
                metadata={"request_id": data.get("id", "")},
            )
        finally:
            for f in (prompt_file, output_file):
                try:
                    os.unlink(f)
                except OSError:
                    pass

    def _mock_chat(
        self,
        prompt: str,
        system: Optional[str],
        model: Optional[str],
    ) -> AIResponse:
        """Deterministic mock for offline / no-key mode."""
        content = self._mock_godot_response(prompt)
        return AIResponse(
            provider=self.name,
            model=model or self.default_model,
            content=content,
            raw={"mock": True},
            success=True,
            usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            metadata={"mock": True},
        )

    @staticmethod
    def _mock_godot_response(prompt: str) -> str:
        """Generate a plausible-looking Godot script response in mock mode."""
        prompt_lower = prompt.lower()
        if "weapon" in prompt_lower:
            return '''```gdscript
# weapon.gd — generated by FOSTAS OS (MOCK MODE)
extends Node3D
class_name Weapon

@export var weapon_name: String = "Toy Weapon"
@export var damage: int = 25
@export var fire_rate: float = 600.0  # RPM
@export var magazine_size: int = 30
@export var range: float = 60.0

var current_ammo: int

func _ready() -> void:
    current_ammo = magazine_size

func fire(from: Vector3, direction: Vector3) -> Dictionary:
    if current_ammo <= 0:
        return {"hit": false, "reason": "empty"}
    current_ammo -= 1
    # Raycast hit detection would go here
    return {"hit": true, "damage": damage, "ammo_left": current_ammo}

func reload() -> void:
    current_ammo = magazine_size
```'''
        if "monster" in prompt_lower or "enemy" in prompt_lower:
            return '''```gdscript
# monster.gd — generated by FOSTAS OS (MOCK MODE)
extends CharacterBody3D
class_name Monster

@export var max_health: int = 100
@export var move_speed: float = 4.0
@export var attack_damage: int = 20
@export var attack_range: float = 2.0
@export var detection_range: float = 15.0

var health: int

func _ready() -> void:
    health = max_health

func take_damage(amount: int) -> void:
    health = max(0, health - amount)
    if health == 0:
        die()

func die() -> void:
    queue_free()
```'''
        if "network" in prompt_lower or "multiplayer" in prompt_lower or "lag" in prompt_lower:
            return '''```gdscript
# player_network.gd — generated by FOSTAS OS (MOCK MODE)
# Multiplayer interpolation fix
extends Node

const INTERP_DELAY := 0.1  # 100ms buffer
var pending_states: Array = []

func _physics_process(delta: float) -> void:
    var now = Time.get_ticks_msec() / 1000.0
    while pending_states.size() > 1 and pending_states[1].t <= now - INTERP_DELAY:
        pending_states.pop_front()
    if pending_states.size() >= 2:
        var s0 = pending_states[0]
        var s1 = pending_states[1]
        var alpha = (now - INTERP_DELAY - s0.t) / max(0.001, s1.t - s0.t)
        alpha = clamp(alpha, 0.0, 1.0)
        get_parent().global_position = s0.pos.lerp(s1.pos, alpha)
```'''
        return f"""```gdscript
# Generated by FOSTAS OS (MOCK MODE)
# Prompt: {prompt[:200]}
extends Node

func _ready() -> void:
    print("FOSTAS OS mock response")
```"""


def _run_subprocess(cmd: list[str], timeout: int = 180):
    """Run subprocess synchronously (called via to_thread)."""
    import subprocess

    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
