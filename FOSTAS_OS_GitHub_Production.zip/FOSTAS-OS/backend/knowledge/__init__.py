"""FOSTAS OS Knowledge Base package."""
from .manager import KnowledgeManager, get_knowledge_manager, DEFAULT_DOCS

__all__ = ["KnowledgeManager", "get_knowledge_manager", "DEFAULT_DOCS"]
