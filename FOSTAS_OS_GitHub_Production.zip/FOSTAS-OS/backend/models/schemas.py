"""
FOSTAS OS — Data Models

Pydantic models that flow through the orchestrator pipeline:
  UserPrompt → PromptAnalysis → TaskPlan → TaskResults → CompletionReport
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ----------------------------------------------------------------
# Step 1: Prompt Analysis (output of Gemini)
# ----------------------------------------------------------------


class Intent(str, Enum):
    ADD_WEAPON = "add_weapon"
    ADD_MAP = "add_map"
    ADD_VEHICLE = "add_vehicle"
    ADD_POTION = "add_potion"
    ADD_MAGIC = "add_magic"
    CREATE_MONSTER = "create_monster"
    CREATE_CHARACTER = "create_character"
    FIX_BUG = "fix_bug"
    OPTIMIZE = "optimize"
    SCAN_PROJECT = "scan_project"
    DOCUMENTATION = "documentation"
    REFACTOR = "refactor"
    OTHER = "other"


class Complexity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Risk(str, Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class PromptAnalysis(BaseModel):
    """Structured analysis of a user prompt."""

    intent: Intent = Intent.OTHER
    summary: str = ""
    complexity: Complexity = Complexity.MEDIUM
    risk: Risk = Risk.LOW
    required_providers: List[str] = Field(default_factory=list)
    required_files: List[str] = Field(default_factory=list)
    required_assets: List[str] = Field(default_factory=list)
    knowledge_docs: List[str] = Field(default_factory=list)
    subtasks: List[str] = Field(default_factory=list)
    raw_response: Optional[str] = None


# ----------------------------------------------------------------
# Step 2: Task Plan
# ----------------------------------------------------------------


class Task(BaseModel):
    """A single unit of work in a task plan."""

    id: int
    description: str
    provider: str  # "gemini", "zai", "tripo", "godot_manager", "internal"
    depends_on: List[int] = Field(default_factory=list)
    status: str = "pending"  # pending | running | success | failed | skipped
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None

    def mark_started(self) -> None:
        self.status = "running"
        self.started_at = datetime.now(timezone.utc)

    def mark_success(self, result: Dict[str, Any]) -> None:
        self.status = "success"
        self.result = result
        self.finished_at = datetime.now(timezone.utc)

    def mark_failed(self, error: str) -> None:
        self.status = "failed"
        self.error = error
        self.finished_at = datetime.now(timezone.utc)


class TaskPlan(BaseModel):
    """Ordered list of tasks produced by the orchestrator."""

    tasks: List[Task] = Field(default_factory=list)
    reasoning: str = ""

    def get_ready_tasks(self) -> List[Task]:
        """Return tasks whose dependencies are all completed."""
        completed = {t.id for t in self.tasks if t.status == "success"}
        return [
            t
            for t in self.tasks
            if t.status == "pending"
            and all(dep in completed for dep in t.depends_on)
        ]


# ----------------------------------------------------------------
# Step 3: Execution Results
# ----------------------------------------------------------------


class FileChange(BaseModel):
    """Record of a single file modification."""

    action: str  # "create" | "edit" | "delete" | "backup"
    path: str
    bytes_written: Optional[int] = None
    backup_path: Optional[str] = None
    note: Optional[str] = None


class AIInteraction(BaseModel):
    """Record of a single AI call during execution."""

    provider: str
    model: str
    prompt_summary: str
    response_summary: str
    duration_ms: int
    success: bool
    error: Optional[str] = None


class CompletionReport(BaseModel):
    """Final report returned to the user after a prompt is processed."""

    prompt: str
    analysis: PromptAnalysis
    plan: TaskPlan
    file_changes: List[FileChange] = Field(default_factory=list)
    ai_interactions: List[AIInteraction] = Field(default_factory=list)
    knowledge_loaded: List[str] = Field(default_factory=list)
    success: bool = True
    overall_error: Optional[str] = None
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: Optional[datetime] = None
    duration_ms: int = 0
    summary: str = ""  # Human-readable summary
    artifacts: List[str] = Field(default_factory=list)  # Downloadable artifacts

    def finalize(self) -> None:
        self.finished_at = datetime.now(timezone.utc)
        self.duration_ms = int(
            (self.finished_at - self.started_at).total_seconds() * 1000
        )
