"""GDScript structural validator — pre-apply syntax sanity check.

This is NOT a full GDScript parser; it's a fast regex-based gate that
catches the most common AI-output defects before they get written to the
project. The authoritative check is the Godot CLI validation that runs
post-apply (`GodotManager.validate_project`).

Caught issues:
  - ERROR: missing `extends` keyword (GDScript 2.0 requires it).
  - ERROR: tab indentation (Godot 4 .gd files must use 4-space indent).
  - ERROR: mixed tabs and spaces.
  - WARNING: bare `pass` outside any function (likely leftover stub).
  - ERROR: `TODO` / `FIXME` / `XXX` / `HACK` markers (AAA rule: no placeholders).
  - WARNING: `$NodePath` references containing whitespace or non-ASCII
    (likely leftover AI artifacts).
  - WARNING: file longer than 2000 lines (likely bloated AI output).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List


@dataclass
class GDScriptIssue:
    severity: str  # "error" | "warning"
    line: int  # 1-indexed; 0 for file-level
    message: str
    snippet: str = ""


class GDScriptValidator:
    """Regex-based GDScript structural validator."""

    MAX_LINES = 2000
    TAB_RE = re.compile(r"^\t")
    SPACE_INDENT_RE = re.compile(r"^    ")
    EXTENDS_RE = re.compile(r"^\s*extends\s+\S+")
    CLASS_NAME_RE = re.compile(r"^\s*class_name\s+\S+")
    TODO_RE = re.compile(r"\b(TODO|FIXME|XXX|HACK)\b", re.IGNORECASE)
    PASS_OUTSIDE_FUNC_RE = re.compile(r"^(\s*)pass\s*$")
    FUNC_RE = re.compile(r"^\s*func\s+")
    NODE_REF_RE = re.compile(r"\$([\w/.]+)")
    PLACEHOLDER_RE = re.compile(
        r"\b(placeholder|your code here|fill in|stub_)",
        re.IGNORECASE,
    )

    def validate(self, content: str, file_path: str = "") -> List[GDScriptIssue]:
        issues: List[GDScriptIssue] = []
        lines = content.splitlines()

        # File-level checks.
        if not any(self.EXTENDS_RE.match(l) or self.CLASS_NAME_RE.match(l) for l in lines):
            issues.append(
                GDScriptIssue(
                    severity="error",
                    line=0,
                    message=(
                        "Missing `extends <Base>` declaration. GDScript 2.0 requires "
                        "every script to extend a base class (or be a tool script)."
                    ),
                )
            )

        if len(lines) > self.MAX_LINES:
            issues.append(
                GDScriptIssue(
                    severity="warning",
                    line=0,
                    message=(
                        f"File has {len(lines)} lines (> {self.MAX_LINES}). "
                        "Likely bloated AI output; consider splitting."
                    ),
                )
            )

        # Per-line checks.
        in_func_depth = 0
        for i, line in enumerate(lines, start=1):
            stripped = line.lstrip()

            # Indentation: reject tabs entirely.
            if self.TAB_RE.match(line):
                issues.append(
                    GDScriptIssue(
                        severity="error",
                        line=i,
                        message="Tab indentation is forbidden in GDScript 2.0; use 4 spaces.",
                        snippet=line[:80],
                    )
                )

            # TODO/FIXME markers.
            if self.TODO_RE.search(line):
                issues.append(
                    GDScriptIssue(
                        severity="error",
                        line=i,
                        message="TODO/FIXME/XXX/HACK marker found — AAA rule forbids placeholders.",
                        snippet=line.strip()[:80],
                    )
                )

            # Placeholder phrases.
            if self.PLACEHOLDER_RE.search(line):
                issues.append(
                    GDScriptIssue(
                        severity="error",
                        line=i,
                        message=(
                            "Placeholder phrase ('placeholder' / 'your code here' / 'stub_') "
                            "found — AAA rule forbids placeholders."
                        ),
                        snippet=line.strip()[:80],
                    )
                )

            # Bare `pass` outside any function (heuristic — track func depth).
            if self.FUNC_RE.match(line):
                in_func_depth += 1
            if self.PASS_OUTSIDE_FUNC_RE.match(line) and in_func_depth == 0:
                issues.append(
                    GDScriptIssue(
                        severity="warning",
                        line=i,
                        message="Bare `pass` at module level — likely a leftover stub.",
                        snippet=line.strip()[:80],
                    )
                )

            # Suspicious $NodePath references.
            for match in self.NODE_REF_RE.finditer(line):
                node_path = match.group(1)
                if any(c.isspace() or ord(c) > 127 for c in node_path):
                    issues.append(
                        GDScriptIssue(
                            severity="warning",
                            line=i,
                            message=(
                                f"Suspicious $NodePath '{node_path}' contains whitespace "
                                "or non-ASCII — likely an AI artifact."
                            ),
                            snippet=line.strip()[:80],
                        )
                    )

        return issues
