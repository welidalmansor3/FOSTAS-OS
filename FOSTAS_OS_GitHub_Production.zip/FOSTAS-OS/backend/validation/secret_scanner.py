"""Secret scanner — refuse to write files that contain leaked API keys.

Scans content for common secret patterns:
  - Environment-variable assignments: `ZAI_API_KEY=...`, `GEMINI_API_KEY=...`,
    `TRIPO_API_KEY=...`, `FOSTAS_API_KEY=...`.
  - Generic API key patterns: `api_key="..."`, `API_KEY: "..."`, `sk-...`.
  - AWS-style keys: `AKIA...`.
  - Bearer tokens: `Bearer eyJ...`.
  - Long hex strings labeled as secrets.

If any secret is found, the orchestrator's pre-apply validation gate
refuses to write the file and returns the issues to the user.

This is defense-in-depth — the orchestrator should never leak secrets into
generated code in the first place, but a single mistake (e.g. Gemini
echoing the system prompt) could expose them. The scanner is the last line.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List


@dataclass
class SecretIssue:
    severity: str  # always "error" — secrets are always blockers
    line: int  # 1-indexed
    pattern_name: str
    snippet: str  # masked snippet for the log


class SecretScanner:
    """Regex-based secret scanner for AI-generated file content."""

    # Each tuple is (pattern_name, compiled_regex). Patterns are case-insensitive.
    PATTERNS: list[tuple[str, re.Pattern]] = [
        (
            "FOSTAS env var",
            re.compile(
                r"\b(ZAI_API_KEY|GEMINI_API_KEY|TRIPO_API_KEY|FOSTAS_API_KEY)"
                r"\s*[:=]\s*[\"\']?[A-Za-z0-9_\-]{8,}[\"\']?",
                re.IGNORECASE,
            ),
        ),
        (
            "Generic api_key assignment",
            re.compile(
                r"\bapi[_-]?key\b\s*[:=]\s*[\"\'][A-Za-z0-9_\-]{16,}[\"\']",
                re.IGNORECASE,
            ),
        ),
        (
            "AWS access key",
            re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
        ),
        (
            "OpenAI sk- key",
            re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"),
        ),
        (
            "Bearer JWT",
            re.compile(r"\bBearer\s+eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+"),
        ),
        (
            "Google API key",
            re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"),
        ),
        (
            "Slack token",
            re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{10,}\b"),
        ),
    ]

    def scan(self, content: str, file_path: str = "") -> List[SecretIssue]:
        issues: List[SecretIssue] = []
        lines = content.splitlines()
        for i, line in enumerate(lines, start=1):
            for name, pattern in self.PATTERNS:
                if pattern.search(line):
                    # Mask the matched portion for the audit log.
                    masked = pattern.sub(
                        lambda m: m.group(0)[:8] + "***REDACTED***",
                        line,
                    )[:200]
                    issues.append(
                        SecretIssue(
                            severity="error",
                            line=i,
                            pattern_name=name,
                            snippet=masked,
                        )
                    )
        return issues
