"""FOSTAS OS — Pre-apply validation for AI-generated code.

Two complementary validators run BEFORE any AI-generated file is written
to the Godot project:

1. `GDScriptValidator` — regex-based structural checks for .gd files:
   - Must start with `extends <Base>` (or have `class_name` before `extends`).
   - Must use 4-space indentation (no tabs — Godot 4 rejects tabs in .gd).
   - No bare `pass` outside `func`/`class` bodies.
   - No `TODO`/`FIXME`/`XXX`/`HACK` markers (AAA rule: no placeholders).
   - No undefined `$NodePath` references that look like leftover AI artifacts
     (heuristic: paths with spaces or non-ASCII).

2. `SecretScanner` — refuses to write any file whose contents look like they
   contain leaked API keys (ZAI_API_KEY=, GEMINI_API_KEY=, etc.). This is
   the defense-in-depth layer against the orchestrator ever baking a secret
   into a project file.

Both validators return a list of issues; the orchestrator decides whether
to block (issues with severity="error") or warn (severity="warning").
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

from .gdscript_validator import GDScriptValidator, GDScriptIssue
from .secret_scanner import SecretScanner, SecretIssue

__all__ = [
    "GDScriptIssue",
    "GDScriptValidator",
    "SecretIssue",
    "SecretScanner",
    "validate_gdscript",
    "scan_for_secrets",
]


def validate_gdscript(content: str, file_path: str = "") -> List[GDScriptIssue]:
    """Convenience wrapper — run the GDScript validator on a file's content."""
    return GDScriptValidator().validate(content, file_path)


def scan_for_secrets(content: str, file_path: str = "") -> List[SecretIssue]:
    """Convenience wrapper — scan a file's content for leaked secrets."""
    return SecretScanner().scan(content, file_path)
