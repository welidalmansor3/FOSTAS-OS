"""System endpoints (providers, plugins, version info, config status).

SECURITY: No endpoint in this file EVER returns an actual API key.
The /config endpoint returns only masked key status (e.g. '***...abcd')
so operators can verify keys are loaded without exposing them.
"""
from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter

from backend.plugins import list_plugins
from backend.providers import list_providers
from config.settings import get_settings

router = APIRouter(prefix="/api/system", tags=["system"])


@router.get("/providers")
async def get_providers() -> Dict[str, Any]:
    """List AI providers and their real/mock mode + availability.
    NEVER exposes API keys — only booleans and metadata."""
    return {"providers": list_providers()}


@router.get("/plugins")
async def get_plugins() -> Dict[str, Any]:
    """List installed plugin modules and their registered providers."""
    return {"plugins": list_plugins()}


@router.get("/config")
async def get_config_status() -> Dict[str, Any]:
    """Return masked API key status for operator visibility.

    SECURITY: This endpoint NEVER returns actual API key values.
    Each key is masked as '***...<last4>' (or 'EMPTY' if not set).
    This lets operators verify keys are loaded without exposing them.
    """
    settings = get_settings()
    return {
        "api_keys_masked": settings.mask_api_keys(),
        "provider_modes": {
            "ZAI_REAL": settings.zai_real,
            "GEMINI_REAL": settings.gemini_real,
            "TRIPO_REAL": settings.tripo_real,
        },
        "security": {
            "auth_enabled": settings.auth_enabled,
            "rate_limit_enabled": settings.rate_limit_enabled,
            "rate_limit_per_minute": settings.rate_limit_per_minute,
            "cors_origins": settings.cors_origins_list,
        },
        "validation_errors": settings.validate_api_keys(),
    }


@router.get("/version")
async def get_version() -> Dict[str, Any]:
    return {
        "name": "FOSTAS OS",
        "version": "1.1.0",
        "description": (
            "AI Operating System for Game Development. "
            "Orchestrates Z.AI, Gemini, and Tripo to build & maintain "
            "the FOSTAS: Toybox Terror Godot multiplayer FPS."
        ),
    }
