"""Log endpoints."""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter, Query

from backend.core import get_recent_events

router = APIRouter(prefix="/api/logs", tags=["logs"])


@router.get("")
async def get_logs(
    limit: int = Query(100, ge=1, le=1000),
    level: Optional[str] = None,
) -> Dict[str, Any]:
    events = get_recent_events(limit=limit, level=level)
    return {"events": events, "count": len(events)}
