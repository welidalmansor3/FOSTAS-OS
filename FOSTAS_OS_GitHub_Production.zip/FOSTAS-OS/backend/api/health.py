"""Health & system endpoints."""
from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter

from backend.core import get_godot_manager
from backend.providers import list_providers
from config.settings import get_settings

router = APIRouter(tags=["health"])


@router.get("/health")
async def health() -> Dict[str, Any]:
    """Health check + provider status + Godot CLI availability."""
    settings = get_settings()
    godot = get_godot_manager()
    return {
        "status": "ok",
        "version": "1.1.0",
        "godot_cli_available": godot.is_cli_available(),
        "godot_binary": settings.godot_binary,
        "providers": list_providers(),
        "auth_enabled": settings.auth_enabled,
        "rate_limit_enabled": settings.rate_limit_enabled,
    }
