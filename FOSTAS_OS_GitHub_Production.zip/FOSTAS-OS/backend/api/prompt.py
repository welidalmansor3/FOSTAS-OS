"""Prompt orchestration endpoints."""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from backend.core import get_orchestrator
from backend.core import info as log_info

router = APIRouter(prefix="/api", tags=["prompt"])


class PromptRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=8000)
    context: Optional[Dict[str, Any]] = None
    stream: bool = False  # Hint for WebSocket usage; HTTP always returns full report.


@router.post("/prompt")
async def submit_prompt(req: PromptRequest) -> Dict[str, Any]:
    """Process a natural-language prompt end-to-end via the orchestrator pipeline."""
    if not req.prompt.strip():
        raise HTTPException(status_code=400, detail="Prompt cannot be empty")

    log_info(f"API received prompt: {req.prompt[:200]}")
    orchestrator = get_orchestrator()
    report = await orchestrator.process_prompt(req.prompt)

    return report.model_dump(mode="json")
