"""Workspace (Godot project) endpoints."""
from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, HTTPException

from backend.core import get_godot_manager

router = APIRouter(prefix="/api/workspace", tags=["workspace"])


@router.get("/scan")
async def scan_workspace() -> Dict[str, Any]:
    """Scan the active Godot project and return a summary."""
    godot = get_godot_manager()
    try:
        scan = godot.scan()
        return {"success": True, "scan": scan.summary()}
    except FileNotFoundError as e:
        return {"success": False, "error": str(e)}


@router.get("/files")
async def list_files(subdir: str = "") -> Dict[str, Any]:
    godot = get_godot_manager()
    files = godot.list_files(subdir)
    return {"files": files, "count": len(files)}


@router.get("/file")
async def read_file(path: str) -> Dict[str, Any]:
    godot = get_godot_manager()
    try:
        content = godot.read_file(path)
        return {"path": path, "content": content, "size": len(content)}
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(status_code=404, detail=str(e))
