"""WebSocket streaming endpoint for real-time AI activity.

A client connects to `/ws/prompt` and sends a JSON message
`{"prompt": "...", "context": {...}}`. The server streams back JSON
events as the orchestrator pipeline progresses:

  {"type": "analysis",     "data": {...}}
  {"type": "knowledge",    "data": {"loaded": ["Weapons.md", ...]}}
  {"type": "scan",         "data": {...}}
  {"type": "plan",         "data": {...}}
  {"type": "task_started", "data": {"task_id": 1, "provider": "zai"}}
  {"type": "task_success", "data": {"task_id": 1, "result": {...}}}
  {"type": "task_failed",  "data": {"task_id": 1, "error": "..."}}
  {"type": "file_change",  "data": {"action": "create", "path": "..."}}
  {"type": "validation",   "data": {"ok": true, "msg": "..."}}
  {"type": "complete",     "data": {...}}   # full CompletionReport
  {"type": "error",        "data": {"message": "..."}}
"""
from __future__ import annotations

import asyncio
import json
from typing import Any, Dict

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from backend.core import get_orchestrator
from backend.core.events import EventBus, get_event_bus
from backend.models import CompletionReport

router = APIRouter(tags=["stream"])


@router.websocket("/ws/prompt")
async def ws_prompt(websocket: WebSocket) -> None:
    """Stream orchestrator events to a WebSocket client."""
    await websocket.accept()

    # Per-connection subscription to the global EventBus.
    bus: EventBus = get_event_bus()
    queue = bus.subscribe()

    try:
        # Read the first message as the prompt request.
        raw = await websocket.receive_text()
        try:
            payload: Dict[str, Any] = json.loads(raw)
        except json.JSONDecodeError:
            await websocket.send_json(
                {"type": "error", "data": {"message": "Invalid JSON"}}
            )
            return

        prompt_text = (payload.get("prompt") or "").strip()
        if not prompt_text:
            await websocket.send_json(
                {"type": "error", "data": {"message": "Empty prompt"}}
            )
            return

        # Run the orchestrator pipeline in the background; events emitted by
        # the orchestrator will appear in `queue`.
        orchestrator = get_orchestrator()

        async def run_pipeline() -> CompletionReport:
            return await orchestrator.process_prompt(prompt_text)

        pipeline_task = asyncio.create_task(run_pipeline())

        # Forward events to the WebSocket until the pipeline completes.
        try:
            while not pipeline_task.done():
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=0.2)
                except asyncio.TimeoutError:
                    continue
                await websocket.send_json(event)

            # Drain any remaining events.
            while not queue.empty():
                event = queue.get_nowait()
                await websocket.send_json(event)

            # Send the final CompletionReport.
            report = await pipeline_task
            await websocket.send_json(
                {"type": "complete", "data": report.model_dump(mode="json")}
            )
        except WebSocketDisconnect:
            pipeline_task.cancel()
            return
        except Exception as e:
            await websocket.send_json(
                {"type": "error", "data": {"message": str(e)}}
            )
            return
    finally:
        bus.unsubscribe(queue)
