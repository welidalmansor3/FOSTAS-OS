"""Upload manager endpoints."""
from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, File, UploadFile, HTTPException

from backend.core.upload_manager import get_upload_manager
from config.settings import get_settings

router = APIRouter(prefix="/api/uploads", tags=["uploads"])


@router.get("")
async def list_uploads() -> Dict[str, Any]:
    um = get_upload_manager()
    return {"files": um.list_uploads()}


@router.post("")
async def upload_file(file: UploadFile = File(...)) -> Dict[str, Any]:
    settings = get_settings()
    max_bytes = settings.max_upload_size_mb * 1024 * 1024

    um = get_upload_manager()
    # Stream-read with size enforcement so we reject oversized uploads early
    # instead of buffering the whole thing into RAM.
    contents = await file.read(max_bytes + 1)
    if len(contents) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=(
                f"Upload size {len(contents)} bytes exceeds max "
                f"{max_bytes} bytes ({settings.max_upload_size_mb} MB)"
            ),
        )

    result = um.save_upload(file.filename or "upload.bin", contents)
    return {
        "success": result.success,
        "filename": result.filename,
        "saved_path": str(result.saved_path) if result.saved_path else None,
        "category": result.category,
        "size_bytes": result.size_bytes,
        "unzipped": result.unzipped,
        "files_added": result.files_added,
        "error": result.error,
    }
