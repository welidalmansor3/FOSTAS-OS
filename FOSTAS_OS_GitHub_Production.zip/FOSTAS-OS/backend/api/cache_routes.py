"""Cache endpoints."""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter

from backend.core import get_cache

router = APIRouter(prefix="/api/cache", tags=["cache"])


@router.get("/stats")
async def cache_stats() -> Dict[str, Any]:
    cache = get_cache()
    return cache.stats()


@router.delete("")
async def clear_cache(namespace: Optional[str] = None) -> Dict[str, Any]:
    cache = get_cache()
    removed = cache.clear(namespace)
    return {"removed": removed, "namespace": namespace or "all"}
