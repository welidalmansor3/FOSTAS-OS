"""Download manager endpoints."""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter
from pydantic import BaseModel, HttpUrl

from backend.core.download_manager import get_download_manager

router = APIRouter(prefix="/api/downloads", tags=["downloads"])


class DownloadRequest(BaseModel):
    url: HttpUrl
    filename: Optional[str] = None
    expected_sha256: Optional[str] = None


@router.get("")
async def list_downloads() -> Dict[str, Any]:
    dm = get_download_manager()
    return {"files": dm.list_downloads()}


@router.post("")
async def submit_download(req: DownloadRequest) -> Dict[str, Any]:
    dm = get_download_manager()
    result = await dm.download(
        url=str(req.url),
        filename=req.filename,
        expected_sha256=req.expected_sha256,
    )
    return {
        "success": result.success,
        "path": str(result.path) if result.path else None,
        "bytes_downloaded": result.bytes_downloaded,
        "duration_seconds": result.duration_seconds,
        "checksum_verified": result.checksum_verified,
        "error": result.error,
    }
