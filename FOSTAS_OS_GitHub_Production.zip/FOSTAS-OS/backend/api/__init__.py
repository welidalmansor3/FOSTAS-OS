"""
FOSTAS OS — Modular API routers.

Each module exports an `APIRouter` that is mounted by `backend/main.py`.
This keeps route handlers small and grouped by domain (health, prompt,
workspace, knowledge, downloads, uploads, logs, cache, system, stream,
projects).
"""
from .cache_routes import router as cache_router
from .downloads import router as downloads_router
from .health import router as health_router
from .knowledge import router as knowledge_router
from .logs import router as logs_router
from .prompt import router as prompt_router
from .projects import router as projects_router
from .stream import router as stream_router
from .system import router as system_router
from .uploads import router as uploads_router
from .workspace import router as workspace_router

__all__ = [
    "cache_router",
    "downloads_router",
    "health_router",
    "knowledge_router",
    "logs_router",
    "prompt_router",
    "projects_router",
    "stream_router",
    "system_router",
    "uploads_router",
    "workspace_router",
]
