"""Knowledge base endpoints."""
from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.knowledge import get_knowledge_manager

router = APIRouter(prefix="/api/knowledge", tags=["knowledge"])


class KnowledgeUpdate(BaseModel):
    content: str


@router.get("")
async def list_knowledge() -> Dict[str, Any]:
    km = get_knowledge_manager()
    return {"docs": km.list_docs()}


@router.get("/search")
async def search_knowledge(q: str, top_k: int = 3) -> Dict[str, Any]:
    """Keyword-overlap retrieval over the knowledge base."""
    km = get_knowledge_manager()
    results = km.retrieve_relevant(q, top_k=max(1, min(top_k, 10)))
    return {
        "query": q,
        "results": [
            {"doc": name, "score": round(score, 4), "preview": content[:400]}
            for name, score, content in results
        ],
    }


@router.get("/{name}")
async def get_knowledge_doc(name: str) -> Dict[str, Any]:
    km = get_knowledge_manager()
    content = km.get_doc(name)
    if not content:
        raise HTTPException(status_code=404, detail=f"Doc not found: {name}")
    return {"name": name, "content": content, "size": len(content)}


@router.put("/{name}")
async def update_knowledge_doc(name: str, body: KnowledgeUpdate) -> Dict[str, Any]:
    km = get_knowledge_manager()
    path = km.write_doc(name, body.content)
    return {"name": name, "path": str(path), "size": len(body.content)}
