"""Multi-project workspace switcher.

A "project" is a Godot project directory under `workspace/projects/`.
The active project is the one that all godot/ operations apply to.
Switching projects:
  1. Validates the target directory contains a `project.godot` file.
  2. Atomically swaps the active project pointer (a symlink at `workspace/active`).
  3. Reinitializes the GodotManager singleton so subsequent calls use the new path.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.core import get_godot_manager
from backend.core.godot_manager import GodotManager
from config.settings import get_settings

router = APIRouter(prefix="/api/projects", tags=["projects"])


class ProjectSwitchRequest(BaseModel):
    name: str


class ProjectCreateRequest(BaseModel):
    name: str
    template: str = "empty"  # "empty" | "fps_template"


def _projects_root() -> Path:
    settings = get_settings()
    root = settings.workspace_dir / "projects"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _active_symlink() -> Path:
    return get_settings().workspace_dir / "active"


@router.get("")
async def list_projects() -> Dict[str, Any]:
    """List all known Godot projects under workspace/projects/."""
    root = _projects_root()
    active = _active_symlink()
    active_target = active.resolve() if active.exists() else None

    projects: List[Dict[str, Any]] = []
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        is_godot = (child / "project.godot").exists()
        projects.append(
            {
                "name": child.name,
                "path": str(child),
                "is_godot_project": is_godot,
                "is_active": active_target == child.resolve() if active_target else False,
            }
        )
    return {"projects": projects, "count": len(projects)}


@router.post("/switch")
async def switch_project(req: ProjectSwitchRequest) -> Dict[str, Any]:
    """Switch the active Godot project. Reinitializes the GodotManager."""
    target = _projects_root() / req.name
    if not target.exists() or not target.is_dir():
        raise HTTPException(
            status_code=404, detail=f"Project not found: {req.name}"
        )
    if not (target / "project.godot").exists():
        raise HTTPException(
            status_code=400,
            detail=f"Not a Godot project (missing project.godot): {req.name}",
        )

    settings = get_settings()
    # Set the override; the godot_project_dir property will return it on next read.
    settings.godot_project_override = target

    # Reset the GodotManager singleton so it picks up the new path.
    import backend.core as core
    core._godot_manager = None  # type: ignore[attr-defined]
    # Re-create to verify it loads cleanly.
    gm = get_godot_manager()
    _ = gm.scan()

    # Update the active symlink.
    active = _active_symlink()
    if active.exists() or active.is_symlink():
        active.unlink()
    active.symlink_to(target, target_is_directory=True)

    return {
        "success": True,
        "active_project": req.name,
        "path": str(target),
    }


@router.post("/create")
async def create_project(req: ProjectCreateRequest) -> Dict[str, Any]:
    """Create a new Godot project skeleton under workspace/projects/<name>."""
    target = _projects_root() / req.name
    if target.exists():
        raise HTTPException(
            status_code=409, detail=f"Project already exists: {req.name}"
        )
    target.mkdir(parents=True)

    # Minimal Godot 4.3 project.godot
    project_godot = target / "project.godot"
    project_godot.write_text(
        """
; Engine configuration file.
; It's best edited using the editor UI and not directly,
; since the parameters that go here are not all obvious.
config_version=5

[application]
config/name="{name}"
config/description="Created by FOSTAS OS"
run/main_scene="res://scenes/main.tscn"
config/features=4.3, GL Compatibility
config/icon="res://icon.svg"

[rendering]
renderer/rendering_method="gl_compatibility"
renderer/rendering_method.mobile="gl_compatibility"
""".strip().format(name=req.name)
    )

    (target / "scenes").mkdir()
    (target / "scripts").mkdir()
    (target / "assets").mkdir()
    (target / "icon.svg").write_text(
        '<svg height="128" width="128" xmlns="http://www.w3.org/2000/svg">'
        '<rect x="2" y="2" width="124" height="124" rx="16" fill="#478cbf"/>'
        '<polygon points="64,32 96,80 32,80" fill="#fff"/></svg>'
    )

    return {"success": True, "name": req.name, "path": str(target)}
