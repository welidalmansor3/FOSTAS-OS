"""
FOSTAS OS — Upload Manager

Handles user-uploaded files (3D models, textures, audio):
  - Drag & drop via Streamlit → multipart POST to /uploads
  - Supports ZIP, FBX, GLB, OBJ, PNG, JPG, WAV, MP3
  - 100 MB max file size
  - Auto-classification into godot/assets/<category>/
  - Retry / resume: client-side responsibility (idempotent endpoint)
"""
from __future__ import annotations

import os
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from backend.core import logger
from config.settings import get_settings


ALLOWED_EXTENSIONS = {
    ".zip", ".fbx", ".glb", ".gltf", ".obj",
    ".png", ".jpg", ".jpeg", ".webp", ".svg",
    ".wav", ".mp3", ".ogg",
}

# Asset classification map
EXT_TO_CATEGORY = {
    ".fbx": "models", ".glb": "models", ".gltf": "models", ".obj": "models",
    ".png": "textures", ".jpg": "textures", ".jpeg": "textures",
    ".webp": "textures", ".svg": "textures",
    ".wav": "audio", ".mp3": "audio", ".ogg": "audio",
}


@dataclass
class UploadResult:
    success: bool
    filename: str = ""
    saved_path: Optional[Path] = None
    category: str = ""
    size_bytes: int = 0
    unzipped: bool = False
    error: Optional[str] = None
    files_added: int = 1


class UploadManager:
    """Manage user-uploaded game assets."""

    def __init__(self) -> None:
        self.settings = get_settings()
        self.uploads_dir: Path = self.settings.uploads_dir
        self.godot_assets_dir: Path = self.settings.godot_project_dir / "assets"
        self.max_size_bytes = self.settings.max_upload_size_mb * 1024 * 1024
        self.uploads_dir.mkdir(parents=True, exist_ok=True)
        self.godot_assets_dir.mkdir(parents=True, exist_ok=True)

    def save_upload(
        self,
        filename: str,
        file_bytes: bytes,
        auto_classify: bool = True,
    ) -> UploadResult:
        """
        Save an uploaded file. If it's a ZIP, extract & classify each file.
        Returns UploadResult.
        """
        # Validate extension
        ext = Path(filename).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            return UploadResult(
                success=False,
                filename=filename,
                error=f"Extension {ext} not allowed. Allowed: {ALLOWED_EXTENSIONS}",
            )

        # Validate size
        size = len(file_bytes)
        if size > self.max_size_bytes:
            return UploadResult(
                success=False,
                filename=filename,
                error=f"File size {size} exceeds max {self.max_size_bytes} bytes",
            )

        # Save raw upload
        upload_path = self.uploads_dir / filename
        upload_path.write_bytes(file_bytes)
        logger.upload_event("received", filename, size_bytes=size)

        # Handle ZIP
        if ext == ".zip":
            return self._handle_zip(upload_path, file_bytes)

        # Classify & copy into godot/assets/
        category = EXT_TO_CATEGORY.get(ext, "misc")
        if auto_classify:
            target_dir = self.godot_assets_dir / category
            target_dir.mkdir(parents=True, exist_ok=True)
            target = target_dir / filename
            shutil.copy2(upload_path, target)
            logger.upload_event(
                "classified", filename, category=category, target=str(target)
            )
        else:
            target = upload_path

        return UploadResult(
            success=True,
            filename=filename,
            saved_path=target,
            category=category,
            size_bytes=size,
            files_added=1,
        )

    def _handle_zip(self, zip_path: Path, file_bytes: bytes) -> UploadResult:
        """Extract a ZIP and classify each file."""
        extracted: List[str] = []
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                for info in zf.infolist():
                    if info.is_dir():
                        continue
                    ext = Path(info.filename).suffix.lower()
                    if ext not in ALLOWED_EXTENSIONS:
                        logger.warning(f"Skipping disallowed file in ZIP: {info.filename}")
                        continue
                    # Extract to temp
                    extracted_bytes = zf.read(info)
                    if len(extracted_bytes) > self.max_size_bytes:
                        logger.warning(
                            f"Skipping oversize file in ZIP: {info.filename}"
                        )
                        continue
                    fname = Path(info.filename).name
                    category = EXT_TO_CATEGORY.get(ext, "misc")
                    target_dir = self.godot_assets_dir / category
                    target_dir.mkdir(parents=True, exist_ok=True)
                    target = target_dir / fname
                    target.write_bytes(extracted_bytes)
                    extracted.append(f"{category}/{fname}")
                    logger.upload_event(
                        "extracted", fname, category=category
                    )
        except zipfile.BadZipFile as e:
            return UploadResult(
                success=False, filename=zip_path.name, error=f"Bad ZIP: {e}"
            )

        return UploadResult(
            success=True,
            filename=zip_path.name,
            saved_path=zip_path,
            category="zip",
            size_bytes=len(file_bytes),
            unzipped=True,
            files_added=len(extracted),
        )

    def list_uploads(self) -> list[dict]:
        """List all uploaded files."""
        result = []
        for f in self.uploads_dir.iterdir():
            if f.is_file():
                stat = f.stat()
                result.append({
                    "filename": f.name,
                    "size_bytes": stat.st_size,
                    "size_mb": round(stat.st_size / 1024 / 1024, 2),
                    "modified": stat.st_mtime,
                })
        return sorted(result, key=lambda x: x["modified"], reverse=True)


# Singleton
_um: UploadManager | None = None


def get_upload_manager() -> UploadManager:
    global _um
    if _um is None:
        _um = UploadManager()
    return _um
