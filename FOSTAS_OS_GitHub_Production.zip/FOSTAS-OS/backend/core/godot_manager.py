"""
FOSTAS OS — Godot Project Manager

Responsibilities:
  1. Scan a Godot project (project.godot, scripts, scenes, assets)
  2. Generate GDScript (.gd) and scene (.tscn) files from templates / AI output
  3. Edit existing files safely (regex-based patching)
  4. Import assets into the correct folder structure
  5. Invoke `godot --headless` for import / validation / export
  6. ALWAYS create backups before modifying files (never corrupt the project)

The manager never modifies files outside the configured godot project dir.
"""
from __future__ import annotations

import asyncio
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.core import logger
from config.settings import get_settings


# ----------------------------------------------------------------
# Data models
# ----------------------------------------------------------------


@dataclass
class GodotProjectScan:
    """Result of scanning a Godot project."""

    project_path: Path
    project_godot: Dict[str, str]  # parsed project.godot key=value pairs
    scripts: List[Path] = field(default_factory=list)
    scenes: List[Path] = field(default_factory=list)
    textures: List[Path] = field(default_factory=list)
    materials: List[Path] = field(default_factory=list)
    models: List[Path] = field(default_factory=list)  # .glb, .gltf, .fbx, .obj
    sounds: List[Path] = field(default_factory=list)
    other: List[Path] = field(default_factory=list)
    total_files: int = 0
    total_size_bytes: int = 0
    godot_version: str = ""

    def summary(self) -> Dict[str, Any]:
        return {
            "project_path": str(self.project_path),
            "godot_version": self.godot_version,
            "total_files": self.total_files,
            "total_size_mb": round(self.total_size_bytes / 1024 / 1024, 2),
            "scripts": len(self.scripts),
            "scenes": len(self.scenes),
            "textures": len(self.textures),
            "materials": len(self.materials),
            "models": len(self.models),
            "sounds": len(self.sounds),
            "other": len(self.other),
        }


# ----------------------------------------------------------------
# Godot Manager
# ----------------------------------------------------------------


class GodotManager:
    """Manage a Godot project: scan, generate, edit, validate."""

    EXT_MAP = {
        ".gd": "scripts",
        ".tscn": "scenes",
        ".escn": "scenes",
        ".png": "textures",
        ".jpg": "textures",
        ".jpeg": "textures",
        ".webp": "textures",
        ".svg": "textures",
        ".tres": "materials",
        ".glb": "models",
        ".gltf": "models",
        ".fbx": "models",
        ".obj": "models",
        ".wav": "sounds",
        ".mp3": "sounds",
        ".ogg": "sounds",
    }

    def __init__(self) -> None:
        self.settings = get_settings()
        self.project_dir: Path = self.settings.godot_project_dir
        self._backups_dir = self.project_dir.parent / (
            self.project_dir.name + "_backups"
        )

    # ----------------------------------------------------------------
    # Project scanning
    # ----------------------------------------------------------------

    def scan(self) -> GodotProjectScan:
        """Scan the entire Godot project and build a memory of it."""
        if not self.project_dir.exists():
            raise FileNotFoundError(
                f"Godot project not found at {self.project_dir}"
            )

        project_godot = self._parse_project_godot()
        scan = GodotProjectScan(
            project_path=self.project_dir,
            project_godot=project_godot,
            godot_version=project_godot.get("config_version", "unknown"),
        )

        for root, dirs, files in os.walk(self.project_dir):
            # Skip hidden dirs and .godot import cache
            dirs[:] = [d for d in dirs if not d.startswith(".") and d != ".godot"]
            for fname in files:
                # Skip import cache files
                if fname.endswith(".import"):
                    continue
                fpath = Path(root) / fname
                if fpath.name == "project.godot":
                    continue
                ext = fpath.suffix.lower()
                bucket = self.EXT_MAP.get(ext, "other")
                getattr(scan, bucket).append(fpath)
                scan.total_files += 1
                try:
                    scan.total_size_bytes += fpath.stat().st_size
                except OSError:
                    pass

        logger.info(
            f"Godot scan complete: {scan.total_files} files, "
            f"{len(scan.scripts)} scripts, {len(scan.scenes)} scenes",
            **scan.summary(),
        )
        return scan

    def _parse_project_godot(self) -> Dict[str, str]:
        """Parse project.godot into a flat key=value dict (best-effort)."""
        path = self.project_dir / "project.godot"
        if not path.exists():
            return {}
        result: Dict[str, str] = {}
        current_section = ""
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith(";"):
                continue
            if line.startswith("[") and line.endswith("]"):
                current_section = line[1:-1]
                continue
            if "=" in line:
                k, v = line.split("=", 1)
                key = f"{current_section}.{k.strip()}" if current_section else k.strip()
                result[key] = v.strip().strip('"')
        return result

    # ----------------------------------------------------------------
    # File operations (always backup first)
    # ----------------------------------------------------------------

    def backup_file(self, file_path: Path) -> Optional[Path]:
        """Create a timestamped backup of a file. Returns backup path or None."""
        if not file_path.exists():
            return None
        self._backups_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        rel = file_path.relative_to(self.project_dir)
        backup_name = f"{rel.as_posix().replace('/', '__')}__{ts}"
        backup_path = self._backups_dir / backup_name
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file_path, backup_path)
        logger.file_change("backup", str(file_path), backup_path=str(backup_path))
        return backup_path

    def write_file(
        self, rel_path: str, content: str, backup: bool = True
    ) -> Tuple[Path, Optional[Path]]:
        """
        Write content to a file inside the Godot project.

        Args:
            rel_path: path relative to godot/ (e.g. "scripts/weapons/rifle.gd")
            content: file content
            backup: if True and file exists, create backup first

        Returns: (file_path, backup_path_or_None)
        """
        # SECURITY: never allow path traversal outside godot/
        target = (self.project_dir / rel_path).resolve()
        if not str(target).startswith(str(self.project_dir.resolve())):
            raise ValueError(f"Path traversal blocked: {rel_path}")

        target.parent.mkdir(parents=True, exist_ok=True)

        backup_path = None
        if backup and target.exists():
            backup_path = self.backup_file(target)

        target.write_text(content, encoding="utf-8")
        action = "edit" if backup_path else "create"
        logger.file_change(action, str(target), bytes_written=len(content))
        return target, backup_path

    def read_file(self, rel_path: str) -> str:
        """Read a file from the Godot project."""
        target = (self.project_dir / rel_path).resolve()
        if not str(target).startswith(str(self.project_dir.resolve())):
            raise ValueError(f"Path traversal blocked: {rel_path}")
        if not target.exists():
            raise FileNotFoundError(f"File not found: {rel_path}")
        return target.read_text(encoding="utf-8")

    def list_files(self, subdir: str = "") -> List[str]:
        """List all files (relative paths) in a subdir or entire project."""
        base = self.project_dir if not subdir else self.project_dir / subdir
        if not base.exists():
            return []
        result: List[str] = []
        for root, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d != ".godot"]
            for fname in files:
                if fname.endswith(".import"):
                    continue
                fp = Path(root) / fname
                result.append(str(fp.relative_to(self.project_dir)))
        return sorted(result)

    # ----------------------------------------------------------------
    # Code extraction (from AI responses)
    # ----------------------------------------------------------------

    @staticmethod
    def extract_code_blocks(text: str) -> List[Tuple[str, str]]:
        """
        Extract code blocks from an AI response.

        Returns: list of (language, code) tuples.
        Handles ```gdscript ... ``` and ```python ... ``` etc.
        """
        blocks: List[Tuple[str, str]] = []
        # Match ```lang\n...code...\n```
        pattern = re.compile(r"```(\w*)\n([\s\S]*?)```", re.MULTILINE)
        for m in pattern.finditer(text):
            lang = m.group(1).lower() or "text"
            code = m.group(2).rstrip()
            blocks.append((lang, code))
        return blocks

    @staticmethod
    def extract_file_paths(text: str) -> List[Tuple[str, str]]:
        """
        Extract explicit file path declarations from AI response.
        Looks for patterns like:
          # File: scripts/weapons/rifle.gd
          # Path: godot/scripts/foo.gd
          <!-- path: scenes/foo.tscn -->
        Returns: list of (rel_path, None) — content is the surrounding block.
        """
        results: List[Tuple[str, str]] = []
        # Look for path comments inside code blocks
        pattern = re.compile(
            r"```(?:\w*)\n(?:#|//|<!--)\s*(?:File|Path|file|path):\s*([^\n]+)\n([\s\S]*?)```",
            re.MULTILINE,
        )
        for m in pattern.finditer(text):
            path = m.group(1).strip()
            code = m.group(2).rstrip()
            # Strip leading "godot/" if present
            if path.startswith("godot/"):
                path = path[len("godot/") :]
            results.append((path, code))
        return results

    def apply_ai_response(self, ai_content: str) -> List[Tuple[str, str, Optional[Path]]]:
        """
        Apply an AI response to the Godot project.

        Strategy:
          1. Look for explicit "File: <path>" markers in code blocks
          2. If found, write each block to its declared path
          3. Otherwise, infer path from the language/first line (best effort)

        Pre-write validation gate:
          - .gd files are run through GDScriptValidator (structural checks).
          - All files are run through SecretScanner (refuse leaked API keys).
          - Files with ERROR-severity issues are SKIPPED and logged; the rest
            of the batch still applies. The orchestrator's completion report
            surfaces skipped files so the user knows.

        Returns: list of (action, rel_path, backup_path) tuples
        """
        from backend.validation import validate_gdscript, scan_for_secrets

        applied: List[Tuple[str, str, Optional[Path]]] = []

        def _safe_write(rel_path: str, code: str) -> Optional[Tuple[str, str, Optional[Path]]]:
            """Run validators, then write if clean. Returns None if skipped."""
            # Secret scan applies to ALL files.
            secret_issues = scan_for_secrets(code, rel_path)
            if secret_issues:
                logger.error(
                    f"PRE-WRITE BLOCKED (secrets) for {rel_path}: "
                    f"{len(secret_issues)} secret(s) detected — "
                    f"first: {secret_issues[0].pattern_name} at line {secret_issues[0].line}"
                )
                return None

            # GDScript structural check applies only to .gd files.
            if rel_path.endswith(".gd"):
                gd_issues = validate_gdscript(code, rel_path)
                errors = [i for i in gd_issues if i.severity == "error"]
                if errors:
                    logger.error(
                        f"PRE-WRITE BLOCKED (gdscript) for {rel_path}: "
                        f"{len(errors)} error(s) — first: {errors[0].message}"
                    )
                    return None
                # Warnings are logged but don't block.
                for w in [i for i in gd_issues if i.severity == "warning"]:
                    logger.warning(
                        f"PRE-WRITE WARN (gdscript) {rel_path}:{w.line} — {w.message}"
                    )

            _, backup = self.write_file(rel_path, code, backup=True)
            action = "edit" if backup else "create"
            return (action, rel_path, backup)

        # First try explicit file paths
        explicit = self.extract_file_paths(ai_content)
        if explicit:
            for rel_path, code in explicit:
                result = _safe_write(rel_path, code)
                if result is not None:
                    applied.append(result)
            return applied

        # Fall back to language inference from code blocks
        blocks = self.extract_code_blocks(ai_content)
        for i, (lang, code) in enumerate(blocks):
            rel_path = self._infer_path(lang, code, i)
            if not rel_path:
                continue
            result = _safe_write(rel_path, code)
            if result is not None:
                applied.append(result)
        return applied

    @staticmethod
    def _infer_path(lang: str, code: str, idx: int) -> Optional[str]:
        """Infer a file path from a code block when no explicit path is given."""
        # Look for class_name in GDScript
        m = re.search(r"class_name\s+(\w+)", code)
        if m:
            cls = m.group(1).lower()
            # Determine subfolder from extends
            ext_match = re.search(r"extends\s+([\w.]+)", code)
            if ext_match:
                extends = ext_match.group(1).lower()
                if "weapon" in code.lower() or "weapon" in extends:
                    return f"scripts/weapons/{cls}.gd"
                if "monster" in code.lower() or "enemy" in code.lower():
                    return f"scripts/monsters/{cls}.gd"
                if "player" in extends:
                    return f"scripts/player/{cls}.gd"
                if "magic" in code.lower() or "spell" in code.lower():
                    return f"scripts/magic/{cls}.gd"
                if "network" in code.lower():
                    return f"scripts/network/{cls}.gd"
            return f"scripts/{cls}.gd"

        # Fallback by language
        if lang in ("gdscript", "gd"):
            return f"scripts/generated_{idx + 1}.gd"
        if lang in ("python", "py"):
            return f"scripts/generated_{idx + 1}.py"
        if lang in ("tscn", "godot"):
            return f"scenes/generated_{idx + 1}.tscn"
        return None

    # ----------------------------------------------------------------
    # Godot CLI invocation
    # ----------------------------------------------------------------

    def is_cli_available(self) -> bool:
        """Check if Godot binary is available on the system."""
        return self.settings.godot_binary is not None

    async def invoke_cli(
        self, args: List[str], timeout: int = 60
    ) -> Tuple[int, str, str]:
        """
        Invoke `godot --headless <args>` on the project.

        Returns: (exit_code, stdout, stderr)
        """
        binary = self.settings.godot_binary
        if not binary:
            msg = "Godot binary not available — install Godot 4.x or set GODOT_BIN"
            logger.warning(msg)
            return -1, "", msg

        cmd = [binary, "--headless", "--path", str(self.project_dir)] + args
        logger.info(f"Invoking Godot CLI: {' '.join(cmd)}")

        def _run():
            return subprocess.run(
                cmd, capture_output=True, text=True, timeout=timeout
            )

        try:
            proc = await asyncio.to_thread(_run)
            logger.info(
                f"Godot CLI exit {proc.returncode}",
                exit_code=proc.returncode,
                stdout_tail=proc.stdout[-300:],
                stderr_tail=proc.stderr[-300:],
            )
            return proc.returncode, proc.stdout, proc.stderr
        except subprocess.TimeoutExpired:
            return -1, "", f"Godot CLI timed out after {timeout}s"
        except FileNotFoundError:
            return -1, "", f"Godot binary not found: {binary}"

    async def import_assets(self) -> Tuple[int, str, str]:
        """Run godot --import to refresh the asset import cache."""
        return await self.invoke_cli(["--import"], timeout=120)

    async def validate_project(self) -> Tuple[bool, str]:
        """
        Validate the project by running godot --check-only on every script.
        Returns (ok, message).
        """
        scan = self.scan()
        if not scan.scripts:
            return True, "No scripts to validate"
        # Godot 4 supports --check-only to parse scripts without running
        ok = True
        msgs: List[str] = []
        for script in scan.scripts:
            rel = script.relative_to(self.project_dir).as_posix()
            code, out, err = await self.invoke_cli(
                ["--check-only", "--script", rel], timeout=30
            )
            if code != 0:
                ok = False
                msgs.append(f"{rel}: {err.strip()[:200]}")
        return ok, "\n".join(msgs) if msgs else "All scripts OK"

    async def export_project(
        self, preset: str = "Windows Desktop"
    ) -> Tuple[int, str, str]:
        """Export the project using a preset defined in export_presets.cfg."""
        return await self.invoke_cli(
            ["--export-release", preset], timeout=600
        )


# Singleton
_gm: GodotManager | None = None


def get_godot_manager() -> GodotManager:
    global _gm
    if _gm is None:
        _gm = GodotManager()
    return _gm
