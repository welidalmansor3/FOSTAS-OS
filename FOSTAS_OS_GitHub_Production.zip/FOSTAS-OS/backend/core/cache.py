"""
FOSTAS OS — Cache Manager

Two-tier cache:
  - L1: in-memory LRU (process-local, hits are <1 µs)
  - L2: file-based with TTL (survives restarts, shareable across processes)

Caches:
  - AI responses (key = hash of provider+model+prompt+system)
  - Generated assets (file-based)
  - Project analysis snapshots

On `get`: check L1 first; on miss, check L2; on hit, promote to L1.
On `set`: write to both L1 and L2.
On `clear`: wipe both.
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, Optional

from config.settings import get_settings


class _LRUCache:
    """Thread-safe in-memory LRU cache with size cap."""

    def __init__(self, max_entries: int = 512) -> None:
        self._max = max_entries
        self._data: "OrderedDict[str, Any]" = OrderedDict()
        self._lock = threading.Lock()
        # Stats counters (best-effort; not strictly atomic).
        self.hits = 0
        self.misses = 0

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            if key in self._data:
                self._data.move_to_end(key)
                self.hits += 1
                return self._data[key]
            self.misses += 1
            return None

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            if key in self._data:
                self._data.move_to_end(key)
            self._data[key] = value
            while len(self._data) > self._max:
                self._data.popitem(last=False)

    def clear(self) -> int:
        with self._lock:
            n = len(self._data)
            self._data.clear()
            return n

    def stats(self) -> Dict[str, int]:
        with self._lock:
            return {
                "l1_entries": len(self._data),
                "l1_max": self._max,
                "l1_hits": self.hits,
                "l1_misses": self.misses,
            }


class CacheManager:
    """Two-tier (L1 LRU + L2 file) cache with TTL."""

    def __init__(self) -> None:
        self.settings = get_settings()
        self.cache_dir: Path = self.settings.cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl_seconds = self.settings.cache_ttl_hours * 3600
        self._lru = _LRUCache(max_entries=self.settings.cache_lru_max_entries)

    @staticmethod
    def _hash_key(key: str) -> str:
        return hashlib.sha256(key.encode("utf-8")).hexdigest()

    def _l1_key(self, namespace: str, key: str) -> str:
        return f"{namespace}:{self._hash_key(key)}"

    def get(self, namespace: str, key: str) -> Optional[Any]:
        """Get a cached value. Returns None if miss or expired."""
        # L1
        l1_key = self._l1_key(namespace, key)
        l1_val = self._lru.get(l1_key)
        if l1_val is not None:
            return l1_val
        # L2
        ns_dir = self.cache_dir / namespace
        path = ns_dir / f"{self._hash_key(key)}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if time.time() - data.get("ts", 0) > self.ttl_seconds:
                return None  # expired
            value = data.get("value")
            # Promote to L1.
            self._lru.set(l1_key, value)
            return value
        except (json.JSONDecodeError, OSError):
            return None

    def set(self, namespace: str, key: str, value: Any) -> None:
        """Set a cached value (writes to both L1 and L2)."""
        # L1
        self._lru.set(self._l1_key(namespace, key), value)
        # L2
        ns_dir = self.cache_dir / namespace
        ns_dir.mkdir(parents=True, exist_ok=True)
        path = ns_dir / f"{self._hash_key(key)}.json"
        data = {"ts": time.time(), "key": key, "value": value}
        path.write_text(json.dumps(data, default=str, ensure_ascii=False), encoding="utf-8")

    def get_ai_response(
        self, provider: str, model: str, prompt: str, system: Optional[str] = None
    ) -> Optional[str]:
        """Get a cached AI response."""
        key = f"{provider}|{model}|{system or ''}|{prompt}"
        return self.get("ai_responses", key)

    def set_ai_response(
        self,
        provider: str,
        model: str,
        prompt: str,
        response: str,
        system: Optional[str] = None,
    ) -> None:
        """Cache an AI response.

        SECURITY: Before caching, scan the response for secret patterns.
        If any secret is detected, REFUSE to cache it and log a warning.
        This prevents a leaked API key (e.g. if a provider accidentally
        echoes the system prompt back) from being persisted to disk.
        """
        # Defense-in-depth: never cache content that looks like it contains secrets.
        from backend.validation import scan_for_secrets
        secret_issues = scan_for_secrets(response, f"<ai_response:{provider}>")
        if secret_issues:
            import logging
            logging.getLogger("fostas").warning(
                f"SECURITY: Refusing to cache AI response from {provider} — "
                f"{len(secret_issues)} secret pattern(s) detected. "
                f"First match: {secret_issues[0].pattern_name}. "
                "Response will not be persisted to cache."
            )
            return  # Do NOT cache

        key = f"{provider}|{model}|{system or ''}|{prompt}"
        self.set("ai_responses", key, response)

    def clear(self, namespace: Optional[str] = None) -> int:
        """Clear a namespace (or all). Returns number of entries removed."""
        import shutil

        # L1: clear all (granular per-namespace eviction from L1 is overkill).
        self._lru.clear()

        # L2
        if namespace:
            ns_dir = self.cache_dir / namespace
            if ns_dir.exists():
                count = len(list(ns_dir.glob("*.json")))
                shutil.rmtree(ns_dir)
                return count
            return 0
        # Clear all L2
        count = 0
        for d in self.cache_dir.iterdir():
            if d.is_dir():
                count += len(list(d.glob("*.json")))
                shutil.rmtree(d)
        return count

    def stats(self) -> Dict[str, Any]:
        """Return combined L1 + L2 cache statistics."""
        l2_entries = 0
        l2_namespaces = 0
        for d in self.cache_dir.iterdir():
            if d.is_dir():
                l2_namespaces += 1
                l2_entries += len(list(d.glob("*.json")))
        return {
            "l1": self._lru.stats(),
            "l2_total_entries": l2_entries,
            "l2_namespaces": l2_namespaces,
        }


# Singleton
_cache: CacheManager | None = None


def get_cache() -> CacheManager:
    global _cache
    if _cache is None:
        _cache = CacheManager()
    return _cache
