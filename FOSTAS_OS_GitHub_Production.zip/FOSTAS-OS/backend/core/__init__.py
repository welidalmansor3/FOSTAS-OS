"""FOSTAS OS — Core subsystems (orchestrator, godot manager, etc.)."""
# Logger is safe to import eagerly (no internal deps that cause cycles)
from .logger import (
    ai_request,
    ai_response,
    debug,
    download_event,
    error,
    file_change,
    get_recent_events,
    info,
    project_change,
    upload_event,
    warning,
)

# Cache is also safe (only depends on settings)
from .cache import CacheManager, get_cache


# Lazy-loaded singletons to avoid circular imports
_orchestrator = None
_prompt_analyzer = None
_godot_manager = None


def get_orchestrator():
    """Lazily create the orchestrator singleton."""
    global _orchestrator
    if _orchestrator is None:
        from .orchestrator import Orchestrator
        _orchestrator = Orchestrator()
    return _orchestrator


def get_prompt_analyzer():
    global _prompt_analyzer
    if _prompt_analyzer is None:
        from .prompt_analyzer import PromptAnalyzer
        _prompt_analyzer = PromptAnalyzer()
    return _prompt_analyzer


def get_godot_manager():
    global _godot_manager
    if _godot_manager is None:
        from .godot_manager import GodotManager
        _godot_manager = GodotManager()
    return _godot_manager


__all__ = [
    "Orchestrator",
    "get_orchestrator",
    "PromptAnalyzer",
    "get_prompt_analyzer",
    "GodotManager",
    "get_godot_manager",
    "CacheManager",
    "get_cache",
    "ai_request",
    "ai_response",
    "debug",
    "download_event",
    "error",
    "file_change",
    "get_recent_events",
    "info",
    "project_change",
    "upload_event",
    "warning",
]
