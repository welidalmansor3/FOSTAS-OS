"""
FOSTAS OS — In-memory event bus for orchestrator → WebSocket streaming.

The orchestrator emits events as it progresses through the pipeline; the
WebSocket endpoint subscribes a per-connection asyncio.Queue and forwards
events to the client in real time.

This is intentionally an in-process pub/sub (no Redis / no multi-worker
fan-out). For multi-worker deployments, swap this for a Redis pub/sub or
NATS-backed implementation — the EventBus API stays the same.
"""
from __future__ import annotations

import asyncio
from typing import Any, Dict, List

# Single process-wide bus. Created lazily.
_bus: "EventBus | None" = None


class EventBus:
    """In-memory async pub/sub for orchestration events."""

    def __init__(self) -> None:
        self._subscribers: List[asyncio.Queue] = []

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=1024)
        self._subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        if q in self._subscribers:
            self._subscribers.remove(q)

    def publish(self, event: Dict[str, Any]) -> None:
        """Publish an event to all subscribers. Non-blocking; drops on overflow."""
        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                # Drop oldest to make room — subscribers shouldn't block the bus.
                try:
                    q.get_nowait()
                    q.put_nowait(event)
                except Exception:
                    pass


def get_event_bus() -> EventBus:
    global _bus
    if _bus is None:
        _bus = EventBus()
    return _bus


def emit(event_type: str, data: Dict[str, Any]) -> None:
    """Convenience helper to publish a typed event."""
    get_event_bus().publish({"type": event_type, "data": data})
