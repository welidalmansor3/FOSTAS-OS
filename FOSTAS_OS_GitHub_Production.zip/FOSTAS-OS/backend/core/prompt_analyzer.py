"""
FOSTAS OS — Prompt Analyzer

Every user prompt first passes through this module. It calls Gemini
to determine:
  - Intent (add_weapon, create_monster, fix_bug, scan_project, ...)
  - Complexity (low / medium / high / critical)
  - Risk (none / low / medium / high)
  - Required AI providers
  - Required files to create/modify
  - Required 3D assets
  - Knowledge docs to load
  - Subtasks (if the prompt is complex enough to split)

Falls back to a rule-based heuristic if Gemini is unavailable.

Output: PromptAnalysis (pydantic model) consumed by the orchestrator.
"""
from __future__ import annotations

import json
import re
from typing import Optional

from backend.core import logger
from backend.models import Complexity, Intent, PromptAnalysis, Risk
from backend.providers import get_gemini


SYSTEM_PROMPT = """You are FOSTAS OS Prompt Analyzer. Your job is to analyze a user's natural-language request about a Godot game project and return a structured JSON analysis.

Return ONLY a JSON object with this exact schema (no markdown, no commentary):
{
  "intent": "add_weapon|add_map|add_vehicle|add_potion|add_magic|create_monster|create_character|fix_bug|optimize|scan_project|documentation|refactor|other",
  "summary": "<one-sentence summary of what the user wants>",
  "complexity": "low|medium|high|critical",
  "risk": "none|low|medium|high",
  "required_providers": ["zai", "gemini", "tripo"],
  "required_files": ["godot/scripts/weapons/weapon.gd", ...],
  "required_assets": ["3D model URL or description", ...],
  "knowledge_docs": ["Weapons.md", "GameBible.md", ...],
  "subtasks": ["step 1", "step 2", ...]
}

Rules:
- "scan_project" intent requires no providers and no file writes.
- "add_weapon" requires Z.AI (code) + Weapons.md knowledge.
- "create_monster" requires Z.AI (code) + Tripo (3D model) + Monster.md knowledge.
- "fix_bug" requires Gemini (analysis) + Z.AI (patch) + Networking.md/Optimization.md.
- "add_magic" requires Z.AI + Magic.md.
- File paths must start with "godot/" and end with ".gd" or ".tscn" or ".tres".
- Only include providers that are actually needed.
- Be precise. No placeholders.
"""


class PromptAnalyzer:
    """Analyzes user prompts using Gemini (with rule-based fallback)."""

    def __init__(self) -> None:
        self.gemini = get_gemini()

    async def analyze(self, prompt: str) -> PromptAnalysis:
        """Analyze a user prompt and return a structured PromptAnalysis."""
        logger.info(f"Analyzing prompt: {prompt[:200]}", prompt_length=len(prompt))

        # Try Gemini first
        if self.gemini.real_mode:
            try:
                resp = await self.gemini.safe_chat(
                    prompt=prompt,
                    system=SYSTEM_PROMPT,
                    temperature=0.2,
                    max_tokens=800,
                )
                if resp.success and resp.content:
                    analysis = self._parse_gemini_response(resp.content, prompt)
                    if analysis:
                        logger.info(
                            f"Gemini analysis: intent={analysis.intent}, "
                            f"complexity={analysis.complexity}"
                        )
                        return analysis
                logger.warning(
                    f"Gemini analysis failed: {resp.error}; falling back to rules"
                )
            except Exception as e:
                logger.warning(f"Gemini analysis exception: {e}; using rule-based")

        # Rule-based fallback
        return self._rule_based_analyze(prompt)

    def _parse_gemini_response(
        self, content: str, original_prompt: str
    ) -> Optional[PromptAnalysis]:
        """Parse Gemini's JSON response. Tolerant of markdown code fences."""
        # Strip markdown code fences if present
        text = content.strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            # Try to extract the first {...} block
            m = re.search(r"\{[\s\S]*\}", text)
            if not m:
                return None
            try:
                data = json.loads(m.group(0))
            except json.JSONDecodeError:
                return None

        # Map intent string to enum (default to OTHER)
        intent_str = data.get("intent", "other").lower()
        try:
            intent = Intent(intent_str)
        except ValueError:
            intent = Intent.OTHER

        try:
            complexity = Complexity(data.get("complexity", "medium").lower())
        except ValueError:
            complexity = Complexity.MEDIUM

        try:
            risk = Risk(data.get("risk", "low").lower())
        except ValueError:
            risk = Risk.LOW

        return PromptAnalysis(
            intent=intent,
            summary=data.get("summary", ""),
            complexity=complexity,
            risk=risk,
            required_providers=data.get("required_providers", ["zai"]),
            required_files=data.get("required_files", []),
            required_assets=data.get("required_assets", []),
            knowledge_docs=data.get("knowledge_docs", []),
            subtasks=data.get("subtasks", []),
            raw_response=content,
        )

    def _rule_based_analyze(self, prompt: str) -> PromptAnalysis:
        """Deterministic rule-based fallback when Gemini is unavailable."""
        p = prompt.lower()

        # Intent detection
        if "scan" in p and "project" in p:
            intent = Intent.SCAN_PROJECT
            providers: list[str] = []
            files: list[str] = []
            knowledge: list[str] = []
            complexity = Complexity.LOW
            risk = Risk.NONE
        elif ("add" in p or "create" in p or "new" in p) and "weapon" in p:
            intent = Intent.ADD_WEAPON
            providers = ["zai"]
            files = [
                "godot/scripts/weapons/new_weapon.gd",
                "godot/scenes/new_weapon.tscn",
            ]
            knowledge = ["Weapons.md", "GameBible.md"]
            complexity = Complexity.MEDIUM
            risk = Risk.LOW
        elif ("create" in p or "add" in p or "new" in p) and (
            "monster" in p or "enemy" in p
        ):
            intent = Intent.CREATE_MONSTER
            providers = ["zai", "tripo"]
            files = [
                "godot/scripts/monsters/new_monster.gd",
                "godot/scenes/new_monster.tscn",
            ]
            knowledge = ["Monster.md", "GameBible.md"]
            complexity = Complexity.MEDIUM
            risk = Risk.LOW
        elif "fix" in p and ("lag" in p or "network" in p or "multiplayer" in p):
            intent = Intent.FIX_BUG
            providers = ["gemini", "zai"]
            files = ["godot/scripts/network/player_network.gd"]
            knowledge = ["Networking.md", "Optimization.md"]
            complexity = Complexity.HIGH
            risk = Risk.MEDIUM
        elif ("add" in p or "create" in p) and ("magic" in p or "spell" in p):
            intent = Intent.ADD_MAGIC
            providers = ["zai"]
            files = ["godot/scripts/magic/spell.gd"]
            knowledge = ["Magic.md", "GameBible.md"]
            complexity = Complexity.HIGH
            risk = Risk.MEDIUM
        elif ("add" in p or "create" in p) and "potion" in p:
            intent = Intent.ADD_POTION
            providers = ["zai", "tripo"]
            files = ["godot/scripts/items/potion.gd"]
            knowledge = ["Potions.md", "GameBible.md"]
            complexity = Complexity.MEDIUM
            risk = Risk.LOW
        elif ("add" in p or "create" in p) and "map" in p:
            intent = Intent.ADD_MAP
            providers = ["zai", "tripo"]
            files = ["godot/scenes/new_map.tscn"]
            knowledge = ["Maps.md", "GameBible.md"]
            complexity = Complexity.HIGH
            risk = Risk.MEDIUM
        elif ("add" in p or "create" in p) and "vehicle" in p:
            intent = Intent.ADD_VEHICLE
            providers = ["zai", "tripo"]
            files = ["godot/scripts/vehicles/vehicle.gd"]
            knowledge = ["Vehicles.md", "GameBible.md"]
            complexity = Complexity.HIGH
            risk = Risk.MEDIUM
        elif "optimize" in p or "performance" in p:
            intent = Intent.OPTIMIZE
            providers = ["gemini", "zai"]
            files = []
            knowledge = ["Optimization.md", "Networking.md"]
            complexity = Complexity.HIGH
            risk = Risk.MEDIUM
        else:
            intent = Intent.OTHER
            providers = ["zai"]
            files = []
            knowledge = ["GameBible.md"]
            complexity = Complexity.MEDIUM
            risk = Risk.LOW

        return PromptAnalysis(
            intent=intent,
            summary=f"Rule-based analysis: {prompt[:120]}",
            complexity=complexity,
            risk=risk,
            required_providers=providers,
            required_files=files,
            required_assets=[],
            knowledge_docs=knowledge,
            subtasks=[],
            raw_response=None,
        )


# Singleton
_analyzer: PromptAnalyzer | None = None


def get_prompt_analyzer() -> PromptAnalyzer:
    global _analyzer
    if _analyzer is None:
        _analyzer = PromptAnalyzer()
    return _analyzer
