"""
FOSTAS OS — Structured Logger

Logs every AI request, AI response, download, upload, error,
file change, and project change to:
  - logs/fostas.log         (human-readable, rotating)
  - logs/events.jsonl       (machine-readable JSON lines, append-only)

Thread-safe. Async-safe. Used by every subsystem.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import threading
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Dict, Optional

from config.settings import get_settings


_LOCK = threading.Lock()
_INITIALIZED = False
_EVENT_LOGGER: Optional[logging.Logger] = None


def _init() -> logging.Logger:
    """Initialize logger (called once)."""
    global _INITIALIZED, _EVENT_LOGGER
    if _INITIALIZED:
        return _EVENT_LOGGER  # type: ignore

    settings = get_settings()
    logs_dir = settings.logs_dir
    logs_dir.mkdir(parents=True, exist_ok=True)

    log_file = logs_dir / "fostas.log"
    event_file = logs_dir / "events.jsonl"

    # ---- Human-readable rotating log ----
    handler = RotatingFileHandler(
        log_file,
        maxBytes=settings.max_log_file_size_mb * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s [%(levelname)-7s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )

    # Also echo to stdout for `run.py` console visibility
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s [%(levelname)-7s] %(message)s",
            datefmt="%H:%M:%S",
        )
    )

    logger = logging.getLogger("fostas")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    logger.addHandler(handler)
    logger.addHandler(stdout_handler)
    logger.propagate = False

    # ---- JSON-lines event log (separate logger so it doesn't double-format) ----
    json_handler = RotatingFileHandler(
        event_file,
        maxBytes=settings.max_log_file_size_mb * 1024 * 1024,
        backupCount=10,
        encoding="utf-8",
    )
    json_handler.setFormatter(logging.Formatter("%(message)s"))

    _EVENT_LOGGER = logging.getLogger("fostas.events")
    _EVENT_LOGGER.setLevel(logging.INFO)
    _EVENT_LOGGER.handlers.clear()
    _EVENT_LOGGER.addHandler(json_handler)
    _EVENT_LOGGER.propagate = False

    _INITIALIZED = True
    return _EVENT_LOGGER


def _emit(level: str, event_type: str, payload: Dict[str, Any]) -> None:
    """Emit a structured event to both logs."""
    event_logger = _init()
    ts = datetime.now(timezone.utc).isoformat()
    record = {
        "ts": ts,
        "level": level,
        "event": event_type,
        **payload,
    }
    msg = json.dumps(record, default=str, ensure_ascii=False)
    event_logger.info(msg)

    # Also mirror to human-readable log
    main = logging.getLogger("fostas")
    main_level = getattr(logging, level, logging.INFO)
    main.log(main_level, f"[{event_type}] {msg}")


# ---- Public API ----

def ai_request(provider: str, model: str, prompt_summary: str, **extra: Any) -> None:
    """Log an outgoing AI request."""
    _emit(
        "INFO",
        "ai_request",
        {
            "provider": provider,
            "model": model,
            "prompt_summary": prompt_summary[:500],
            **extra,
        },
    )


def ai_response(
    provider: str,
    model: str,
    response_summary: str,
    duration_ms: int,
    success: bool = True,
    error: Optional[str] = None,
    **extra: Any,
) -> None:
    """Log an incoming AI response."""
    _emit(
        "INFO" if success else "ERROR",
        "ai_response",
        {
            "provider": provider,
            "model": model,
            "response_summary": response_summary[:500],
            "duration_ms": duration_ms,
            "success": success,
            "error": error,
            **extra,
        },
    )


def file_change(action: str, path: str, **extra: Any) -> None:
    """Log a file modification (create/edit/delete)."""
    _emit(
        "INFO",
        "file_change",
        {"action": action, "path": path, **extra},
    )


def project_change(action: str, description: str, **extra: Any) -> None:
    """Log a higher-level project change."""
    _emit(
        "INFO",
        "project_change",
        {"action": action, "description": description, **extra},
    )


def download_event(action: str, url: str, **extra: Any) -> None:
    """Log a download-manager event."""
    _emit(
        "INFO",
        "download",
        {"action": action, "url": url, **extra},
    )


def upload_event(action: str, filename: str, **extra: Any) -> None:
    """Log an upload-manager event."""
    _emit(
        "INFO",
        "upload",
        {"action": action, "filename": filename, **extra},
    )


def error(message: str, **extra: Any) -> None:
    """Log an error."""
    _emit("ERROR", "error", {"message": message, **extra})


def warning(message: str, **extra: Any) -> None:
    """Log a warning."""
    _emit("WARNING", "warning", {"message": message, **extra})


def info(message: str, **extra: Any) -> None:
    """Log an informational message."""
    _emit("INFO", "info", {"message": message, **extra})


def debug(message: str, **extra: Any) -> None:
    """Log a debug message."""
    _emit("DEBUG", "debug", {"message": message, **extra})


def get_recent_events(limit: int = 100, level: Optional[str] = None) -> list[dict]:
    """Read recent events from the JSONL log. Used by /logs API."""
    settings = get_settings()
    event_file = settings.logs_dir / "events.jsonl"
    if not event_file.exists():
        return []
    events: list[dict] = []
    # Read last `limit * 5` lines to be safe (filter reduces)
    with open(event_file, "r", encoding="utf-8") as f:
        lines = f.readlines()[-(limit * 5) :]
    for line in reversed(lines):
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
            if level and ev.get("level") != level:
                continue
            events.append(ev)
            if len(events) >= limit:
                break
        except json.JSONDecodeError:
            continue
    return events
