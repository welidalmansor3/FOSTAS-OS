"""
FOSTAS OS — Plugin system for AI providers.

A plugin is any Python module that exposes a `register(registry)` function.
The registry is a dict of provider-name -> provider-constructor. Built-in
providers (Z.AI, Gemini, Tripo) are registered at startup; external plugins
can be loaded by adding their module path to the `FOSTAS_PLUGINS` env var
(comma-separated).

Example plugin:

    # my_plugin.py
    from backend.providers.base import BaseProvider, AIResponse

    class MyProvider(BaseProvider):
        async def chat(self, prompt: str, system: str = "", **kw) -> AIResponse:
            ...

    def register(registry):
        registry["my_provider"] = MyProvider

Usage:
    FOSTAS_PLUGINS=my_plugin,other_plugin python run.py
"""
from __future__ import annotations

import importlib
import os
from typing import Any, Callable, Dict, List, Type

# Registry: provider-name -> factory callable that returns a provider instance.
_REGISTRY: Dict[str, Callable[..., Any]] = {}
# Metadata about loaded plugins.
_LOADED: List[Dict[str, Any]] = []


def register_provider(name: str, factory: Callable[..., Any]) -> None:
    """Register a provider factory. Overwrites existing entries with the same name."""
    _REGISTRY[name] = factory


def list_plugins() -> List[Dict[str, Any]]:
    """Return metadata about all loaded plugins."""
    return list(_LOADED)


def list_registered_providers() -> List[str]:
    """Return the names of all registered providers."""
    return sorted(_REGISTRY.keys())


def get_provider_factory(name: str) -> Callable[..., Any]:
    """Return the factory for a registered provider. Raises KeyError if not found."""
    if name not in _REGISTRY:
        raise KeyError(
            f"Provider '{name}' is not registered. Available: {list_registered_providers()}"
        )
    return _REGISTRY[name]


def load_plugins_from_env() -> None:
    """Load plugins listed in the FOSTAS_PLUGINS env var (comma-separated module paths)."""
    plugins_env = os.environ.get("FOSTAS_PLUGINS", "").strip()
    if not plugins_env:
        return
    for module_path in plugins_env.split(","):
        module_path = module_path.strip()
        if not module_path:
            continue
        try:
            mod = importlib.import_module(module_path)
            if hasattr(mod, "register"):
                mod.register(register_provider)
                _LOADED.append(
                    {
                        "module": module_path,
                        "status": "loaded",
                        "providers_registered": [
                            n for n in _REGISTRY.keys()
                            if _REGISTRY[n].__module__ == module_path
                        ],
                    }
                )
            else:
                _LOADED.append(
                    {
                        "module": module_path,
                        "status": "no_register_function",
                        "providers_registered": [],
                    }
                )
        except Exception as e:
            _LOADED.append(
                {
                    "module": module_path,
                    "status": f"error: {e}",
                    "providers_registered": [],
                }
            )


# Register built-in providers at import time.
def _register_builtins() -> None:
    """Register the built-in Z.AI, Gemini, and Tripo providers as factories."""
    from backend.providers.gemini_provider import GeminiProvider
    from backend.providers.tripo_provider import TripoProvider
    from backend.providers.zai_provider import ZAIProvider

    def make_zai(**kw): return ZAIProvider(**kw)
    def make_gemini(**kw): return GeminiProvider(**kw)
    def make_tripo(**kw): return TripoProvider(**kw)

    register_provider("zai", make_zai)
    register_provider("gemini", make_gemini)
    register_provider("tripo", make_tripo)
    _LOADED.append(
        {
            "module": "backend.providers (built-in)",
            "status": "loaded",
            "providers_registered": ["zai", "gemini", "tripo"],
        }
    )


_register_builtins()
