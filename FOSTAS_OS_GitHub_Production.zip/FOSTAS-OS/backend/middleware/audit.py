"""Audit middleware — logs every API request with method, path, status, duration.

Writes structured audit entries to the JSONL log so they can be queried
alongside AI request/response logs. The audit log is the foundation of
the security posture: every state-changing request is traceable.
"""
from __future__ import annotations

import time
from typing import Any, Dict

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from backend.core import logger

# Paths that don't need audit logging (high-frequency read-only checks).
_SKIP_PATHS = {"/health"}


class AuditMiddleware(BaseHTTPMiddleware):
    """Log every API request as a structured audit entry."""

    async def dispatch(self, request: Request, call_next):
        if request.url.path in _SKIP_PATHS:
            return await call_next(request)

        start = time.time()
        response = await call_next(request)
        duration_ms = int((time.time() - start) * 1000)

        # Build audit entry.
        audit_entry: Dict[str, Any] = {
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "duration_ms": duration_ms,
            "client_ip": request.client.host if request.client else "unknown",
            "user_agent": request.headers.get("user-agent", "")[:200],
        }
        # Use the structured logger so it lands in both fostas.log and events.jsonl.
        logger.info(
            f"AUDIT {audit_entry['method']} {audit_entry['path']} "
            f"-> {audit_entry['status']} ({audit_entry['duration_ms']}ms) "
            f"from {audit_entry['client_ip']}"
        )

        return response
