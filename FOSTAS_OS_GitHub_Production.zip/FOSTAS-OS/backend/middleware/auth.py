"""Optional API-key authentication middleware.

When `AUTH_ENABLED=true` and `FOSTAS_API_KEY` is set, all `/api/*` endpoints
require an `X-API-Key` header matching the configured key. The `/health`,
`/docs`, `/openapi.json`, and `/redoc` endpoints are always public so that
health checks and API discovery work without authentication.

This is intentionally a single shared key (not per-user auth) — appropriate
for a single-tenant studio tool. For multi-tenant deployments, replace with
JWT/OAuth middleware.
"""
from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from config.settings import get_settings

# Paths that bypass authentication even when auth is enabled.
PUBLIC_PATHS = {"/health", "/docs", "/openapi.json", "/redoc", "/"}


class AuthMiddleware(BaseHTTPMiddleware):
    """Validate X-API-Key header against the configured FOSTAS_API_KEY."""

    async def dispatch(self, request: Request, call_next):
        settings = get_settings()
        if not settings.auth_enabled:
            return await call_next(request)

        path = request.url.path
        # Public paths always bypass auth.
        if path in PUBLIC_PATHS or path.startswith("/docs") or path.startswith("/redoc"):
            return await call_next(request)

        # WebSocket upgrade requests bypass this HTTP middleware (handled separately).
        if request.headers.get("upgrade", "").lower() == "websocket":
            return await call_next(request)

        provided = request.headers.get("X-API-Key", "")
        expected = settings.fostas_api_key
        if not expected:
            # Auth is enabled but no key configured — fail closed.
            return JSONResponse(
                status_code=503,
                content={
                    "detail": "Server auth is enabled but FOSTAS_API_KEY is not configured."
                },
            )
        if provided != expected:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or missing X-API-Key header."},
            )

        return await call_next(request)
