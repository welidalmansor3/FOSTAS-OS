"""Per-IP token-bucket rate limiter.

When `RATE_LIMIT_ENABLED=true`, each client IP is allowed up to
`RATE_LIMIT_PER_MINUTE` requests per 60-second sliding window. Requests
over the limit receive HTTP 429 with a `Retry-After` header.

The bucket state is in-process (single-worker). For multi-worker
deployments, swap for a Redis-backed implementation — the public API
stays the same.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Deque, Dict

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from config.settings import get_settings

# Per-IP request timestamps. In-process only.
_buckets: Dict[str, Deque[float]] = defaultdict(deque)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Token-bucket per-IP rate limiter."""

    async def dispatch(self, request: Request, call_next):
        settings = get_settings()
        if not settings.rate_limit_enabled:
            return await call_next(request)

        # Don't rate-limit the docs / health endpoints.
        path = request.url.path
        if path in {"/health", "/docs", "/openapi.json", "/redoc", "/"}:
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        now = time.time()
        window_seconds = 60.0
        max_requests = settings.rate_limit_per_minute

        bucket = _buckets[client_ip]
        # Evict timestamps older than the window.
        while bucket and bucket[0] < now - window_seconds:
            bucket.popleft()

        if len(bucket) >= max_requests:
            oldest = bucket[0]
            retry_after = int(oldest + window_seconds - now) + 1
            return JSONResponse(
                status_code=429,
                content={
                    "detail": (
                        f"Rate limit exceeded: max {max_requests} requests per "
                        f"{int(window_seconds)}s per IP."
                    ),
                    "retry_after_seconds": retry_after,
                },
                headers={"Retry-After": str(retry_after)},
            )

        bucket.append(now)
        return await call_next(request)
