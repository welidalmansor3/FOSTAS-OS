"""
FOSTAS OS — FastAPI Backend (v1.1.0)

Main API server. Boots on port 8000.

All route handlers live in modular routers under `backend/api/`. This file
is the composition root: it wires middleware (CORS + auth + rate limit +
audit) and mounts the routers.

Endpoints (grouped by router):
  health    GET  /health
  system    GET  /api/system/providers
            GET  /api/system/plugins
            GET  /api/system/version
  prompt    POST /api/prompt
  stream    WS   /ws/prompt              (real-time AI activity streaming)
  workspace GET  /api/workspace/scan
            GET  /api/workspace/files
            GET  /api/workspace/file
  projects  GET  /api/projects
            POST /api/projects/switch
            POST /api/projects/create
  knowledge GET  /api/knowledge
            GET  /api/knowledge/search
            GET  /api/knowledge/{name}
            PUT  /api/knowledge/{name}
  downloads GET  /api/downloads
            POST /api/downloads
  uploads   GET  /api/uploads
            POST /api/uploads
  logs      GET  /api/logs
  cache     GET  /api/cache/stats
            DELETE /api/cache
"""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.api import (
    cache_router,
    downloads_router,
    health_router,
    knowledge_router,
    logs_router,
    prompt_router,
    projects_router,
    stream_router,
    system_router,
    uploads_router,
    workspace_router,
)
from backend.middleware import AuditMiddleware, AuthMiddleware, RateLimitMiddleware
from backend.plugins import load_plugins_from_env
from config.settings import get_settings


def create_app() -> FastAPI:
    settings = get_settings()
    settings.ensure_directories()

    # ---- Startup validation: refuse to start if required API keys are missing ----
    # Per security requirements: if any provider is in REAL mode but its API key
    # is missing, log a clear error and raise. When run via run.py this is
    # already validated; this is the safety net for direct `uvicorn` invocation.
    errors = settings.validate_api_keys()
    if errors:
        # Don't print keys — just the error messages.
        for e in errors:
            import sys
            print(f"❌ {e}", file=sys.stderr)
        raise RuntimeError(
            "FOSTAS OS refuses to start with missing configuration. "
            "See errors above. Fix .env or set *_REAL=false for mock mode."
        )

    # Load any external plugins declared via FOSTAS_PLUGINS env var.
    load_plugins_from_env()

    app = FastAPI(
        title="FOSTAS OS",
        description=(
            "AI Operating System for Game Development. "
            "Orchestrates Z.AI, Gemini, and Tripo to build & maintain "
            "the FOSTAS: Toybox Terror Godot multiplayer FPS."
        ),
        version="1.1.0",
    )

    # ---- Middleware (outermost first) ----
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    # Audit (always on — logs every request).
    app.add_middleware(AuditMiddleware)
    # Rate limit (configurable via RATE_LIMIT_ENABLED).
    app.add_middleware(RateLimitMiddleware)
    # Auth (optional via AUTH_ENABLED + FOSTAS_API_KEY).
    app.add_middleware(AuthMiddleware)

    # ---- Routers ----
    app.include_router(health_router)
    app.include_router(system_router)
    app.include_router(prompt_router)
    app.include_router(stream_router)
    app.include_router(workspace_router)
    app.include_router(projects_router)
    app.include_router(knowledge_router)
    app.include_router(downloads_router)
    app.include_router(uploads_router)
    app.include_router(logs_router)
    app.include_router(cache_router)

    return app


# Module-level app instance for uvicorn
app = create_app()


if __name__ == "__main__":
    import uvicorn

    settings = get_settings()
    uvicorn.run(
        "backend.main:app",
        host=settings.backend_host,
        port=settings.backend_port,
        reload=False,
        log_level="info",
    )
