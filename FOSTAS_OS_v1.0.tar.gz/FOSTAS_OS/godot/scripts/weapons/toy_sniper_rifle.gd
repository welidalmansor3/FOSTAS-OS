extends Weapon
class_name ToySniperRifle

@export var damage: int = 80
@export var fire_rate: float = 60.0  # Rounds per minute
@export var magazine_size: int = 10
@export var range: float = 200.0
@export var is_bolt_action: bool = true

var _can_fire: bool = true
var _is_reloading: bool = false
var _time_since_last_shot: float = 0.0
var _bolt_action_delay: float = 1.0  # Time to cycle bolt after each shot

func _ready() -> void:
	super._ready()
	_update_fire_rate()

func _physics_process(delta: float) -> void:
	if not _can_fire:
		_time_since_last_shot += delta
		
		if _is_reloading:
			# Check if reload is complete
			if _time_since_last_shot >= reload_time:
				_complete_reload()
		elif is_bolt_action and _time_since_last_shot >= _bolt_action_delay:
			# Bolt action cycling complete
			_can_fire = true
			_time_since_last_shot = 0.0

func fire() -> void:
	if not _can_fire or _is_reloading or current_ammo <= 0:
		return
		
	# Play fire animation and sound
	play_animation("fire")
	play_sound("fire")
	
	# Spawn bullet/projectile
	spawn_bullet()
	
	# Consume ammo
	current_ammo -= 1
	
	# Set cooldown
	_can_fire = false
	_time_since_last_shot = 0.0
	
	# If bolt action, prevent immediate next shot
	if is_bolt_action:
		_can_fire = false

func reload() -> void:
	if current_ammo >= magazine_size or _is_reloading or current_ammo <= 0:
		return
	
	_is_reloading = true
	_time_since_last_shot = 0.0
	_can_fire = false
	
	# Play reload animation and sound
	play_animation("reload")
	play_sound("reload")

func _complete_reload() -> void:
	current_ammo = magazine_size
	_is_reloading = false
	_can_fire = true
	_time_since_last_shot = 0.0

func _update_fire_rate() -> void:
	# Convert RPM to seconds between shots
	var fire_delay: float = 60.0 / fire_rate
	fire_cooldown = fire_delay

func spawn_bullet() -> void:
	# Create a bullet instance
	var bullet: Bullet = bullet_scene.instantiate()
	
	# Set bullet properties
	bullet.damage = damage
	bullet.max_range = range
	bullet.team = team
	
	# Position at muzzle
	bullet.global_transform = muzzle.global_transform
	
	# Add to scene tree
	get_tree().root.add_child(bullet)
	
	# Play muzzle flash (toy sparkle)
	play_muzzle_flash()
	
	# Play bullet tracer (candy-colored streak)
	play_bullet_tracer()