# File: scripts/weapons/weapon.gd
# FOSTAS: Toybox Terror — Base Weapon Class
# All weapons extend this. Provides fire(), reload(), ammo tracking.
extends Node3D
class_name Weapon

@export var weapon_name: String = "Toy Weapon"
@export var damage: int = 25
@export var fire_rate: float = 600.0  # rounds per minute
@export var magazine_size: int = 30
@export var range_m: float = 60.0
@export var reload_time: float = 2.5
@export var team_color: Color = Color(0.9, 0.22, 0.27)  # RED default

var current_ammo: int = 0
var is_reloading: bool = false
var _last_fire_time: float = 0.0
var _reload_timer: float = 0.0

signal fired(hit_result: Dictionary)
signal reloaded
signal ammo_changed(current: int, max: int)

func _ready() -> void:
    current_ammo = magazine_size
    ammo_changed.emit(current_ammo, magazine_size)

func _process(delta: float) -> void:
    if is_reloading:
        _reload_timer -= delta
        if _reload_timer <= 0.0:
            _finish_reload()

func can_fire() -> bool:
    if is_reloading:
        return false
    if current_ammo <= 0:
        return false
    var now: float = Time.get_ticks_msec() / 1000.0
    var cooldown: float = 60.0 / max(1.0, fire_rate)
    if now - _last_fire_time < cooldown:
        return false
    return true

func fire(from_position: Vector3, direction: Vector3) -> Dictionary:
    if not can_fire():
        return {"hit": false, "reason": "cannot_fire"}
    current_ammo -= 1
    _last_fire_time = Time.get_ticks_msec() / 1000.0
    ammo_changed.emit(current_ammo, magazine_size)
    # Raycast-based hit detection (server-authoritative in real multiplayer)
    var space_state: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
    var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(
        from_position, from_position + direction * range_m
    )
    query.exclude = [self]
    var result: Dictionary = space_state.intersect_ray(query)
    var hit_result: Dictionary = {"hit": false, "damage": 0, "ammo_left": current_ammo}
    if not result.is_empty():
        hit_result.hit = true
        hit_result.collider = result.collider
        hit_result.position = result.position
        hit_result.damage = damage
    fired.emit(hit_result)
    return hit_result

func reload() -> void:
    if is_reloading:
        return
    if current_ammo == magazine_size:
        return
    is_reloading = true
    _reload_timer = reload_time

func _finish_reload() -> void:
    current_ammo = magazine_size
    is_reloading = false
    ammo_changed.emit(current_ammo, magazine_size)
    reloaded.emit()
