extends CharacterBody3D
class_name PlayerNetwork

# Network configuration
@export var interpolation_buffer_size: int = 3  # 150ms at 20Hz server tick
@export var prediction_smoothing: float = 0.1  # Visual smoothing duration
@export var movement_tolerance: float = 0.5  # Max position correction distance

# Player state
var player_id: int = 0
var is_local_player: bool = false

# Network state tracking
var server_confirmed_state: Dictionary = {}  # Last server-confirmed position/rotation
var client_predicted_state: Dictionary = {}  # Client's predicted position/rotation
var input_buffer: Array = []  # Client-side input history for reconciliation
var snapshot_buffer: Array = []  # Received server snapshots for interpolation

# Movement state
var move_direction: Vector3 = Vector3.ZERO
var look_direction: Vector3 = Vector3.ZERO
var is_sprinting: bool = false

# Network timing
var last_server_tick: int = 0
var interpolation_timer: float = 0.0
var last_snapshot_time: float = 0.0

# Component references
@onready var camera_pivot: Node3D = $CameraPivot
@onready var collision_shape: CollisionShape3D = $CollisionShape3D

func _ready() -> void:
    # Set up network identity
    if is_local_player:
        # Register with network manager
        pass
    
    # Initialize state
    server_confirmed_state = {
        "position": global_transform.origin,
        "rotation": global_transform.basis,
        "tick": 0
    }
    
    client_predicted_state = server_confirmed_state.duplicate(true)
    
    # Configure interpolation buffer
    for i in range(interpolation_buffer_size):
        snapshot_buffer.append({
            "position": Vector3.ZERO,
            "rotation": Basis.IDENTITY,
            "tick": -1,
            "timestamp": -1.0
        })

func _physics_process(delta: float) -> void:
    if is_local_player:
        _handle_local_player_input(delta)
        _update_client_prediction(delta)
    else:
        _interpolate_remote_player(delta)
    
    # Apply movement
    _apply_movement(delta)
    
    # Update collision shape position (for server-side validation)
    collision_shape.global_transform = global_transform

func _handle_local_player_input(delta: float) -> void:
    # Gather input (this would come from your input system)
    var input := {
        "move": Vector3.ZERO,
        "look": Vector2.ZERO,
        "sprint": Input.is_action_pressed("sprint"),
        "timestamp": Time.get_ticks_msec() / 1000.0
    }
    
    # Standardize input
    input.move.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
    input.move.z = Input.get_action_strength("move_backward") - Input.get_action_strength("move_forward")
    input.move = input.move.normalized()
    
    # Add to input buffer for reconciliation
    input_buffer.append(input)
    
    # Keep buffer size reasonable (last 200ms of inputs)
    while input_buffer.size() > 12:  # 12 inputs at 60Hz = 200ms
        input_buffer.pop_front()
    
    # Update movement state
    move_direction = input.move
    look_direction = input.look
    is_sprinting = input.sprint

func _update_client_prediction(delta: float) -> void:
    # Apply client-side prediction
    var move_speed: float = 8.0 if is_sprinting else 5.0
    
    # Predict movement
    var predicted_velocity := move_direction * move_speed
    var predicted_position := global_transform.origin + predicted_velocity * delta
    
    # Update predicted state
    client_predicted_state["position"] = predicted_position
    client_predicted_state["rotation"] = camera_pivot.transform.basis
    
    # Visual smoothing between server correction and prediction
    if server_confirmed_state["tick"] > client_predicted_state["tick"]:
        # Server has sent a correction - reconcile
        var correction_factor := clamp(delta / prediction_smoothing, 0.0, 1.0)
        global_transform.origin = global_transform.origin.lerp(
            server_confirmed_state["position"], correction_factor
        )
        
        # Update prediction to match server
        client_predicted_state = server_confirmed_state.duplicate(true)
        
        # Re-apply recent inputs after correction
        _replay_inputs_after_correction()

func _replay_inputs_after_correction() -> void:
    # Replay inputs from buffer after server correction
    for input in input_buffer:
        var move_speed: float = 8.0 if input.sprint else 5.0
        var predicted_velocity := input.move * move_speed
        client_predicted_state["position"] += predicted_velocity * (1.0 / 60.0)  # 60Hz input rate

func _interpolate_remote_player(delta: float) -> void:
    # Find two snapshots to interpolate between
    var snapshot1: Dictionary = _get_latest_snapshot()
    var snapshot2: Dictionary = _get_previous_snapshot(snapshot1)
    
    if snapshot1["tick"] == -1 or snapshot2["tick"] == -1:
        # Not enough snapshots - freeze
        return
    
    # Calculate interpolation factor
    var interpolation_factor := _calculate_interpolation_factor(snapshot1, snapshot2, delta)
    
    # Interpolate position and rotation
    var interpolated_position := snapshot1["position"].lerp(
        snapshot2["position"], interpolation_factor
    )
    
    var interpolated_rotation := snapshot1["rotation"].slerp(
        snapshot2["rotation"], interpolation_factor
    )
    
    # Apply interpolated state with smoothing
    global_transform.origin = global_transform.origin.lerp(
        interpolated_position, delta * 10.0  # Fast smoothing
    )
    
    transform.basis = transform.basis.slerp(
        interpolated_rotation, delta * 10.0
    )

func _get_latest_snapshot() -> Dictionary:
    # Return the most recent valid snapshot
    for snapshot in snapshot_buffer:
        if snapshot["tick"] != -1:
            return snapshot
    return {"tick": -1, "position": Vector3.ZERO, "rotation": Basis.IDENTITY}

func _get_previous_snapshot(latest: Dictionary) -> Dictionary:
    # Find the snapshot before the latest one
    var found_latest := false
    for snapshot in snapshot_buffer:
        if found_latest and snapshot["tick"] != -1:
            return snapshot
        if snapshot["tick"] == latest["tick"]:
            found_latest = true
    return {"tick": -1, "position": Vector3.ZERO, "rotation": Basis.IDENTITY}

func _calculate_interpolation_factor(snapshot1: Dictionary, snapshot2: Dictionary, delta: float) -> float:
    # Calculate how far between two snapshots we are
    var time_between_snapshots := snapshot1["timestamp"] - snapshot2["timestamp"]
    if time_between_snapshots <= 0:
        return 0.0
    
    var interpolation_timer := Time.get_ticks_msec() / 1000.0 - snapshot1["timestamp"]
    var factor := interpolation_timer / time_between_snapshots
    
    # Clamp to [0, 1] range
    return clamp(factor, 0.0, 1.0)

func _apply_movement(delta: float) -> void:
    # Only apply movement for local player (server handles movement for others)
    if not is_local_player:
        return
    
    # Apply movement based on predicted state
    var move_speed: float = 8.0 if is_sprinting else 5.0
    velocity = move_direction * move_speed
    
    # Apply gravity if needed
    # velocity.y -= gravity * delta
    
    # Move character
    move_and_slide()

# Network functions called by server or RPC
func receive_server_snapshot(snapshot: Dictionary) -> void:
    # Add snapshot to buffer
    snapshot_buffer.push_front(snapshot)
    
    # Remove oldest snapshot if buffer is full
    if snapshot_buffer.size() > interpolation_buffer_size:
        snapshot_buffer.pop_back()
    
    # Update server confirmed state
    server_confirmed_state = snapshot.duplicate(true)
    
    # Check for position correction
    if is_local_player:
        var position_delta := global_transform.origin - server_confirmed_state["position"]
        if position_delta.length() > movement_tolerance:
            # Server correction needed - adjust position
            global_transform.origin = server_confirmed_state["position"]
            _replay_inputs_after_correction()

func process_server_correction(correction: Dictionary) -> void:
    # Handle server position correction
    if correction.has("position"):
        server_confirmed_state["position"] = correction["position"]
    
    if correction.has("rotation"):
        server_confirmed_state["rotation"] = correction["rotation"]
    
    if correction.has("tick"):
        server_confirmed_state["tick"] = correction["tick"]
    
    # Apply correction if this is the local player
    if is_local_player:
        var position_delta := global_transform.origin - server_confirmed_state["position"]
        if position_delta.length() > movement_tolerance:
            global_transform.origin = server_confirmed_state["position"]
            _replay_inputs_after_correction()

# Helper functions
func set_player_network_id(id: int) -> void:
    player_id = id
    name = "Player_" + str(id)

func mark_as_local() -> void:
    is_local_player = true
    # Set up camera, controls, etc.