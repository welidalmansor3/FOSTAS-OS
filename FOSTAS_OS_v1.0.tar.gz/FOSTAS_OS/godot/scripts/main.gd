# File: scripts/main.gd
# FOSTAS: Toybox Terror — Main scene entry point
extends Node3D

func _ready() -> void:
    print("FOSTAS: Toybox Terror — main scene loaded")
    print("Weapons available: ", WeaponsRegistry.list_weapons() if has_node("/root/WeaponsRegistry") else [])
    print("Monsters available: ", MonstersRegistry.list_monsters() if has_node("/root/MonstersRegistry") else [])
