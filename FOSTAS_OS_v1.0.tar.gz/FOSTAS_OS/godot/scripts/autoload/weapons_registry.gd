# File: scripts/autoload/weapons_registry.gd
# FOSTAS: Toybox Terror — Central registry of all weapon classes
extends Node

const WEAPON_SCRIPTS: Dictionary = {
    "BumbleBeeAR": "res://scripts/weapons/bumblebee_ar.gd",
    "PlasmaCarbine": "res://scripts/weapons/plasma_carbine.gd",
    "LaserMarksman": "res://scripts/weapons/laser_marksman.gd",
    "BuzzBeeSMG": "res://scripts/weapons/buzzbee_smg.gd",
    "HornetSMG": "res://scripts/weapons/hornet_smg.gd",
    "StarSniper": "res://scripts/weapons/star_sniper.gd",
    "StingerLMG": "res://scripts/weapons/stinger_lmg.gd",
    "ConfettiCannon": "res://scripts/weapons/confetti_cannon.gd",
    "BubbleBlaster": "res://scripts/weapons/bubble_blaster.gd",
    "PartyPopper": "res://scripts/weapons/party_popper.gd",
    "BalloonBomber": "res://scripts/weapons/balloon_bomber.gd",
}

func get_weapon_script(weapon_name: String) -> GDScript:
    var path: String = WEAPON_SCRIPTS.get(weapon_name, "")
    if path.is_empty():
        push_warning("Unknown weapon: " + weapon_name)
        return null
    return load(path) as GDScript

func list_weapons() -> Array:
    return WEAPON_SCRIPTS.keys()
