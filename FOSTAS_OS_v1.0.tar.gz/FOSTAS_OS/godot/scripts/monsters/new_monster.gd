extends CharacterBody3D
class_name NewMonster

@export var max_health: int = 100
@export var move_speed: float = 5.0
@export var attack_damage: int = 25
@export var detection_range: float = 15.0
@export var attack_cooldown: float = 1.0
@export var respawn_time: float = 5.0

var current_health: int
var state: String = "IDLE"
var player_ref: Node3D
var attack_timer: float = 0.0
var wander_timer: float = 0.0
var wander_direction: Vector3

func _ready():
    current_health = max_health
    $DetectionArea.body_entered.connect(_on_player_detected)
    $DetectionArea.body_exited.connect(_on_player_lost)
    $AttackArea.body_entered.connect(_on_player_in_attack_range)
    $AttackArea.body_exited.connect(_on_player_out_of_attack_range)
    $AttackCooldown.wait_time = attack_cooldown
    $AttackCooldown.timeout.connect(_on_attack_cooldown_finished)

func _physics_process(delta):
    # State machine for monster behavior
    match state:
        "IDLE":
            # Check if we should start wandering
            wander_timer -= delta
            if wander_timer <= 0:
                state = "WANDER"
                wander_direction = Vector3(randf_range(-1, 1), 0, randf_range(-1, 1)).normalized()
                wander_timer = randf_range(2, 5)
        
        "WANDER":
            # Random wandering movement
            wander_timer -= delta
            if wander_timer <= 0:
                state = "IDLE"
            else:
                velocity = move_speed * wander_direction
                move_and_slide()
        
        "CHASE":
            # Chase the detected player
            if player_ref:
                var direction_to_player = (player_ref.global_position - global_position).normalized()
                velocity = move_speed * direction_to_player
                move_and_slide()
                
                # Check if we're in attack range
                if global_position.distance_to(player_ref.global_position) < 2.0:
                    state = "ATTACK"
        
        "ATTACK":
            # Attack the player if in range
            if player_ref and global_position.distance_to(player_ref.global_position) < 2.0:
                if attack_timer <= 0:
                    attack_player()
                    attack_timer = attack_cooldown
            else:
                state = "CHASE"
            
            attack_timer -= delta
            if attack_timer <= 0:
                state = "CHASE"

func _on_player_detected(body: Node3D):
    # Check if the detected body is a player
    if body.is_in_group("player"):
        player_ref = body
        state = "CHASE"

func _on_player_lost(body: Node3D):
    # Check if the lost body is our current target
    if body == player_ref:
        player_ref = null
        state = "IDLE"

func _on_player_in_attack_range(body: Node3D):
    # Player is in attack range, prepare to attack
    if body == player_ref:
        state = "ATTACK"

func _on_player_out_of_attack_range(body: Node3D):
    # Player left attack range, resume chasing
    if body == player_ref:
        state = "CHASE"

func _on_attack_cooldown_finished():
    # Attack cooldown finished, can attack again
    pass

func attack_player():
    # Deal damage to the player
    if player_ref and player_ref.has_method("take_damage"):
        player_ref.take_damage(attack_damage)

func take_damage(amount: int):
    # Reduce health and check if monster should die
    current_health -= amount
    if current_health <= 0:
        die()

func die():
    # Handle monster death - respawn after delay
    $CollisionShape3D.disabled = true
    $MeshInstance3D.visible = false
    $RespawnTimer.wait_time = respawn_time
    $RespawnTimer.timeout.connect(_respawn)
    $RespawnTimer.start()
    state = "DEAD"

func _respawn():
    # Respawn the monster
    current_health = max_health
    $CollisionShape3D.disabled = false
    $MeshInstance3D.visible = true
    state = "IDLE"
    $RespawnTimer.timeout.disconnect(_respawn)