"""
FOSTAS OS — End-to-End Pipeline Test

Tests all 4 demo prompts:
  1. Add a new weapon
  2. Create a monster
  3. Fix multiplayer lag
  4. Scan my project

Requires the backend to be running (python run.py --no-frontend).
Or run via: python run.py --test (which boots backend automatically).

The test:
  - Submits each prompt to /api/prompt
  - Verifies the response shape
  - Confirms file changes were applied (where expected)
  - Reports pass/fail for each
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from backend.core.orchestrator import get_orchestrator  # noqa: E402
from backend.core import logger  # noqa: E402


DEMO_PROMPTS = [
    (
        "Add Weapon",
        "Add a new weapon: Toy Sniper Rifle, 80 dmg, 60 RPM, bolt-action, 10-round mag, 200m range",
        ["weapon", "sniper", "rifle"],
        "godot/scripts/weapons/",
    ),
    (
        "Generate Monster",
        "Create a monster: 100 HP, melee attacker, spawns at night, 5 m/s speed, 25 dmg per hit",
        ["monster", "enemy"],
        "godot/scripts/monsters/",
    ),
    (
        "Fix Bug",
        "Fix multiplayer lag in player movement — players are rubber-banding",
        ["network", "interpolat", "lag"],
        None,  # may edit existing file
    ),
    (
        "Scan Project",
        "Scan my project and report all weapons and monsters",
        ["scan", "scripts", "scenes"],
        None,  # no file changes
    ),
]


async def run_one(name: str, prompt: str, expected_keywords: list[str], expected_path: str | None) -> dict:
    """Run a single demo prompt and return a result dict."""
    print(f"\n{'─' * 60}")
    print(f"TEST: {name}")
    print(f"PROMPT: {prompt}")
    print(f"{'─' * 60}")

    orch = get_orchestrator()
    report = await orch.process_prompt(prompt)

    result = {
        "name": name,
        "prompt": prompt,
        "success": report.success,
        "intent": report.analysis.intent.value if report.analysis.intent else "unknown",
        "complexity": report.analysis.complexity.value if report.analysis.complexity else "unknown",
        "duration_ms": report.duration_ms,
        "file_changes": [fc.model_dump() for fc in report.file_changes],
        "ai_interactions": [
            {
                "provider": ai.provider,
                "model": ai.model,
                "success": ai.success,
                "duration_ms": ai.duration_ms,
            }
            for ai in report.ai_interactions
        ],
        "knowledge_loaded": report.knowledge_loaded,
        "errors": [t.error for t in report.plan.tasks if t.error],
    }

    # Assertions
    print(f"  → success={report.success}, intent={result['intent']}, "
          f"duration={report.duration_ms}ms")
    print(f"  → file_changes={len(result['file_changes'])}, "
          f"ai_interactions={len(result['ai_interactions'])}")

    if not report.success:
        result["failure_reason"] = "orchestrator returned success=False"
        print(f"  ❌ FAILED: orchestrator returned success=False")
        if result["errors"]:
            print(f"     errors: {result['errors']}")
        return result

    # Check at least one AI interaction happened (except scan_project)
    if result["intent"] != "scan_project":
        if not result["ai_interactions"]:
            result["failure_reason"] = "no AI interactions recorded"
            print(f"  ❌ FAILED: no AI interactions recorded")
            return result

    # Check file changes for create/add intents
    if expected_path:
        # Verify a file was created in the expected subdir
        paths = [fc["path"] for fc in result["file_changes"]]
        if not any(expected_path in p for p in paths):
            # Try once more — list the actual files in that dir
            from backend.core import get_godot_manager
            gm = get_godot_manager()
            files_after = gm.list_files(expected_path.replace("godot/", ""))
            if not files_after:
                result["failure_reason"] = f"no file created in {expected_path}"
                print(f"  ❌ FAILED: no file created in {expected_path}")
                print(f"     paths: {paths}")
                return result
            else:
                print(f"  ℹ️  Files in {expected_path}: {files_after}")
        else:
            print(f"  ✅ File created in expected path: {expected_path}")

    # Check summary contains expected keywords (loose check)
    summary_lower = report.summary.lower()
    matched_kw = [kw for kw in expected_keywords if kw in summary_lower]
    if matched_kw:
        print(f"  ✅ Summary contains keywords: {matched_kw}")
    else:
        print(f"  ℹ️  Summary keywords not matched (loose check, not failing)")

    result["passed"] = True
    print(f"  ✅ PASSED")
    return result


async def main() -> int:
    print("=" * 60)
    print("FOSTAS OS — End-to-End Pipeline Test")
    print("=" * 60)
    print(f"Testing {len(DEMO_PROMPTS)} demo prompts...")

    results = []
    for name, prompt, kws, path in DEMO_PROMPTS:
        r = await run_one(name, prompt, kws, path)
        results.append(r)

    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    passed = sum(1 for r in results if r.get("passed"))
    failed = len(results) - passed
    for r in results:
        icon = "✅" if r.get("passed") else "❌"
        print(f"  {icon} {r['name']:<20} intent={r['intent']:<15} "
              f"duration={r['duration_ms']}ms  "
              f"files={len(r['file_changes'])}  ai={len(r['ai_interactions'])}")

    print(f"\n  Total: {passed} passed, {failed} failed")

    # Save detailed report
    report_path = ROOT / "logs" / "test_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(results, indent=2, default=str, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"\n  Detailed report: {report_path}")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
