# FOSTAS OS

**AI Operating System for Game Development**

FOSTAS OS is a natural-language → production-code pipeline that orchestrates **Z.AI** + **Google Gemini** + **Tripo AI** to build, modify, and maintain the **FOSTAS: Toybox Terror** Godot 4.3 multiplayer FPS.

You describe what you want. FOSTAS OS analyzes the prompt, loads relevant game knowledge, generates GDScript, edits the Godot project (with backups), validates via Godot CLI, and returns a completion report.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure API keys (ZAI is auto; Gemini key optional — falls back to mock)
cp .env.example .env
# edit .env: set GEMINI_API_KEY for real Gemini (or leave blank for mock)

# 3. Boot FOSTAS OS (boots both backend + frontend)
python run.py
```

Then open:
- **Frontend UI:** http://localhost:8501
- **Backend API docs:** http://localhost:8000/docs

Press `Ctrl+C` to stop both services.

---

## 🎯 Try the 4 Demo Prompts

In the Streamlit UI (Prompt panel), click any demo button:

| Demo | Prompt | Expected Outcome |
|------|--------|------------------|
| **Add Weapon** | "Add a new weapon: Toy Sniper Rifle, 80 dmg, 60 RPM, bolt-action, 10-round mag, 200m range" | Z.AI generates `godot/scripts/weapons/sniper_rifle.gd` |
| **Generate Monster** | "Create a monster: 100 HP, melee attacker, spawns at night, 5 m/s speed, 25 dmg per hit" | Z.AI generates `godot/scripts/monsters/*.gd`; Tripo returns placeholder GLB URL |
| **Fix Bug** | "Fix multiplayer lag in player movement — players are rubber-banding" | Gemini analyzes + proposes interpolation fix → applied to network script |
| **Scan Project** | "Scan my project and report all weapons and monsters" | Returns full inventory of scripts, scenes, models |

---

## 🏗️ Architecture

```
FOSTAS_OS/
├── run.py                    # ← Single launcher (boots backend + frontend)
├── .env / .env.example       # API keys + settings (NEVER commit real .env)
├── requirements.txt
│
├── config/
│   └── settings.py           # Pydantic settings (env-driven, no hardcoded secrets)
│
├── backend/                  # FastAPI (Python, async, modular)
│   ├── main.py               # API app + routes
│   ├── api/                  # (route modules, currently in main.py for v1)
│   ├── core/
│   │   ├── orchestrator.py   # The brain: Gemini → Z.AI → Tripo → Godot
│   │   ├── prompt_analyzer.py# Gemini-based intent/complexity/risk parser
│   │   ├── godot_manager.py  # Scan, edit, validate Godot project (with backups)
│   │   ├── cache.py          # File-based AI response cache
│   │   ├── download_manager.py # Chunked + resume + checksum
│   │   ├── upload_manager.py # Drag-drop + auto-classify into godot/assets/
│   │   └── logger.py         # Structured logs (fostas.log + events.jsonl)
│   ├── providers/
│   │   ├── base.py           # BaseProvider interface
│   │   ├── zai_provider.py   # REAL: glm-4-plus via z-ai CLI
│   │   ├── gemini_provider.py# REAL: gemini-2.5-flash via google-genai SDK
│   │   └── tripo_provider.py # MOCK (v1): placeholder GLB URL
│   ├── knowledge/
│   │   └── manager.py        # Load + retrieve game knowledge docs
│   └── models/
│       └── schemas.py        # Pydantic: PromptAnalysis, Task, CompletionReport
│
├── frontend/                 # Streamlit (dark theme)
│   └── app.py                # 8 panels: Prompt, Workspace, AI Activity,
│                             #          Logs, Downloads, Uploads, Knowledge, System
│
├── knowledge/                # FOSTAS game knowledge base (auto-seeded)
│   ├── GameBible.md          # Vision, factions, classes, performance targets
│   ├── Weapons.md            # 11-weapon manifest + damage model
│   ├── Magic.md              # Mage spell system (Tier-2, Tier-3, bounty)
│   ├── Potions.md            # Healing/Speed/Rage/Invisibility potions
│   ├── Vehicles.md           # Toy Kart, Tank, Helicopter
│   ├── Maps.md               # Castle Wars map layout + lighting
│   ├── Monster.md            # Shadow Monster AI + FOSTAS event phases
│   ├── Networking.md         # Server-authoritative + lag compensation
│   └── Optimization.md       # Frame budget, LOD, occlusion culling
│
├── godot/                    # Sample Godot 4.3 project (auto-seeded)
│   ├── project.godot
│   ├── scenes/main.tscn
│   ├── scripts/
│   │   ├── main.gd
│   │   ├── weapons/weapon.gd, bumblebee_ar.gd
│   │   ├── monsters/shadow_monster.gd
│   │   ├── network/player_network.gd
│   │   └── autoload/weapons_registry.gd, monsters_registry.gd
│   └── assets/{characters,weapons,environment,ui,audio}/
│
├── workspace/                # Active project pointer (symlink or copy)
├── cache/                    # AI response cache (auto-managed)
├── downloads/                # Download manager files
├── uploads/                  # User-uploaded assets
├── logs/                     # fostas.log + events.jsonl
│
└── scripts/
    ├── seed.py               # Re-seed knowledge + Godot project
    └── test_pipeline.py      # End-to-end test of 4 demo prompts
```

---

## 🔌 AI Provider Roles

| Provider | Role | Real in v1 | Model |
|----------|------|------------|-------|
| **Z.AI** | Primary Programming AI — Godot scripts, gameplay, multiplayer, scenes | ✅ Real (via `z-ai` CLI) | `glm-4-plus` |
| **Google Gemini** | Architecture, planning, code review, prompt analysis | ✅ Real (via `google-genai` SDK) | `gemini-2.5-flash` |
| **Tripo AI** | 3D asset generation — props, buildings, environment | ❌ Mock (v1) | `tripo-v3` |

To enable real Gemini: set `GEMINI_API_KEY` in `.env` (get one at https://aistudio.google.com/apikey).
Without it, Gemini falls back to a deterministic rule-based mock.

To enable real Tripo: set `TRIPO_REAL=true` and `TRIPO_API_KEY` in `.env`.

---

## 🧠 Pipeline Flow

```
User Prompt
    │
    ▼
[1] Prompt Analyzer (Gemini)        → PromptAnalysis
    │  intent, complexity, risk,
    │  required files/providers/assets,
    │  knowledge docs to load
    ▼
[2] Knowledge Retriever             → loaded .md docs
    │  (keyword-overlap retrieval)
    ▼
[3] Godot Workspace Scan            → current project memory
    │
    ▼
[4] Z.AI Code Generation            → GDScript files
    │  (cached, retried on failure,
    │   Gemini fallback if Z.AI fails twice)
    ▼
[5] Tripo 3D Asset Generation       → GLB model URL (mock in v1)
    │
    ▼
[6] Godot Manager Apply             → write files (always backup first)
    │
    ▼
[7] Godot CLI Validate              → syntax check (if Godot binary available)
    │
    ▼
[8] Completion Report               → user-facing summary
       (file changes, AI interactions,
        knowledge loaded, duration)
```

---

## 🔒 Security

- **No hardcoded API keys.** All secrets read from `.env`.
- `.env.example` is the only env file committed; real `.env` is gitignored.
- Frontend never sees API keys — all AI calls happen server-side.
- Godot manager rejects path traversal attempts (paths must stay inside `godot/`).
- File writes always create timestamped backups before overwriting.
- CORS limited to `localhost:8000` and `localhost:8501` by default.

---

## 🛠️ Production-Ready Features

- ✅ **Async FastAPI** with Pydantic v2 validation
- ✅ **Modular provider interface** — add new AI providers without touching orchestrator
- ✅ **Error recovery**: Z.AI retry + Gemini fallback
- ✅ **File-based AI response cache** (24h TTL)
- ✅ **Structured logging** (JSON-lines + human-readable, rotating)
- ✅ **Godot project backups** before every write
- ✅ **Download manager** with chunked transfer, resume, SHA-256 verification, retry
- ✅ **Upload manager** with auto-classification (ZIP extraction, asset routing)
- ✅ **Godot CLI integration** for import + validation + export

---

## 📋 API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health + provider status |
| GET | `/api/providers` | List AI providers + modes |
| POST | `/api/prompt` | Submit a natural-language prompt |
| GET | `/api/workspace/scan` | Scan Godot project |
| GET | `/api/workspace/files` | List project files |
| GET | `/api/workspace/file?path=` | Read a single file |
| GET | `/api/knowledge` | List knowledge docs |
| GET | `/api/knowledge/{name}` | Read a knowledge doc |
| PUT | `/api/knowledge/{name}` | Write a knowledge doc |
| GET | `/api/downloads` | List downloaded files |
| POST | `/api/downloads` | Submit URL to download |
| GET | `/api/uploads` | List uploaded files |
| POST | `/api/uploads` | Upload a file (multipart) |
| GET | `/api/logs?limit=100` | Recent log events |
| GET | `/api/cache/stats` | Cache statistics |
| DELETE | `/api/cache` | Clear cache |

---

## 🧪 Testing

```bash
# Run end-to-end test of all 4 demo prompts
python run.py --test

# Re-seed knowledge + Godot project (idempotent)
python run.py --seed
```

The test report is saved to `logs/test_report.json`.

---

## 🎮 The FOSTAS: Toybox Terror Game

The seeded knowledge base + Godot project describe a complete game design:

- **5v5 multiplayer FPS** for PC (Steam)
- **Stylized toy world** aesthetic with **mid-match psychological horror event**
- **Engine:** Godot 4.3
- **Match:** 8-12 minutes, Best-of-3, 4-minute rounds
- **Classes:** Combat Medic + Tactical Mage
- **11 weapons** (BumbleBee AR, BuzzBee SMG, Star Sniper, Stinger LMG, etc.)
- **FOSTAS Monster event**: 4 phases (Blackout → Warning → Hunt → Recovery)
- **Server-authoritative networking** with 200ms lag compensation
- **Performance targets:** 60 FPS on GTX 1060, 144 FPS on RTX 4070

See `knowledge/GameBible.md` for the full design doc.

---

## 🛣️ Roadmap (v2+)

- Real Tripo API integration (3D model generation)
- Streamlit file editor with syntax highlighting
- Godot scene (.tscn) visual editor
- Multi-project workspace switcher
- WebSocket-based real-time AI activity streaming
- Docker Compose deployment
- User authentication + multi-tenant
- Plugin system for custom AI providers

---

## 📄 License

Proprietary — FOSTAS OS internal use. Game design © FOSTAS Studio.
