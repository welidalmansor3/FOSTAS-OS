"""
FOSTAS OS — FastAPI Backend

Main API server. Boots on port 8000.

Endpoints:
  GET  /health                    — health check + provider status
  GET  /api/providers             — list AI providers
  POST /api/prompt                — submit a natural-language prompt
  GET  /api/workspace/scan        — scan the Godot project
  GET  /api/workspace/files       — list files in the project
  GET  /api/workspace/file?path=  — read a single file
  GET  /api/knowledge             — list knowledge docs
  GET  /api/knowledge/{name}      — read a knowledge doc
  PUT  /api/knowledge/{name}      — write a knowledge doc
  GET  /api/downloads             — list downloaded files
  POST /api/downloads             — submit a URL to download
  GET  /api/uploads               — list uploaded files
  POST /api/uploads                — upload a file (multipart)
  GET  /api/logs?limit=100        — recent log events
  GET  /api/cache/stats           — cache statistics
  DELETE /api/cache                — clear cache
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from backend.core import (
    error as log_error,
    get_cache,
    get_godot_manager,
    get_orchestrator,
    get_recent_events,
    info as log_info,
)
from backend.core.download_manager import get_download_manager
from backend.core.upload_manager import get_upload_manager
from backend.knowledge import get_knowledge_manager
from backend.providers import list_providers
from config.settings import get_settings


# ----------------------------------------------------------------
# Pydantic request models
# ----------------------------------------------------------------


class PromptRequest(BaseModel):
    prompt: str
    context: Optional[Dict[str, Any]] = None


class DownloadRequest(BaseModel):
    url: str
    filename: Optional[str] = None
    expected_sha256: Optional[str] = None


class KnowledgeUpdate(BaseModel):
    content: str


# ----------------------------------------------------------------
# App factory
# ----------------------------------------------------------------


def create_app() -> FastAPI:
    settings = get_settings()
    settings.ensure_directories()

    app = FastAPI(
        title="FOSTAS OS",
        description=(
            "AI Operating System for Game Development. "
            "Orchestrates Z.AI, Gemini, and Tripo to build & maintain "
            "the FOSTAS: Toybox Terror Godot multiplayer FPS."
        ),
        version="1.0.0",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ----------------------------------------------------------------
    # Health & system
    # ----------------------------------------------------------------

    @app.get("/health")
    async def health() -> Dict[str, Any]:
        godot = get_godot_manager()
        return {
            "status": "ok",
            "version": "1.0.0",
            "godot_cli_available": godot.is_cli_available(),
            "godot_binary": settings.godot_binary,
            "providers": list_providers(),
        }

    @app.get("/api/providers")
    async def get_providers() -> Dict[str, Any]:
        return {"providers": list_providers()}

    # ----------------------------------------------------------------
    # Prompt orchestration
    # ----------------------------------------------------------------

    @app.post("/api/prompt")
    async def submit_prompt(req: PromptRequest) -> Dict[str, Any]:
        """Process a natural-language prompt end-to-end."""
        if not req.prompt.strip():
            raise HTTPException(status_code=400, detail="Prompt cannot be empty")

        log_info(f"API received prompt: {req.prompt[:200]}")
        orchestrator = get_orchestrator()
        report = await orchestrator.process_prompt(req.prompt)

        return report.model_dump(mode="json")

    # ----------------------------------------------------------------
    # Workspace
    # ----------------------------------------------------------------

    @app.get("/api/workspace/scan")
    async def scan_workspace() -> Dict[str, Any]:
        godot = get_godot_manager()
        try:
            scan = godot.scan()
            return {"success": True, "scan": scan.summary()}
        except FileNotFoundError as e:
            return {"success": False, "error": str(e)}

    @app.get("/api/workspace/files")
    async def list_files(subdir: str = "") -> Dict[str, Any]:
        godot = get_godot_manager()
        files = godot.list_files(subdir)
        return {"files": files, "count": len(files)}

    @app.get("/api/workspace/file")
    async def read_file(path: str) -> Dict[str, Any]:
        godot = get_godot_manager()
        try:
            content = godot.read_file(path)
            return {"path": path, "content": content, "size": len(content)}
        except (FileNotFoundError, ValueError) as e:
            raise HTTPException(status_code=404, detail=str(e))

    # ----------------------------------------------------------------
    # Knowledge
    # ----------------------------------------------------------------

    @app.get("/api/knowledge")
    async def list_knowledge() -> Dict[str, Any]:
        km = get_knowledge_manager()
        return {"docs": km.list_docs()}

    @app.get("/api/knowledge/{name}")
    async def get_knowledge_doc(name: str) -> Dict[str, Any]:
        km = get_knowledge_manager()
        content = km.get_doc(name)
        if not content:
            raise HTTPException(status_code=404, detail=f"Doc not found: {name}")
        return {"name": name, "content": content, "size": len(content)}

    @app.put("/api/knowledge/{name}")
    async def update_knowledge_doc(name: str, body: KnowledgeUpdate) -> Dict[str, Any]:
        km = get_knowledge_manager()
        path = km.write_doc(name, body.content)
        return {"name": name, "path": str(path), "size": len(body.content)}

    # ----------------------------------------------------------------
    # Downloads
    # ----------------------------------------------------------------

    @app.get("/api/downloads")
    async def list_downloads() -> Dict[str, Any]:
        dm = get_download_manager()
        return {"files": dm.list_downloads()}

    @app.post("/api/downloads")
    async def submit_download(req: DownloadRequest) -> Dict[str, Any]:
        dm = get_download_manager()
        result = await dm.download(
            url=req.url,
            filename=req.filename,
            expected_sha256=req.expected_sha256,
        )
        return {
            "success": result.success,
            "path": str(result.path) if result.path else None,
            "bytes_downloaded": result.bytes_downloaded,
            "duration_seconds": result.duration_seconds,
            "checksum_verified": result.checksum_verified,
            "error": result.error,
        }

    # ----------------------------------------------------------------
    # Uploads
    # ----------------------------------------------------------------

    @app.get("/api/uploads")
    async def list_uploads() -> Dict[str, Any]:
        um = get_upload_manager()
        return {"files": um.list_uploads()}

    @app.post("/api/uploads")
    async def upload_file(file: UploadFile = File(...)) -> Dict[str, Any]:
        um = get_upload_manager()
        contents = await file.read()
        result = um.save_upload(file.filename or "upload.bin", contents)
        return {
            "success": result.success,
            "filename": result.filename,
            "saved_path": str(result.saved_path) if result.saved_path else None,
            "category": result.category,
            "size_bytes": result.size_bytes,
            "unzipped": result.unzipped,
            "files_added": result.files_added,
            "error": result.error,
        }

    # ----------------------------------------------------------------
    # Logs
    # ----------------------------------------------------------------

    @app.get("/api/logs")
    async def get_logs(
        limit: int = Query(100, ge=1, le=1000),
        level: Optional[str] = None,
    ) -> Dict[str, Any]:
        events = get_recent_events(limit=limit, level=level)
        return {"events": events, "count": len(events)}

    # ----------------------------------------------------------------
    # Cache
    # ----------------------------------------------------------------

    @app.get("/api/cache/stats")
    async def cache_stats() -> Dict[str, Any]:
        cache = get_cache()
        return cache.stats()

    @app.delete("/api/cache")
    async def clear_cache(namespace: Optional[str] = None) -> Dict[str, Any]:
        cache = get_cache()
        removed = cache.clear(namespace)
        return {"removed": removed, "namespace": namespace or "all"}

    return app


# Module-level app instance for uvicorn
app = create_app()


if __name__ == "__main__":
    import uvicorn

    settings = get_settings()
    uvicorn.run(
        "backend.main:app",
        host=settings.backend_host,
        port=settings.backend_port,
        reload=False,
        log_level="info",
    )
