"""
FOSTAS OS — Knowledge Base Manager

Loads, indexes, and retrieves knowledge documents from knowledge/.
Knowledge docs are Markdown files describing the game:
  GameBible.md, Weapons.md, Magic.md, Potions.md, Vehicles.md,
  Maps.md, Monster.md, Networking.md, Optimization.md

The retriever uses keyword overlap (TF-IDF-lite) to find docs
relevant to a given prompt — no external embedding API needed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Set, Tuple

from backend.core import logger
from config.settings import get_settings


# Default knowledge docs (created by the seeder)
DEFAULT_DOCS = [
    "GameBible.md",
    "Weapons.md",
    "Magic.md",
    "Potions.md",
    "Vehicles.md",
    "Maps.md",
    "Monster.md",
    "Networking.md",
    "Optimization.md",
]


@dataclass
class KnowledgeDoc:
    name: str  # e.g. "Weapons.md"
    path: Path
    title: str  # First H1
    content: str
    sections: List[Tuple[str, str]]  # (heading, body)
    word_set: Set[str]


class KnowledgeManager:
    """Loads and indexes knowledge documents."""

    def __init__(self) -> None:
        self.settings = get_settings()
        self.knowledge_dir: Path = self.settings.knowledge_dir
        self._docs: Dict[str, KnowledgeDoc] = {}
        self._loaded = False

    def load(self, force: bool = False) -> None:
        """Load all .md files from knowledge/."""
        if self._loaded and not force:
            return
        self._docs.clear()
        if not self.knowledge_dir.exists():
            logger.warning(f"knowledge dir does not exist: {self.knowledge_dir}")
            return
        for md_file in sorted(self.knowledge_dir.glob("*.md")):
            try:
                doc = self._parse_md(md_file)
                self._docs[doc.name] = doc
            except Exception as e:
                logger.error(f"Failed to parse {md_file}: {e}")
        self._loaded = True
        logger.info(f"Loaded {len(self._docs)} knowledge docs", count=len(self._docs))

    def _parse_md(self, path: Path) -> KnowledgeDoc:
        """Parse a markdown file into sections."""
        content = path.read_text(encoding="utf-8")
        # Extract title from first H1
        title = path.stem
        m = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
        if m:
            title = m.group(1).strip()

        # Split into sections by ## headings
        sections: List[Tuple[str, str]] = []
        parts = re.split(r"^##\s+(.+)$", content, flags=re.MULTILINE)
        # parts: [pre_h2, h2_1, body_1, h2_2, body_2, ...]
        if len(parts) > 1:
            for i in range(1, len(parts), 2):
                heading = parts[i].strip()
                body = parts[i + 1].strip() if i + 1 < len(parts) else ""
                sections.append((heading, body))

        # Word set for retrieval (lowercase, alnum only, length >= 3)
        words = set(re.findall(r"[a-z0-9_]{3,}", content.lower()))

        return KnowledgeDoc(
            name=path.name,
            path=path,
            title=title,
            content=content,
            sections=sections,
            word_set=words,
        )

    def list_docs(self) -> List[str]:
        """List all knowledge doc names."""
        if not self._loaded:
            self.load()
        return sorted(self._docs.keys())

    def get_doc(self, name: str) -> str:
        """Get full content of a knowledge doc by name."""
        if not self._loaded:
            self.load()
        # Allow lookup with or without .md
        if not name.endswith(".md"):
            name = name + ".md"
        doc = self._docs.get(name)
        return doc.content if doc else ""

    def write_doc(self, name: str, content: str) -> Path:
        """Write content to a knowledge doc (creates or overwrites)."""
        if not name.endswith(".md"):
            name = name + ".md"
        path = self.knowledge_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        logger.file_change("edit", str(path), bytes_written=len(content))
        # Refresh index
        self._loaded = False
        self.load()
        return path

    def retrieve_relevant(
        self, prompt: str, top_k: int = 3
    ) -> List[Tuple[str, float, str]]:
        """
        Find docs relevant to a prompt using keyword overlap scoring.

        Returns: list of (doc_name, score, doc_content) sorted by score desc.
        """
        if not self._loaded:
            self.load()
        if not self._docs:
            return []

        # Tokenize prompt
        prompt_words = set(re.findall(r"[a-z0-9_]{3,}", prompt.lower()))
        if not prompt_words:
            return []

        scored: List[Tuple[str, float, str]] = []
        for name, doc in self._docs.items():
            if not doc.word_set:
                continue
            overlap = len(prompt_words & doc.word_set)
            if overlap == 0:
                continue
            # Jaccard-like score
            score = overlap / len(prompt_words | doc.word_set)
            scored.append((name, score, doc.content))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def retrieve_by_intent(self, intent: str) -> List[str]:
        """
        Retrieve docs relevant to a known intent.
        Maps intents to expected knowledge docs.
        """
        mapping = {
            "add_weapon": ["Weapons.md", "GameBible.md"],
            "create_monster": ["Monster.md", "GameBible.md"],
            "fix_bug": ["Networking.md", "Optimization.md"],
            "optimize": ["Optimization.md", "Networking.md"],
            "add_magic": ["Magic.md", "GameBible.md"],
            "add_potion": ["Potions.md", "GameBible.md"],
            "add_map": ["Maps.md", "GameBible.md"],
            "add_vehicle": ["Vehicles.md", "GameBible.md"],
            "scan_project": [],
            "documentation": [],
            "refactor": ["Optimization.md"],
        }
        docs = mapping.get(intent, ["GameBible.md"])
        # Filter to only existing docs
        if not self._loaded:
            self.load()
        return [d for d in docs if d in self._docs]


# Singleton
_km: KnowledgeManager | None = None


def get_knowledge_manager() -> KnowledgeManager:
    global _km
    if _km is None:
        _km = KnowledgeManager()
        _km.load()
    return _km
