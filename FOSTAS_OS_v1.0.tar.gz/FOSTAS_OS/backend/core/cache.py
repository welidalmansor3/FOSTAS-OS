"""
FOSTAS OS — Cache Manager

Caches:
  - AI responses (key = hash of provider+model+prompt+system)
  - Generated assets (file-based)
  - Project analysis snapshots

Uses file-based cache with TTL. No external DB required.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Optional

from config.settings import get_settings


class CacheManager:
    """File-based cache with TTL."""

    def __init__(self) -> None:
        self.settings = get_settings()
        self.cache_dir: Path = self.settings.cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl_seconds = self.settings.cache_ttl_hours * 3600

    @staticmethod
    def _hash_key(key: str) -> str:
        return hashlib.sha256(key.encode("utf-8")).hexdigest()

    def get(self, namespace: str, key: str) -> Optional[Any]:
        """Get a cached value. Returns None if miss or expired."""
        ns_dir = self.cache_dir / namespace
        path = ns_dir / f"{self._hash_key(key)}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if time.time() - data.get("ts", 0) > self.ttl_seconds:
                return None  # expired
            return data.get("value")
        except (json.JSONDecodeError, OSError):
            return None

    def set(self, namespace: str, key: str, value: Any) -> None:
        """Set a cached value."""
        ns_dir = self.cache_dir / namespace
        ns_dir.mkdir(parents=True, exist_ok=True)
        path = ns_dir / f"{self._hash_key(key)}.json"
        data = {"ts": time.time(), "key": key, "value": value}
        path.write_text(json.dumps(data, default=str, ensure_ascii=False), encoding="utf-8")

    def get_ai_response(
        self, provider: str, model: str, prompt: str, system: Optional[str] = None
    ) -> Optional[str]:
        """Get a cached AI response."""
        key = f"{provider}|{model}|{system or ''}|{prompt}"
        return self.get("ai_responses", key)

    def set_ai_response(
        self,
        provider: str,
        model: str,
        prompt: str,
        response: str,
        system: Optional[str] = None,
    ) -> None:
        """Cache an AI response."""
        key = f"{provider}|{model}|{system or ''}|{prompt}"
        self.set("ai_responses", key, response)

    def clear(self, namespace: Optional[str] = None) -> int:
        """Clear a namespace (or all). Returns number of entries removed."""
        import shutil

        if namespace:
            ns_dir = self.cache_dir / namespace
            if ns_dir.exists():
                count = len(list(ns_dir.glob("*.json")))
                shutil.rmtree(ns_dir)
                return count
            return 0
        # Clear all
        count = 0
        for d in self.cache_dir.iterdir():
            if d.is_dir():
                count += len(list(d.glob("*.json")))
                shutil.rmtree(d)
        return count

    def stats(self) -> Dict[str, int]:
        """Return cache statistics."""
        stats: Dict[str, int] = {"total_entries": 0, "namespaces": 0}
        for d in self.cache_dir.iterdir():
            if d.is_dir():
                stats["namespaces"] += 1
                stats["total_entries"] += len(list(d.glob("*.json")))
        return stats


# Singleton
_cache: CacheManager | None = None


def get_cache() -> CacheManager:
    global _cache
    if _cache is None:
        _cache = CacheManager()
    return _cache
