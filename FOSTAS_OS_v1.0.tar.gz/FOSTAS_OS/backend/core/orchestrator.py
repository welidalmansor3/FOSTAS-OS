"""
FOSTAS OS — AI Orchestrator

The brain of FOSTAS OS. Coordinates the full pipeline:

    User Prompt
        │
        ▼
    [1] Prompt Analyzer (Gemini)  →  PromptAnalysis
        │
        ▼
    [2] Knowledge Retriever        →  load relevant .md docs
        │
        ▼
    [3] Godot Workspace Scan       →  current project memory
        │
        ▼
    [4] Z.AI Code Generation       →  GDScript / scene files
        │ (optional)
        ▼
    [5] Tripo 3D Asset Generation  →  GLB / FBX model URLs
        │
        ▼
    [6] Godot Manager Apply        →  write files (with backups)
        │
        ▼
    [7] Godot CLI Validate         →  syntax check
        │
        ▼
    [8] Completion Report          →  user-facing summary

Error recovery:
  - If Z.AI fails → retry once
  - If Z.AI still fails → ask Gemini for an alternative implementation
  - If Tripo fails → retry once, then continue with placeholder
  - Never crash; always return a CompletionReport (success=false on error)
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from backend.core import logger
from backend.core.cache import get_cache
from backend.core.godot_manager import GodotManager, get_godot_manager
from backend.core.prompt_analyzer import PromptAnalyzer, get_prompt_analyzer
from backend.knowledge import get_knowledge_manager
from backend.models import (
    AIInteraction,
    Complexity,
    CompletionReport,
    FileChange,
    Intent,
    PromptAnalysis,
    Risk,
    Task,
    TaskPlan,
)
from backend.providers import get_gemini, get_tripo, get_zai


# System prompts for code generation
ZAI_CODEGEN_SYSTEM = """You are FOSTAS OS's Lead Godot Engineer. You write production-ready GDScript for Godot 4.3.

Rules:
- Output GDScript 2.0 syntax (Godot 4.x).
- Use @export for inspector-exposed properties.
- Use class_name for reusable classes.
- Use typed variables and return types everywhere.
- Include _ready(), _physics_process() only if needed.
- No placeholders. No TODOs. No "your code here".
- Comment why, not what.
- For weapons: include damage, fire_rate, magazine_size, range, fire(), reload().
- For monsters: include max_health, move_speed, attack_damage, take_damage(), die(), simple AI state machine.
- For network fixes: include interpolation buffers, lag compensation hooks.

When asked to generate a file, wrap your output in a single ```gdscript code block
and start with a "# File: <relative/path.gd>" comment so the Godot Manager can
write it to the right location.

Example:
```gdscript
# File: scripts/weapons/rifle.gd
extends Node3D
class_name RifleWeapon

@export var damage: int = 25
...
```"""

GEMINI_FIX_SYSTEM = """You are FOSTAS OS's Lead Network Engineer. When asked to fix a multiplayer/lag issue:
1. Identify the root cause from the symptoms.
2. Propose a concrete GDScript patch (interpolation, prediction, reconciliation).
3. Output the fix as a single ```gdscript code block starting with "# File: <path>"."""


class Orchestrator:
    """Coordinates the full FOSTAS OS pipeline."""

    def __init__(self) -> None:
        self.analyzer = get_prompt_analyzer()
        self.knowledge = get_knowledge_manager()
        self.godot = get_godot_manager()
        self.cache = get_cache()
        self.zai = get_zai()
        self.gemini = get_gemini()
        self.tripo = get_tripo()

    async def process_prompt(self, prompt: str) -> CompletionReport:
        """
        Process a user prompt end-to-end.

        Always returns a CompletionReport. Never raises.
        """
        started = datetime.now(timezone.utc)
        report = CompletionReport(
            prompt=prompt,
            analysis=PromptAnalysis(),  # placeholder, filled below
            plan=TaskPlan(),
        )

        try:
            # ---- Step 1: Analyze ----
            analysis = await self.analyzer.analyze(prompt)
            report.analysis = analysis
            logger.info(
                f"Analysis complete: intent={analysis.intent}, "
                f"complexity={analysis.complexity}, risk={analysis.risk}"
            )

            # Special case: scan_project requires no further AI work
            if analysis.intent == Intent.SCAN_PROJECT:
                return await self._handle_scan(report)

            # ---- Step 2: Load relevant knowledge ----
            knowledge_loaded: List[str] = []
            knowledge_content = ""
            for doc_name in analysis.knowledge_docs:
                content = self.knowledge.get_doc(doc_name)
                if content:
                    knowledge_loaded.append(doc_name)
                    knowledge_content += f"\n\n=== {doc_name} ===\n{content[:4000]}"
            report.knowledge_loaded = knowledge_loaded

            # Also retrieve by keyword overlap as a bonus
            relevant = self.knowledge.retrieve_relevant(prompt, top_k=2)
            for name, _score, content in relevant:
                if name not in knowledge_loaded:
                    knowledge_loaded.append(name)
                    knowledge_content += f"\n\n=== {name} (auto) ===\n{content[:3000]}"

            # ---- Step 3: Scan workspace (lightweight) ----
            try:
                scan = self.godot.scan()
                workspace_summary = scan.summary()
            except Exception as e:
                logger.warning(f"Workspace scan failed: {e}")
                workspace_summary = {"error": str(e)}

            # ---- Step 4: Build task plan ----
            plan = self._build_plan(analysis)
            report.plan = plan

            # ---- Step 5: Execute tasks ----
            file_changes: List[FileChange] = []
            ai_interactions: List[AIInteraction] = []
            # Shared state between tasks: latest AI content per provider
            task_state: Dict[str, Any] = {
                "ai_content": {},  # provider -> latest content
                "asset_url": None,
            }

            for task in plan.tasks:
                if task.status != "pending":
                    continue
                # Check dependencies
                if not all(
                    any(t.id == dep and t.status == "success" for t in plan.tasks)
                    for dep in task.depends_on
                ):
                    task.status = "skipped"
                    continue

                task.mark_started()
                try:
                    fc, ai, result = await self._execute_task(
                        task,
                        analysis,
                        prompt,
                        knowledge_content,
                        workspace_summary,
                        task_state,
                    )
                    file_changes.extend(fc)
                    ai_interactions.extend(ai)
                    task.mark_success(result or {})
                except Exception as e:
                    logger.error(f"Task {task.id} failed: {e}")
                    task.mark_failed(str(e))

            report.file_changes = file_changes
            report.ai_interactions = ai_interactions

            # ---- Step 6: Validate (best-effort) ----
            if self.godot.is_cli_available() and file_changes:
                ok, msg = await self.godot.validate_project()
                logger.info(f"Validation: ok={ok}, msg={msg[:200]}")
                if not ok:
                    report.plan.tasks.append(
                        Task(
                            id=999,
                            description=f"Validation warnings: {msg}",
                            provider="godot_manager",
                            status="failed" if not ok else "success",
                            error=msg if not ok else None,
                        )
                    )

            # ---- Step 7: Build summary ----
            successful = sum(1 for t in plan.tasks if t.status == "success")
            failed = sum(1 for t in plan.tasks if t.status == "failed")
            report.success = failed == 0
            report.summary = self._build_summary(report, successful, failed)
            report.finalize()
            return report

        except Exception as e:
            logger.error(f"Orchestrator fatal error: {e}", exc_info=True)
            report.success = False
            report.overall_error = str(e)
            report.summary = f"FOSTAS OS encountered an error: {e}"
            report.finalize()
            return report

    # ----------------------------------------------------------------
    # Special handler: scan_project intent
    # ----------------------------------------------------------------

    async def _handle_scan(self, report: CompletionReport) -> CompletionReport:
        """Handle the scan_project intent: scan and report."""
        scan = self.godot.scan()
        summary = scan.summary()

        # Build a readable inventory
        lines = [
            "# FOSTAS OS — Project Scan Report",
            "",
            f"**Project path:** `{scan.project_path}`",
            f"**Godot version:** {scan.godot_version}",
            f"**Total files:** {scan.total_files}",
            f"**Total size:** {summary['total_size_mb']} MB",
            "",
            "## Inventory",
            f"- Scripts (.gd): {len(scan.scripts)}",
            f"- Scenes (.tscn): {len(scan.scenes)}",
            f"- Textures: {len(scan.textures)}",
            f"- Materials: {len(scan.materials)}",
            f"- 3D Models: {len(scan.models)}",
            f"- Sounds: {len(scan.sounds)}",
            "",
            "## Scripts",
        ]
        for s in scan.scripts[:50]:
            lines.append(f"- `{s.relative_to(scan.project_path)}`")
        if len(scan.scripts) > 50:
            lines.append(f"- ... and {len(scan.scripts) - 50} more")

        lines.extend(["", "## Scenes"])
        for s in scan.scenes[:30]:
            lines.append(f"- `{s.relative_to(scan.project_path)}`")

        lines.extend(["", "## 3D Models"])
        for s in scan.models[:20]:
            lines.append(f"- `{s.relative_to(scan.project_path)}`")

        report.summary = "\n".join(lines)
        report.success = True
        report.plan.tasks = [
            Task(
                id=1,
                description="Scan Godot project",
                provider="godot_manager",
                status="success",
                result=summary,
            )
        ]
        report.finalize()
        return report

    # ----------------------------------------------------------------
    # Plan builder
    # ----------------------------------------------------------------

    def _build_plan(self, analysis: PromptAnalysis) -> TaskPlan:
        """Build a task plan based on the analysis."""
        tasks: List[Task] = []
        tid = 1

        # Always load knowledge first
        if analysis.knowledge_docs:
            tasks.append(
                Task(
                    id=tid,
                    description=f"Load knowledge docs: {', '.join(analysis.knowledge_docs)}",
                    provider="internal",
                )
            )
            tid += 1

        # Z.AI code generation (depends on knowledge)
        if "zai" in analysis.required_providers and analysis.required_files:
            tasks.append(
                Task(
                    id=tid,
                    description=f"Generate code via Z.AI for: {', '.join(analysis.required_files[:3])}",
                    provider="zai",
                    depends_on=[1] if analysis.knowledge_docs else [],
                )
            )
            zai_task_id = tid
            tid += 1
        else:
            zai_task_id = None

        # Tripo asset generation (parallel to Z.AI)
        if "tripo" in analysis.required_providers:
            tasks.append(
                Task(
                    id=tid,
                    description="Generate 3D asset via Tripo (mock in v1)",
                    provider="tripo",
                    depends_on=[1] if analysis.knowledge_docs else [],
                )
            )
            tid += 1

        # Gemini analysis (for fix_bug intent)
        if "gemini" in analysis.required_providers and analysis.intent == Intent.FIX_BUG:
            tasks.append(
                Task(
                    id=tid,
                    description="Analyze bug + propose fix via Gemini",
                    provider="gemini",
                    depends_on=[1] if analysis.knowledge_docs else [],
                )
            )
            gemini_task_id = tid
            tid += 1
        else:
            gemini_task_id = None

        # Apply to Godot (depends on Z.AI and/or Gemini)
        apply_deps = [d for d in [zai_task_id, gemini_task_id] if d is not None]
        if apply_deps:
            tasks.append(
                Task(
                    id=tid,
                    description="Apply AI output to Godot project (with backups)",
                    provider="godot_manager",
                    depends_on=apply_deps,
                )
            )
            tid += 1

        # Validate via Godot CLI
        tasks.append(
            Task(
                id=tid,
                description="Validate project via Godot CLI (if available)",
                provider="godot_manager",
                depends_on=list(range(1, tid)),
            )
        )

        return TaskPlan(
            tasks=tasks,
            reasoning=f"Plan for intent={analysis.intent}, complexity={analysis.complexity}",
        )

    # ----------------------------------------------------------------
    # Task executor
    # ----------------------------------------------------------------

    async def _execute_task(
        self,
        task: Task,
        analysis: PromptAnalysis,
        prompt: str,
        knowledge_content: str,
        workspace_summary: Dict[str, Any],
        task_state: Dict[str, Any],
    ) -> tuple[List[FileChange], List[AIInteraction], Dict[str, Any]]:
        """Execute a single task. Returns (file_changes, ai_interactions, result)."""
        file_changes: List[FileChange] = []
        ai_interactions: List[AIInteraction] = []
        result: Dict[str, Any] = {}

        provider = task.provider

        # ---- Internal: knowledge load ----
        if provider == "internal":
            result["loaded_docs"] = analysis.knowledge_docs
            return file_changes, ai_interactions, result

        # ---- Z.AI codegen ----
        if provider == "zai":
            # Check cache first
            cache_key = f"{prompt}|{knowledge_content[:500]}"
            cached = self.cache.get_ai_response("zai", "glm-4-plus", cache_key)
            if cached:
                logger.info("Z.AI cache HIT")
                ai_content = cached
                ai_interactions.append(
                    AIInteraction(
                        provider="zai",
                        model="glm-4-plus",
                        prompt_summary=prompt[:200],
                        response_summary="[CACHED] " + ai_content[:200],
                        duration_ms=0,
                        success=True,
                    )
                )
            else:
                # Build the actual generation prompt
                gen_prompt = self._build_codegen_prompt(
                    prompt, analysis, knowledge_content, workspace_summary
                )
                # First attempt
                resp = await self.zai.safe_chat(
                    prompt=gen_prompt,
                    system=ZAI_CODEGEN_SYSTEM,
                    temperature=0.3,
                    max_tokens=2048,
                )
                if not resp.success:
                    # Retry once
                    logger.warning(f"Z.AI failed, retrying: {resp.error}")
                    resp = await self.zai.safe_chat(
                        prompt=gen_prompt,
                        system=ZAI_CODEGEN_SYSTEM,
                        temperature=0.4,
                        max_tokens=2048,
                    )
                if not resp.success:
                    # Ask Gemini for alternative
                    logger.warning("Z.AI failed twice; asking Gemini for alternative")
                    alt_resp = await self.gemini.safe_chat(
                        prompt=f"Z.AI failed to generate code for: {prompt}\nProvide an alternative GDScript implementation.",
                        system=ZAI_CODEGEN_SYSTEM,
                    )
                    resp = alt_resp if alt_resp.success else resp

                ai_interactions.append(
                    AIInteraction(
                        provider="zai",
                        model=resp.model,
                        prompt_summary=gen_prompt[:200],
                        response_summary=resp.content[:200],
                        duration_ms=resp.duration_ms,
                        success=resp.success,
                        error=resp.error,
                    )
                )
                ai_content = resp.content
                if resp.success and ai_content:
                    self.cache.set_ai_response(
                        "zai", "glm-4-plus", cache_key, ai_content
                    )

            # Store in shared task_state so the apply task can pick it up
            if ai_content:
                task_state["ai_content"]["zai"] = ai_content
            result["ai_content"] = (ai_content or "")[:5000]
            return file_changes, ai_interactions, result

        # ---- Gemini analysis (for fix_bug) ----
        if provider == "gemini":
            gen_prompt = self._build_fix_prompt(
                prompt, analysis, knowledge_content, workspace_summary
            )
            resp = await self.gemini.safe_chat(
                prompt=gen_prompt,
                system=GEMINI_FIX_SYSTEM,
                temperature=0.3,
                max_tokens=2048,
            )
            ai_interactions.append(
                AIInteraction(
                    provider="gemini",
                    model=resp.model,
                    prompt_summary=gen_prompt[:200],
                    response_summary=resp.content[:200],
                    duration_ms=resp.duration_ms,
                    success=resp.success,
                    error=resp.error,
                )
            )
            content = resp.content if resp.success else ""
            if content:
                task_state["ai_content"]["gemini"] = content
            result["ai_content"] = content[:5000]
            return file_changes, ai_interactions, result

        # ---- Tripo asset ----
        if provider == "tripo":
            asset_prompt = f"3D model for: {prompt}. Style: stylized toy world, low-poly, plastic shading."
            resp = await self.tripo.safe_generate_asset(prompt=asset_prompt, asset_format="glb")
            ai_interactions.append(
                AIInteraction(
                    provider="tripo",
                    model="tripo-v3",
                    prompt_summary=asset_prompt[:200],
                    response_summary=f"asset_url={resp.asset_url}",
                    duration_ms=resp.duration_ms,
                    success=resp.success,
                    error=resp.error,
                )
            )
            if resp.success:
                task_state["asset_url"] = resp.asset_url
                task_state["asset_format"] = resp.asset_format
            result["asset_url"] = resp.asset_url if resp.success else ""
            result["asset_format"] = resp.asset_format
            return file_changes, ai_interactions, result

        # ---- Godot Manager apply ----
        if provider == "godot_manager" and "Apply" in task.description:
            # Pick the latest AI content from any provider (prefer Z.AI, then Gemini)
            ai_content = (
                task_state.get("ai_content", {}).get("zai")
                or task_state.get("ai_content", {}).get("gemini")
                or ""
            )

            if ai_content:
                applied = self.godot.apply_ai_response(ai_content)
                for action, rel_path, backup_path in applied:
                    file_changes.append(
                        FileChange(
                            action=action,
                            path=f"godot/{rel_path}",
                            backup_path=str(backup_path) if backup_path else None,
                        )
                    )
                result["applied_files"] = [fc.path for fc in file_changes]
                logger.info(
                    f"Applied {len(file_changes)} file changes to Godot project"
                )
            else:
                result["applied_files"] = []
                result["note"] = "No AI content to apply"
                logger.warning("Apply task ran but no AI content was available")

            return file_changes, ai_interactions, result

        # ---- Godot Manager validate ----
        if provider == "godot_manager" and "Validate" in task.description:
            if self.godot.is_cli_available():
                ok, msg = await self.godot.validate_project()
                result["validation_ok"] = ok
                result["validation_msg"] = msg
            else:
                result["validation_ok"] = None
                result["validation_msg"] = "Godot CLI not available; skipped"

            return file_changes, ai_interactions, result

        return file_changes, ai_interactions, result

    # ----------------------------------------------------------------
    # Prompt builders
    # ----------------------------------------------------------------

    def _build_codegen_prompt(
        self,
        prompt: str,
        analysis: PromptAnalysis,
        knowledge_content: str,
        workspace_summary: Dict[str, Any],
    ) -> str:
        """Build the prompt sent to Z.AI for code generation."""
        files_str = "\n".join(f"- {f}" for f in analysis.required_files) or "(none specified — infer from prompt)"
        return f"""USER REQUEST:
{prompt}

PROJECT KNOWLEDGE:
{knowledge_content[:6000]}

CURRENT WORKSPACE:
- Scripts: {workspace_summary.get('scripts', 'unknown')}
- Scenes: {workspace_summary.get('scenes', 'unknown')}
- Godot version: {workspace_summary.get('godot_version', '4.3')}

REQUIRED OUTPUT FILES:
{files_str}

Generate production-ready GDScript for Godot 4.3 that fulfills the USER REQUEST.
Each file MUST start with "# File: <relative/path.gd>" (path relative to godot/).
Use typed GDScript 2.0 syntax. No placeholders. No TODOs.
"""

    def _build_fix_prompt(
        self,
        prompt: str,
        analysis: PromptAnalysis,
        knowledge_content: str,
        workspace_summary: Dict[str, Any],
    ) -> str:
        """Build the prompt for Gemini to analyze & propose a fix."""
        files_str = "\n".join(f"- {f}" for f in analysis.required_files)
        return f"""USER BUG REPORT:
{prompt}

NETWORKING KNOWLEDGE:
{knowledge_content[:6000]}

CURRENT WORKSPACE:
- Scripts: {workspace_summary.get('scripts', 'unknown')}

AFFECTED FILES:
{files_str}

Analyze the bug and propose a concrete GDScript fix.
Output the fix as a single ```gdscript code block starting with "# File: <path>".
"""

    # ----------------------------------------------------------------
    # Summary builder
    # ----------------------------------------------------------------

    def _build_summary(
        self, report: CompletionReport, successful: int, failed: int
    ) -> str:
        """Build a human-readable summary of what happened."""
        lines = [
            f"# FOSTAS OS — Completion Report",
            "",
            f"**Prompt:** {report.prompt}",
            f"**Intent:** {report.analysis.intent}",
            f"**Complexity:** {report.analysis.complexity}",
            f"**Risk:** {report.analysis.risk}",
            f"**Duration:** {report.duration_ms} ms",
            f"**Success:** {'✅' if report.success else '❌'}",
            "",
            "## Tasks",
            f"- Successful: {successful}",
            f"- Failed: {failed}",
            "",
        ]

        if report.knowledge_loaded:
            lines.append("## Knowledge Loaded")
            for d in report.knowledge_loaded:
                lines.append(f"- {d}")
            lines.append("")

        if report.ai_interactions:
            lines.append("## AI Interactions")
            for ai in report.ai_interactions:
                status = "✅" if ai.success else "❌"
                lines.append(
                    f"- {status} **{ai.provider}** ({ai.model}) — {ai.duration_ms}ms"
                )
            lines.append("")

        if report.file_changes:
            lines.append("## File Changes")
            for fc in report.file_changes:
                lines.append(f"- `{fc.action}` → `{fc.path}`")
                if fc.backup_path:
                    lines.append(f"  - backup: `{fc.backup_path}`")
            lines.append("")

        if report.overall_error:
            lines.append("## Error")
            lines.append(f"```\n{report.overall_error}\n```")

        return "\n".join(lines)


# Singleton
_orchestrator: Orchestrator | None = None


def get_orchestrator() -> Orchestrator:
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = Orchestrator()
    return _orchestrator
