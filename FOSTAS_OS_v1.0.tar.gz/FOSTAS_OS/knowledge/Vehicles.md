# FOSTAS Vehicles System

## Design Philosophy
FOSTAS: Toybox Terror is primarily a 5v5 infantry FPS, but vehicles appear as map objectives and event rewards. All vehicles use the stylized toy aesthetic — bright plastic colors, oversized wheels, cartoon proportions.

## Toy Kart (Map Objective)
- Spawns once per round at the mid-field playground center
- 2 seats: driver + gunner
- Driver: WASD movement, Boost (Shift, 3-second burst, 10s cooldown)
- Gunner: Toy Blaster turret (infinite ammo, 300 RPM, 15 DMG)
- HP: 200 (destroyed → respawns after 60s)
- Speed: 12 m/s normal, 18 m/s boost
- Model: original Kart GLB (not in 11-weapon manifest — separate asset)

## Toy Tank (FOSTAS Event Reward)
- Spawns for the team that kills the most Shadow Monsters during the Hunt phase
- 1 driver, 1 gunner
- Main cannon: 150 DMG, 4 RPM, 100m range, splash radius 5m
- Coaxial MG: 25 DMG, 600 RPM
- HP: 500
- Speed: 6 m/s
- Limited duration: 60 seconds, then despawns

## Toy Helicopter (Rare Pickup)
- Spawns at a random rooftop every 3 minutes
- 1 pilot, 1 gunner
- Pilot: WASD + Space/Ctrl for altitude
- Gunner: dual Toy Blasters (300 RPM each, 12 DMG)
- HP: 150
- Flight time: unlimited until destroyed
- Fuel: NONE (simplified for arcade feel)

## Adding a New Vehicle via FOSTAS OS
1. Create `godot/scripts/vehicles/<vehicle_name>.gd` extending `VehicleBody3D` or `RigidBody3D`.
2. Define `@export` stats: max_speed, hp, seats, weapons.
3. Implement `_physics_process()` for movement.
4. Add driver/gunner input mapping.
5. Create matching `.tscn` scene.
6. Register in `godot/autoload/vehicles_registry.gd`.
