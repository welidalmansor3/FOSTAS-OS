# FOSTAS Performance Optimization

## Targets
- 60 FPS sustained on GTX 1060 @ 1080p medium (during 5v5 + FOSTAS event)
- 120-144 FPS on RTX 4070
- Frame-time budget: 16.6 ms (60 FPS)

## Profiling Tools
- Godot Built-in Profiler (Monitor tab)
- `--rendering-driver opengl3` for compatibility testing
- `--rendering-driver vulkan` for production
- Render debug: `--render-debug overdraw` to find overdraw hotspots

## Rendering Optimizations

### LOD (Level of Detail)
- 3 LOD levels per weapon model: full (0-15m), medium (15-40m), low (40m+)
- 4 LOD levels per environment mesh (castle_wars is 19 meshes)
- Trigger: distance from camera
- Use Godot's `LODManager` or manual `MeshInstance3D.lod_bias`

### Occlusion Culling
- Enable `OcclusionCulling` in project settings
- Bake occlusion meshes for castle_wars and mid-field playground
- Critical for 1684-mesh mid-field scene

### Baked Lighting (Cute Phase)
- Use BakedLightmap + LightmapGI for cute phase
- 4K lightmap resolution for castle interiors
- 2K for outdoor areas
- Static geometry only — dynamic objects use real-time light probes

### Real-time Lighting (Horror Phase)
- Single cold point-light per shadow monster (max 5 active)
- Disable shadow casting on point-lights (perf cost too high)
- Use unlit materials for distant geometry during Hunt phase

### Material Optimizations
- Use `StandardMaterial3D` with `shading_mode = unshaded` where possible
- PlasticToy material: 1 texture, 1 uniform (team_color_override) — very cheap
- Avoid `BaseMaterial3D` features like `subsurface_scattering` for toys

## Networking Optimizations

### Snapshot Compression
- Use delta compression (send only changes from last snapshot)
- Quantize positions to 16-bit per axis (±327m, 1mm precision)
- Quantize rotations to quaternion packed in 32 bits

### Bandwidth Budget
- Target: 64 Kbps per client (server → client)
- Target: 16 Kbps per client (client → server, inputs)
- 5v5 = 10 clients = 640 Kbps server upload, 160 Kbps server download

## Memory Optimizations
- Asset streaming for mid-field playground (load in chunks based on player position)
- Texture streaming: mipmaps streamed from disk
- Audio: stream long stems, preload short SFX

## Frame-Time Budget Breakdown (60 FPS = 16.6ms)
- Rendering: 8ms (48%)
- Physics: 3ms (18%)
- Networking: 1ms (6%)
- Game logic: 3ms (18%)
- Audio: 0.5ms (3%)
- OS/overhead: 1.1ms (7%)

## Common Performance Issues & Fixes

### Frame Drops During FOSTAS Event
- Root cause: 5 real-time point-lights + dynamic GI recalculation
- Fix: disable dynamic GI during Hunt, use baked "horror" lightmap + per-monster point-light

### Stuttering on Asset Load
- Root cause: synchronous texture streaming
- Fix: enable `ResourceLoader.load_async`, preload critical assets at match start

### High Draw Calls (1684 mesh mid-field)
- Root cause: too many small meshes
- Fix: merge static meshes via `MeshInstance3D.merge_meshes`, target <500 draw calls per frame
