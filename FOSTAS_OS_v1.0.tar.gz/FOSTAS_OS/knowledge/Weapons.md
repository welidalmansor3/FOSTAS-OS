# FOSTAS Weapons System

## Toy Reskin Pipeline (8 steps, applied to all imported weapon GLTFs)
1. Load imported GLTF as-is (no re-modeling)
2. Swap every metallic/dark material for PlasticToy material
3. Apply team_color_override (RED: #E63946, BLUE: #1D6FB8)
4. Replace muzzle flash with toy sparkle particle
5. Replace bullet tracer with candy-colored streak
6. Add subtle cartoon outline shader
7. Normalize scale to 1m bounding-box longest axis
8. Attach Toy Blaster Pistol as universal sidearm

## Damage Model
- Headshot: x4
- Torso: x1
- Limb: x0.7
- TTK target: 0.3-0.8 s at optimal range

## Weapon Manifest (11 imported GLTFs)

| # | Folder | Real Weapon | Toy Name | Slot | DMG | RPM | Mag | Range |
|---|--------|-------------|----------|------|-----|-----|-----|-------|
| 1 | low-poly_aug_a1 | Steyr AUG A1 | BumbleBee AR | Primary | 22 | 700 | 30 | 60m |
| 2 | low-poly_fn_arka | FN ARKA | Plasma Carbine | Primary | 28 | 600 | 30 | 80m |
| 3 | low-poly_hk_mr762 | H&K MR762 | Laser Marksman | Primary | 55 | 300 | 20 | 120m |
| 4 | low-poly_kriss_vector | KRISS Vector | BuzzBee SMG | Primary | 16 | 1100 | 25 | 25m |
| 5 | low-poly_pp-19_vityaz-sn | PP-19 Vityaz | Hornet SMG | Primary | 18 | 800 | 30 | 30m |
| 6 | low-poly_psl_rifle | PSL DMR | Star Sniper | Primary | 110 (HS one-shot) | 60 | 10 | 200m |
| 7 | low-poly_rpk-74n | RPK-74N | Stinger LMG | Primary | 24 | 600 | 75 | 80m, bipod |
| 8 | low-poly_saiga_410 | Saiga-410 | Confetti Cannon | Primary | 12x8 pellets | 200 | 8 | 15m |
| 9 | low-poly_six_12 | Six12 | Bubble Blaster | Primary | 14x6 pellets | 240 | 6 | 18m |
| 10 | low-poly_tactical_shotgun | Tactical Shotgun | Party Popper | Primary | 16x9 pellets | 100 | 5 | 20m |
| 11 | low-poly_gl6 | GL6 grenade launcher | Balloon Bomber | Primary | 80 splash | 60 | 4 | 50m arc |

## Universal Sidearm (NOT from imported GLTF)
**Toy Blaster Pistol**: single low-poly mesh ~3K tris, toy plastic, every class spawns with it. DMG 12, RPM 300, Mag 10, Range 20m. Infinite reserve.

## Critical Gaps
- All 11 weapon GLTFs ship with ZERO animations — must author reload/fire/inspect from scratch.
- Scale normalization required (bounding boxes range from 0.38m to 3.88m longest axis).

## Adding a New Weapon
To add a new weapon via FOSTAS OS:
1. Create `godot/scripts/weapons/<weapon_name>.gd` extending `Weapon` base class.
2. Define `@export` stats matching the table above.
3. Implement `fire()`, `reload()`, `_physics_process()`.
4. Create matching `.tscn` scene with model placeholder.
5. Register in `godot/autoload/weapons_registry.gd`.
