# FOSTAS Maps System

## Primary Map — Castle Wars
Assembled from TWO imported GLTFs:

### Base: `castle_wars_pavlov_vr/scene.gltf`
- 19 meshes, 21 nodes, 19 materials, 5 textures
- Bounding box: 137m x 40m x 18.7m
- Two opposing castles: AlliesC.001 → Red, AxisC → Blue
- Each castle has 3 floors: courtyard gate, ramparts, sniper tower
- ⚠ LICENSE: CC-BY-NC-SA-4.0 — NON-COMMERCIAL. Replace for Steam release.

### Mid-field: `lowpoly__map__asset__by_resoforge`
- Massive 1684-mesh, 2746-node set
- Bounding box: 252m x 112m x 60m
- Materials: PLANE, YELLOW, WHITE, etc.
- Provides containers, ramps, crates for cover
- License: CC-BY-4.0 (commercial OK)

## Map Layout
- Two castles at opposite ends (Red on west, Blue on east)
- Courtyard in the middle (artifact spawn point)
- 3 lanes: north, middle, south
- Vertical play: each castle's sniper tower overlooks courtyard
- Health/ammo racks in each castle's courtyard

## Lighting
- **Cute phase (default)**: baked global illumination, soft pastel GI, warm sun
- **Horror phase (FOSTAS event)**: real-time GI, single cold point-light per shadow monster, rest of map in darkness
- Transition: 0.4-second lerp

## Verticality
- Each castle: gate level, ramparts (mid), sniper tower (top)
- Tower windows overlook courtyard
- Sniper rifle (Star Sniper) optimal from tower

## Future Maps (planned)
1. **Toy Workshop** — assembly line conveyor belts, toy parts as cover
2. **Playground** — swing sets, slides, sandcastle bunkers
3. **Toy Store** — shelving aisles, display cases, checkout counter control point

## Adding a New Map via FOSTAS OS
1. Create `godot/scenes/maps/<map_name>.tscn` extending Node3D.
2. Import the base GLTF as a child scene.
3. Add spawn points (player, weapon, potion, vehicle).
4. Add light probes for baked GI (cute phase).
5. Add real-time light sources for horror phase.
6. Register in `godot/autoload/maps_registry.gd`.
