# FOSTAS Multiplayer Networking

## Architecture
- Dedicated-server authoritative (standard competitive FPS)
- Server tick rate: 20 Hz (50ms per tick)
- Client input rate: 60 Hz
- Snapshot interpolation: 100ms buffer
- Lag compensation: 200ms rewind window for hit validation
- Reconnect window: 90 seconds

## Server Authority
- Server runs full game simulation at 20 Hz
- Clients send inputs (movement, look, fire) at 60 Hz
- Server validates all actions (no client trust)
- Server broadcasts world snapshots at 20 Hz
- Clients interpolate between snapshots (100ms buffer)

## Hit Validation (Lag Compensation)
- Client fires → predicts hit locally
- Server rewinds world state by up to 200ms
- Server validates shot from client's perspective at fire time
- If hit confirmed server-side, damage applied
- If miss, no rollback needed (client prediction was wrong)

## Client-Side Prediction
- Movement: client predicts own position, server corrects if mismatch
- Reconciliation: client rewinds to server-confirmed state, replays inputs
- Visual smoothing: 0.1s lerp to avoid rubber-banding

## Snapshot Interpolation
- Buffer 3 snapshots (150ms) before rendering
- Linear interpolation between snapshots
- Extrapolation cap: 100ms (then freeze entity)

## FOSTAS Event Networking
- Server rolls trigger time at match start (random 1:30-6:30, once per match)
- Server broadcasts all phase transitions:
  - Phase 1 Blackout (0.4s) — all clients blackout simultaneously
  - Phase 2 Warning (1.0s) — all clients see warning text
  - Phase 3 Hunt (20s) — server spawns 5 monsters, broadcasts positions
  - Phase 4 Recovery (2s) — all clients fade back

## Common Issues & Fixes

### Lag / Rubber-banding
- Symptom: players teleport, hit registration feels off
- Root cause: snapshot interpolation buffer underrun, or client prediction mismatch
- Fix: increase interpolation buffer to 150ms, add input delta compression, validate movement server-side with tolerance window

### Desync
- Symptom: clients see different world states
- Root cause: missed snapshots, deterministic physics divergence
- Fix: server broadcasts full state every 5 seconds (re-sync), client rewinds and replays

### High Ping Player
- Symptom: lag compensation abused (getting shot around corners)
- Root cause: 200ms rewind window too generous for 300ms+ ping players
- Fix: clamp rewind to min(client_ping, 200ms), reject shots from ping > 300ms

## Adding New Network Features via FOSTAS OS
1. Define RPC in `godot/scripts/network/rpc_manager.gd`.
2. Use `@rpc("any_peer", "call_local", "reliable")` for state changes.
3. Use `@rpc("any_peer", "unreliable")` for high-frequency updates.
4. Server validates all peer requests before applying.
