# FOSTAS Potions System

## Healing Potion (Toy Green)
- Restores 50 HP instantly
- Carry limit: 2 per life
- Use key: F
- VFX: toy-green sparkle burst, "drink" animation on character
- Models reuse `medkit` asset with green tint shader

## Speed Potion (Toy Yellow)
- +30% movement speed for 8 seconds
- Carry limit: 1 per life
- Use key: G
- VFX: yellow motion trail, cartoon dust clouds at feet
- Cooldown after use: 5 seconds (anti-spam)

## Rage Potion (Toy Red)
- +25% damage for 6 seconds
- Carry limit: 1 per life
- Use key: H
- VFX: red eye glow, weapon barrel flame aura
- Risk: highlights user on enemy minimap (visible during cute phase only)

## Invisibility Potion (Toy Blue)
- 4 seconds of invisibility (90% transparent)
- Carry limit: 1 per life
- Use key: J
- VFX: blue dissolve effect, faint shimmer on movement
- Breaks on damage dealt or taken

## Potion Spawn Rules
- Spawn at fixed map points (potions rack in each castle's courtyard)
- Respawn every 45 seconds after pickup
- Maximum 3 potions per rack at any time
- Both teams have equal access to their own rack

## Adding a New Potion via FOSTAS OS
1. Create `godot/scripts/items/potion.gd` extending `Item` base class.
2. Define `@export` stats: effect_type, magnitude, duration, carry_limit.
3. Implement `use(player)` method that applies the effect.
4. Register in `godot/autoload/items_registry.gd`.
5. Add a spawn point to the map's potions rack.
