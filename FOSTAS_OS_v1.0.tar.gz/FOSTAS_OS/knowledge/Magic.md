# FOSTAS Magic System (Tactical Mage only)

## Spell Gating (per-life randomized quest)
Each life, the Mage is assigned ONE of two quests at random:

### Quest A — "3 Headshots"
Land three headshot kills. On completion, unlocks Tier-2 Weapon Enchantment.

### Quest B — "3 Teammate Heals"
Heal three teammates via Heal Pulse (shared with Medic cooldown). On completion, unlocks Tier-2 Mass Shield.

## Tier-2 Spells (quest reward)

### Weapon Enchantment
- Headshot damage multiplier jumps from x4 to x12
- Mage's weapon glows purple (#9D4EDD)
- Duration: 15 seconds
- Cooldown: 30 seconds
- Pairs with high-fire-rate weapons (BuzzBee SMG, Hornet SMG)

### Mass Shield
- All teammates within 8m gain 50 HP overshield
- Shield glows team-color
- Duration: 10 seconds
- Cooldown: 45 seconds

## Tier-3 Spells (Soul Contract — automatic penalty)

### Mass Teleport
- Teleports entire team to friendly castle
- Penalty: Mage loses 50 HP permanently for rest of round
- Cooldown: 120 seconds

### Soul Harvest
- Instantly kills all Shadow Monsters in 30m radius (only during FOSTAS event)
- Penalty: Mage's next 3 respawns take +50% damage
- Cooldown: 240 seconds

## Bounty → Ultimate Shortcut
Any player on a 3-killstreak gets a glowing red rune above their head (visible through walls to enemies only) AND automatically unlocks their class's Tier-2 ability without completing the quest. This is the parallel path to spell power.

## Spellbook Prop & VFX
- Mage carries `old_fantasy_book` asset floating beside left hand
- Book opens and glows when casting any spell
- Weapon Enchantment VFX: purple particle trail on bullets, weapon barrel aura
- Mass Shield VFX: team-color expanding ring on cast
- Mass Teleport VFX: team-color column of light, players dissolve and reform at castle
