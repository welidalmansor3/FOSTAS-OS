# FOSTAS: Toybox Terror — Game Bible

## Vision
FOSTAS: Toybox Terror is an online 5v5 multiplayer first-person shooter for PC (Steam) that pairs a brightly-colored stylized toy-world aesthetic with a mid-match psychological-horror event (the FOSTAS Monster). Engine: Godot 4.3. Match length: 8-12 minutes. Best-of-3 rounds in ranked Artifact Mode.

## Factions
Two factions only: **RED TEAM** vs **BLUE TEAM**. No other color is permitted anywhere in the project. This is enforced at the shader level — the PlasticToy material takes a `team_color_override` uniform.

## Match Structure
- 5v5 lobby-based
- 4-minute round timer
- 30-second artifact-spawn delay
- FOSTAS event triggers ONCE per match at random 1:30-6:30
- Reconnect window: 90 seconds

## Classes
1. **Combat Medic** — support/close-range. Body mesh: `low_poly_solider_character`. Carries `medkit`. Heal Pulse (Q), Revive (E).
2. **Tactical Mage** — mid-range caster. Body mesh: `soldat_low_poly`. Carries `old_fantasy_book`. Spell system gated behind per-life quests.

## Performance Targets
- 60 FPS sustained on GTX 1060 @ 1080p medium
- 120-144 FPS on RTX 4070
- Frame-time budget: 16.6 ms

## Damage Model
- Headshot: x4 multiplier
- Torso: x1
- Limb: x0.7
- TTK target: 0.3-0.8 s at optimal range (0.25 floor, 1.2 ceiling)

## Hardcore Injury System
Six limb HP pools per player: head, torso, left arm, right arm, left leg, right leg. Four thresholds trigger escalating debuffs.

## Bots
Fill empty lobby slots to guarantee 5v5 minimum. Reuse Medic/Mage meshes with Toy Reskin Pass. Three skill levels: easy, medium, hard.
