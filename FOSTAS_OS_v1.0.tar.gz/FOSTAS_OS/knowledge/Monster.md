# FOSTAS Monster System

## Shadow Monster (FOSTAS Event creature)
- Asset: `decraniated_low_poly_retro_pixel`
- Re-shaded to pure black (#0A0A0F) with red emissive eyes (#FF0000)
- Five instances spawn during the 20-second Hunt phase
- AI-driven: wanders randomly, chases nearest player on sight
- HP: 100
- Speed: 5 m/s (slightly slower than player sprint of 6 m/s)
- Attack: melee, 25 DMG per hit, 1.0s cooldown
- Detection range: 15m, FOV 180°
- Cannot be permanently killed — respawns after 5s if destroyed

## FOSTAS Event Phases

### Phase 1 — Blackout (0.4s)
- Every player's screen snaps to pure black
- Cute ambient music cuts to dead silence
- All team VOIP mutes
- No fade — sudden and total

### Phase 2 — Warning (1.0s)
- Massive blood-red glowing text: "FOSTAS MONSTER IS COMING! HIDE!"
- Heavy sub-bass rumble
- VOIP remains muted

### Phase 3 — Hunt (20s)
- 5 Shadow Monsters spawn from random courtyard points
- Players debuffed: -15% movement speed (panic slow), screen-shake x3, minimap disabled, VOIP muted
- Monsters hunt players; players can fight back but monster respawns
- Tactical Mage's Soul Harvest Tier-3 can clear monsters in radius

### Phase 4 — Recovery (2s)
- Screen fades back to cute palette
- Sun returns, ambient music resumes
- Match continues from where interrupted (timer, artifact state, bleed-outs preserved)

## Lighting Transition
- 0.4s lerp from baked cute-phase GI to real-time horror-phase GI
- Cold point-light follows each shadow monster
- Rest of map is in darkness during Hunt

## Adaptive Music
- 4 stems: cute base, cute combat, horror base, horror combat
- 0.5s crossfades
- During FOSTAS event: silence at Phase 1, sub-bass rumble at Phase 2, horror combat stem at Phase 3, fade back to cute at Phase 4

## Adding a New Monster via FOSTAS OS
1. Create `godot/scripts/monsters/<monster_name>.gd` extending `CharacterBody3D`.
2. Define `@export` stats: max_health, move_speed, attack_damage, detection_range.
3. Implement simple state machine: IDLE → WANDER → CHASE → ATTACK → DIE.
4. Implement `take_damage(amount)` and `die()`.
5. Create matching `.tscn` scene with model placeholder.
6. Register in `godot/autoload/monsters_registry.gd`.
7. (Optional) Request 3D model generation from Tripo.
