"""
FOSTAS OS — Single Launcher

Boots both the FastAPI backend (port 8000) and Streamlit frontend
(port 8501) from a single command:

    python run.py

Use Ctrl+C to stop both processes cleanly.

Optional args:
    python run.py --no-frontend      # backend only
    python run.py --no-backend       # frontend only
    python run.py --seed             # re-seed knowledge + Godot project, then exit
    python run.py --test             # run end-to-end test of all 4 demo prompts
"""
from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

# Resolve project root
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def run_seed() -> int:
    """Re-seed knowledge base + Godot project."""
    print("\n" + "=" * 60)
    print("FOSTAS OS — Seeding Knowledge Base & Godot Project")
    print("=" * 60 + "\n")
    return subprocess.call([sys.executable, str(ROOT / "scripts" / "seed.py")])


def run_tests() -> int:
    """Run end-to-end test of all 4 demo prompts."""
    print("\n" + "=" * 60)
    print("FOSTAS OS — End-to-End Test")
    print("=" * 60 + "\n")
    return subprocess.call([sys.executable, str(ROOT / "scripts" / "test_pipeline.py")])


def start_backend(host: str, port: int) -> subprocess.Popen:
    """Start the FastAPI backend via uvicorn."""
    print(f"[launcher] Starting FastAPI backend on {host}:{port} ...")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "uvicorn",
            "backend.main:app",
            "--host", host,
            "--port", str(port),
            "--log-level", "info",
        ],
        cwd=str(ROOT),
        env=env,
    )
    return proc


def start_frontend(port: int, backend_url: str) -> subprocess.Popen:
    """Start the Streamlit frontend."""
    print(f"[launcher] Starting Streamlit frontend on port {port} ...")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "streamlit", "run",
            str(ROOT / "frontend" / "app.py"),
            "--server.port", str(port),
            "--server.headless", "true",
            "--browser.gatherUsageStats", "false",
        ],
        cwd=str(ROOT),
        env=env,
    )
    return proc


def wait_for_backend(url: str, timeout: float = 30.0) -> bool:
    """Wait for backend to be reachable. Returns True if up."""
    import httpx
    start = time.time()
    while time.time() - start < timeout:
        try:
            r = httpx.get(url, timeout=2.0)
            if r.status_code == 200:
                return True
        except Exception:
            pass
        time.sleep(0.5)
    return False


def main() -> int:
    parser = argparse.ArgumentParser(
        description="FOSTAS OS — single launcher",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run.py                 # boot backend + frontend
  python run.py --no-frontend   # backend only
  python run.py --seed          # re-seed knowledge + Godot project
  python run.py --test          # run end-to-end tests
        """,
    )
    parser.add_argument("--no-frontend", action="store_true", help="don't start Streamlit")
    parser.add_argument("--no-backend", action="store_true", help="don't start FastAPI")
    parser.add_argument("--seed", action="store_true", help="re-seed knowledge + Godot project, then exit")
    parser.add_argument("--test", action="store_true", help="run end-to-end tests, then exit")
    args = parser.parse_args()

    # Handle --seed
    if args.seed:
        return run_seed()

    # Handle --test
    if args.test:
        return run_tests()

    # Load settings
    from config.settings import get_settings
    settings = get_settings()

    # Ensure directories + seed if knowledge is empty
    if not any(settings.knowledge_dir.glob("*.md")):
        print("[launcher] Knowledge base empty — seeding first...")
        run_seed()

    backend_proc: subprocess.Popen | None = None
    frontend_proc: subprocess.Popen | None = None
    procs: list[subprocess.Popen] = []

    try:
        # Start backend
        if not args.no_backend:
            backend_proc = start_backend(settings.backend_host, settings.backend_port)
            procs.append(backend_proc)
            backend_url = f"http://localhost:{settings.backend_port}/health"
            print(f"[launcher] Waiting for backend at {backend_url} ...")
            if not wait_for_backend(backend_url):
                print("[launcher] ⚠️  Backend did not become healthy in 30s — continuing anyway")
            else:
                print("[launcher] ✅ Backend healthy")

        # Start frontend
        if not args.no_frontend:
            frontend_proc = start_frontend(
                settings.frontend_port,
                f"http://localhost:{settings.backend_port}",
            )
            procs.append(frontend_proc)

        print("\n" + "=" * 60)
        print("  FOSTAS OS is RUNNING")
        print("=" * 60)
        if backend_proc:
            print(f"  📡 Backend API:    http://localhost:{settings.backend_port}")
            print(f"  📚 API docs:       http://localhost:{settings.backend_port}/docs")
        if frontend_proc:
            print(f"  🎨 Streamlit UI:   http://localhost:{settings.frontend_port}")
        print("\n  Press Ctrl+C to stop both services.")
        print("=" * 60 + "\n")

        # Wait for either process to exit
        while True:
            for p in procs:
                ret = p.poll()
                if ret is not None:
                    print(f"[launcher] Process {p.args} exited with code {ret}")
                    return ret
            time.sleep(0.5)

    except KeyboardInterrupt:
        print("\n[launcher] Shutting down...")
        return 0
    finally:
        for p in procs:
            try:
                if p.poll() is None:
                    p.terminate()
                    try:
                        p.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        p.kill()
            except Exception:
                pass
        print("[launcher] All services stopped.")


if __name__ == "__main__":
    sys.exit(main())
